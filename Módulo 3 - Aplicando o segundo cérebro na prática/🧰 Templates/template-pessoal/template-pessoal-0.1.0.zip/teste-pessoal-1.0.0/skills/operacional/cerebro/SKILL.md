---
name: cerebro
description: >
  Boot do cérebro pessoal Pixel sobre OpenClaw v2. Carrega contexto completo no início
  da sessão: MAPA.md raiz, USER.md, últimas 48h de daily notes em memory/{YYYY-MM-DD}.md,
  decisões do mês corrente em memory/decisoes/{YYYY-MM}.md, skills instaladas em
  skills/_registry.md. Funciona em standalone (1 cérebro) ou multi-brain (diretor com
  pessoal+empresa+diretoria lado a lado). Princípio P11 — detecta estrutura antes de ler.
---

# /cerebro — Boot do Cérebro Pessoal

> Skill de **entrada** da sessão. Lê tudo que o agente precisa pra estar atualizado: estrutura do workspace, perfil do dono, capturas recentes, decisões do mês, skills instaladas. Em modo multi-brain (diretor), também carrega cérebros coletivos clonados ao lado.

## Quando rodar

- **Início de toda sessão** Claude Code no workspace OpenClaw v2
- **Após `/clear` ou compactação** — contexto foi descartado, precisa recarregar
- Quando a sessão tá rodando há tempo e o agente parece ter perdido contexto

## Modos detectados automaticamente

| Modo | Quando | O que faz |
|---|---|---|
| **Standalone** | 1 cérebro só (cwd é workspace direto) | Boot completo do workspace atual |
| **Multi-brain** | cwd é pasta-mãe `~/{empresa}/` com `pessoal/`, `empresa/`, `diretoria/` | Boot do pessoal + carrega CLAUDE.md dos coletivos em paralelo |

Detectar:

```bash
if [ -f "MAPA.md" ] && [ -d "memory" ]; then
  MODO="standalone"
  WORKSPACE="."
elif [ -d "pessoal" ] && [ -f "pessoal/MAPA.md" ]; then
  MODO="multi-brain"
  WORKSPACE="pessoal"
else
  MODO="indefinido"
fi
```

Se `MODO=indefinido`, abortar:

> _"Workspace OpenClaw v2 não detectado. Verifique se você está na raiz do workspace ou na pasta-mãe (`~/{empresa}/`) com cérebros clonados. Se ainda não inicializou, rode `wizard-workspace` do mini-curso."_

## Fluxo — boot completo

### Passo 1 — Detectar estrutura (P11)

Checar arquivos canônicos do workspace v2:

```bash
test -f "$WORKSPACE/MAPA.md"             # mapa raiz existe?
test -f "$WORKSPACE/USER.md"             # perfil do dono existe?
test -d "$WORKSPACE/memory"              # pasta de memória existe?
test -d "$WORKSPACE/skills"              # pasta de skills existe?
test -f "$WORKSPACE/skills/_registry.md" # registry existe?
```

Se algum faltar, reportar quais e seguir com os que tem (não abortar — degrada).

### Passo 2 — Ler arquivos canônicos (paralelo)

Em UMA mensagem, fazer N tool calls Read em paralelo:

- `$WORKSPACE/MAPA.md` — gabarito do workspace
- `$WORKSPACE/USER.md` — quem é o dono
- `$WORKSPACE/IDENTITY.md` (se existe) — nome/modelo do agente
- `$WORKSPACE/SOUL.md` (se existe) — personalidade
- `$WORKSPACE/AGENTS.md` (se existe) — boot sequence/red lines
- `$WORKSPACE/memory/MAPA.md` — convenção da pasta memory

### Passo 3 — Ler últimas 48h de daily notes

```bash
# Encontra os 2 arquivos de daily mais recentes (formato YYYY-MM-DD.md)
ls -1 "$WORKSPACE/memory/"*.md 2>/dev/null \
  | grep -E "[0-9]{4}-[0-9]{2}-[0-9]{2}\.md$" \
  | sort -r | head -2
```

Ler os 2 arquivos retornados (no máximo 48h de capturas — 1 ontem + 1 hoje, ou 2 sessões dentro do mesmo dia).

### Passo 4 — Ler decisões do mês corrente

```bash
test -f "$WORKSPACE/memory/decisoes/$(date +%Y-%m).md"
```

Se existe, ler. Se não, OK — talvez sem decisões registradas neste mês.

### Passo 5 — Ler registry de skills

```bash
test -f "$WORKSPACE/skills/_registry.md"
```

Se existe, ler — agente sabe que skills tem disponível.

### Passo 6 — Modo multi-brain (se aplicar)

Se `MODO=multi-brain`, em paralelo com os passos acima, carregar CLAUDE.md dos cérebros coletivos:

- `$PWD/empresa/CLAUDE.md` (se existir)
- `$PWD/diretoria/CLAUDE.md` (se existir)

### Passo 7 — Confirmação curta (1 linha)

**Standalone:**

```
Cérebro de {USER_NAME} carregado: 2 dailies (48h), 5 decisões em maio, 12 skills.
```

**Multi-brain:**

```
3 cérebros carregados: Vera (pessoal) ✓, Léo (empresa) ✓, Atena (diretoria) ✓.
Pessoal: 2 dailies (48h), 5 decisões em maio, 12 skills.
```

Se algum cérebro faltou:

```
2/3 cérebros: Vera (pessoal) ✓, Léo (empresa) ✓, diretoria ✗ (não clonado).
```

## O que NÃO faz

- Não faz `git pull` — pra sincronizar com remoto, rodar manualmente. (Hook `SessionStart` pode fazer automaticamente se configurado pelo aluno.)
- Não distribui capturas — pra isso, `/sync-empresa` ou `/sync-diretoria` (skills nos respectivos repos coletivos).
- Não persiste sessão — pra isso, `/sync-pessoal` (alias `/save`, ou linguagem natural).
- Não cria daily note — só lê.

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| Sessão Claude Code aberta na raiz do workspace ou pasta-mãe | `pwd` retorna path válido | Avisa cwd; sugere navegar pro local certo |
| `MAPA.md` raiz existe | `test -f MAPA.md` | Orientar rodar `wizard-workspace` do mini-curso |
| `memory/MAPA.md` existe | `test -f memory/MAPA.md` | Idem |
| Permissão de leitura nos arquivos | `cat <arquivo>` funciona | Reporta path com erro; segue com os que conseguiu |

## Variações conhecidas

| Cenário | Adaptação |
|---|---|
| Solo founder com workspace v2 | Modo standalone. Carrega só este cérebro. Mensagem celebratória, não diagnóstica. |
| Diretor com 3 cérebros lado a lado | Modo multi-brain. Carrega 3 CLAUDE.md em paralelo + boot completo do pessoal. |
| Diretor com 2 cérebros (sem `diretoria/`) | Modo multi-brain parcial. Reporta "2/3 cérebros". |
| Workspace ainda não inicializado | `wizard-workspace` v2 não rodou. Skill aborta com orientação. |
| Aluno tem `MAPA.md` mas é template upstream (com `{{...}}`) | Detectar placeholders restantes; orientar finalizar setup. |
| Aluno tem `memory/sessions/` (estrutura legada pré-V2) | Ler `sessions/*.md` como fallback além de `memory/*.md`. Avisar uma vez sobre migração. |
| Sem daily notes recentes (workspace recém-criado) | Ok — só carrega MAPA + USER. Sem alarme. |
| Múltiplas empresas paralelas (`~/acme/`, `~/norte/`) | Skill opera em 1 pasta-mãe por sessão. Pra outra empresa, abrir nova sessão. |

## Quando algo não funciona

| Sintoma | Causa | Ação |
|---|---|---|
| `MAPA.md não encontrado` | Workspace não inicializado | Orientar `wizard-workspace` do mini-curso v2 |
| `Permission denied` ao ler arquivo | Permissão restrita ou clone parcial | Reportar path; seguir com os que conseguiu |
| `CLAUDE.md` ainda tem `{{...}}` | Template upstream não foi inicializado naquele cérebro | Avisar e oferecer rodar inicialização |
| Subpasta é symlink quebrado | Setup workstation criou symlink mas alvo sumiu | Reportar; sugerir reclone ou re-setup |
| Resultado contradiz o que o usuário esperava | `/cerebro` rodou antes de compactar e contexto foi perdido | Sugerir re-rodar |

## Adaptando pra realidade do aluno

- **Aluno do mini-curso (solo)** — provavelmente só `pessoal/`. Skill funciona standalone. Mensagem celebratória.
- **Diretor adoptou recente** — pode ter clonado pessoal mas ainda não inicializado os coletivos. Detectar template não-inicializado e oferecer rodar inicialização.
- **Funcionário sem cérebro pessoal** — modo standalone no `empresa/`. Skill quase no-op (Claude Code já carrega cwd) — útil só após `/clear` pra recarregar daily 48h.
- **Setup customizado** (paths não-canônicos) — aceitar env vars `BRAIN_PESSOAL`, `BRAIN_EMPRESA`, `BRAIN_DIRETORIA`. Gravar em `~/.cerebro-paths` pra próxima sessão.

---

*Skill canônica de boot — vive nos 3 templates Pixel (pessoal, empresa, diretoria). Adaptada à v2 do mini-curso OpenClaw em 2026-05-02.*
