---
name: sync-pessoal
description: >
  Flush de fim de sessão do cérebro pessoal Pixel. Roteia capturas pra pasta correta
  do workspace OpenClaw v2 (memory/{YYYY-MM-DD}.md pra daily, memory/decisoes/{YYYY-MM}.md
  pra decisões, memory/projects/{nome}.md pra atualizações de projeto), commita e pusha
  em `main`. Reativa: salva o que o aluno pede, não opina. Detecta estrutura presente
  antes de escrever (P11). Triggers LN: "salva", "guarda", "comita", "save", "flush".
---

# /sync-pessoal — Cérebro Pessoal Pixel (sobre OpenClaw v2)

> Flush de fim de sessão. Pega tudo que o Claude acumulou no buffer durante a conversa e materializa nas pastas do workspace OpenClaw v2 — sem inventar estrutura, sem opinar.

## Quando rodar

**Automático:**
- Antes de compactar a sessão (sempre — nunca compactar com buffer não salvo)

**Manual:**
- Usuário digita `/sync-pessoal` (ou alias `/save`)
- Linguagem natural: "salva", "guarda", "comita", "flush", "fecha a sessão"

## Princípios

1. **Reativa, não proativa.** Salva o que o aluno pediu. Não escaneia menções pra perguntar "quer guardar URL X?". Se o aluno quer guardar algo, ele diz.
2. **Foco em escrever.** Lógica de boot/leitura de contexto é responsabilidade do `/cerebro`, não desta skill. Se o agente já tem contexto carregado (rodou `/cerebro`), `/sync-pessoal` apenas escreve. Se não rodou, faz só uma checagem mínima (`memory/MAPA.md` existe?) antes de escrever.
3. **Mapas distribuídos (P12).** Respeita a convenção do workspace v2 — `memory/MAPA.md` define o que vai onde. Se o aluno customizou, segue a customização.
4. **Padrão OpenClaw.** Daily notes em `memory/{YYYY-MM-DD}.md` direto na raiz de `memory/` — não em `sessions/`, não em `daily/`.

## Fluxo — 5 passos

### Passo 1 — Sanity check (1 linha)

```bash
test -f memory/MAPA.md || { echo "Rode /cerebro ou wizard-workspace primeiro"; exit 1; }
```

Sem mais. Boot completo é responsabilidade do `/cerebro`.

### Passo 2 — Revisão mental e classificação

Reler a sessão desde o último `/sync-pessoal`. Classificar capturas em 3 categorias:

| Categoria | Destino | Quando |
|---|---|---|
| **Daily note** | `memory/{YYYY-MM-DD}.md` (append) | Sempre — registra o que aconteceu na sessão |
| **Decisão registrada** | `memory/decisoes/{YYYY-MM}.md` (append) | Aluno tomou decisão concreta que vale o registro mensal |
| **Atualização de projeto** | `memory/projects/{nome}.md` (update) | Mudou status, métricas ou contexto de um projeto ativo |

Mesma captura pode ir pra mais de um destino (ex: decisão + atualização de projeto + linha na daily). A daily é o INDEX do que aconteceu — outras pastas têm o conteúdo durável.

### Passo 3 — Escrever nas pastas certas

#### Daily note (sempre)

Append em `memory/{YYYY-MM-DD}.md`:

```markdown
# {{YYYY-MM-DD}}

## Sessões

### {{HH:MM}} — {tópico}

- {o que aconteceu, 1-3 bullets}
- {se houve decisão registrada} → ver `memory/decisoes/{YYYY-MM}.md#{slug}`
- {se houve atualização de projeto} → ver `memory/projects/{nome}.md`

{próximos passos, se houver}

## Capturas pra contexto durável

- `memory/decisoes/{YYYY-MM}.md` — {N} entradas adicionadas (se houver)
- `memory/projects/{nome}.md` — status atualizado (se houver)
- {outros arquivos canônicos atualizados, se houver}
```

Se `memory/{YYYY-MM-DD}.md` já existe:
- **Append** nova `### HH:MM — {tópico}` em `## Sessões`
- **Atualizar** `## Capturas pra contexto durável` (sobrescreve o índice — ele reflete o estado de hoje)
- **Nunca apagar** sessões anteriores do dia.

#### Decisões (se houver)

Append em `memory/decisoes/{YYYY-MM}.md`:

```markdown
## {{YYYY-MM-DD HH:MM}} — {título da decisão}

**Decisão:** {1-2 frases}
**Contexto:** {por que, o que motivou}
**Consequências:** {o que muda a partir daqui}
```

#### Atualização de projeto (se houver)

Update em `memory/projects/{nome}.md`. Skill **não cria projeto novo** — se o projeto não existe ainda, perguntar ao aluno:

> _"Detectei capturas sobre 'projeto-x' mas `memory/projects/projeto-x.md` não existe. Crio ou tá em outro lugar?"_

### Passo 4 — Git

```bash
git add memory/
git commit -m "sync-pessoal: {resumo em 1 linha do que foi capturado}"
git pull --no-rebase origin main    # merge, nunca rebase
git push origin main
```

**Merge não rebase.** Workspace pode ser escrito por você no laptop E pelo OpenClaw na VPS — rebase causa estados inconsistentes.

**Nunca `git add .` ou `git add -A`.** Adicione só `memory/` (escopo da skill).

### Passo 5 — Confirmação curta

```
✓ Sync completo:
  - Daily: memory/2026-05-02.md (+1 sessão)
  - Decisões: memory/decisoes/2026-05.md (+2 entradas)
  - Projetos: memory/projects/lancamento-curso.md (status atualizado)
  Commit + push OK.
```

Se houver capturas com escopo cross-brain (empresa/diretoria), sugerir — não chamar:

> _"Algumas capturas parecem ter escopo empresa ou diretoria. Quer rodar `/sync-empresa` ou `/sync-diretoria` agora?"_

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| Workspace OpenClaw v2 inicializado | `test -f MAPA.md && test -f memory/MAPA.md` | Orientar rodar `wizard-workspace` do mini-curso |
| Branch atual é `main` | `git branch --show-current` | `git checkout -b main` ou orientar resolver |
| Repo git inicializado | `git rev-parse --show-toplevel` | Orientar `git init` ou clone correto |
| Remote `origin` (opcional pra push) | `git remote -v` | Commit local funciona; orientar criar remote |
| Internet (opcional pra push) | — | Commit local; push fica pendente até reconectar |

## Variações conhecidas

| Cenário | Adaptação |
|---|---|
| Aluno tem `memory/sessions/` (estrutura legada) | Avisar que padrão v2 é `memory/{YYYY-MM-DD}.md` direto. Oferecer migrar — não forçar. |
| Aluno customizou `memory/MAPA.md` com pastas extras (`memory/people/`, `memory/research/`) | Respeitar. `/sync-pessoal` lê o MAPA local e roteia conforme convenção do aluno. |
| Daily note já existe pro dia | Append nova seção `## HH:MM — {tópico}`. Nunca sobrescrever. |
| Captura tem screenshot/imagem | Skill **não baixa**. Se aluno quer guardar, ele pede e passa URL externa. |
| Múltiplas máquinas (laptop + VPS) | Sempre `pull --no-rebase` antes; `push` ao fim. Conflito → resolve via merge. |
| Solo founder sem cérebros coletivos | Skill funciona standalone. Não sugere `/sync-empresa` no fim. |
| Diretor com 3 cérebros lado a lado | Sugere `/sync-empresa` ou `/sync-diretoria` quando contexto cross-brain aparece. Nunca chama automaticamente. |
| Sessão muito longa (compactação iminente) | Roda automaticamente antes do compactador disparar. |
| Sessão sem contexto durável | Cria daily com "sessão operacional, sem capturas duráveis" pra manter trilha. |

## Quando algo não funciona

| Sintoma | Causa | Ação |
|---|---|---|
| `Workspace OpenClaw v2 não inicializado` | `wizard-workspace` não rodou | Orientar rodar antes de qualquer `/sync-pessoal` |
| `fatal: not a git repository` | Pasta não é repo OU aluno fora do workspace | Verificar `pwd`; orientar `git init` ou clone |
| `error: src refspec main does not match any` | Branch local não é `main` | `git checkout -b main` |
| `Permission denied (publickey)` | SSH key não configurada | Orientar `gh auth login` ou setup SSH |
| `non-fast-forward` no push | Outra máquina pushou | `git pull --no-rebase`, resolver, retry |
| Conflito de merge no pull | Edição simultânea (laptop + VPS) | Resolver mantendo as duas versões. **Nunca** `--force`. |
| Captura sobre projeto que não existe em `memory/projects/` | Aluno mencionou projeto novo | Perguntar antes de criar arquivo. Não criar silenciosamente. |
| Aluno diz "salva" sem ter conversa | Sessão vazia | Confirmar: _"Sessão sem contexto durável. Crio daily marcando isso ou pulo?"_ |
| Trigger LN ambíguo (`"salva isso"`) | Pode ser `/sync-pessoal` OU pedido pra salvar arquivo específico | Confirmar com 1 linha antes de rodar |

## Adaptando pra realidade do aluno

- **Stack diferente** (Notion, Obsidian, Logseq como camada principal) — `/sync-pessoal` não substitui essas ferramentas. Posiciona o cérebro git como **backup + contexto pro Claude**, não editor primário.
- **Aluno não conhece git** — em primeira execução com erro, agente explica em linguagem natural antes de propor comando.
- **Cérebro pessoal em VPS via OpenClaw + laptop com Claude Code** — pull antes de trabalhar, push ao terminar. Conflitos via merge.
- **Solo founder** — skill standalone. Não sugerir `/sync-empresa` no fim.
- **Aluno customizou estrutura** (pastas extras em `memory/`, naming diferente) — respeitar; ler `memory/MAPA.md` local pra entender convenção.

## Regras duras

- **Só Markdown e HTML.** Outros formatos viram URL no markdown (skill não baixa).
- **Reativa.** Skill executa o que o aluno pediu. Não pergunta proativamente sobre menções.
- **`memory/` é o escopo.** `git add memory/` específico, nunca `.` ou `-A`.
- **Padrão OpenClaw**: daily em `memory/{YYYY-MM-DD}.md`, decisões em `memory/decisoes/{YYYY-MM}.md`, projetos em `memory/projects/{nome}.md`.
- **P11 — detectar antes**: respeita o que existe. Não cria pasta nova sem permissão.
- **Merge não rebase** em `git pull`.
- **Cross-brain é explícito.** `/sync-pessoal` só opera neste workspace.

---

*Skill da família `/sync-*` (Pixel AI Hub). Cross-brain via `/sync-empresa` (template-empresa) e `/sync-diretoria` (template-diretoria) — skills irmãs nos respectivos repos.*
