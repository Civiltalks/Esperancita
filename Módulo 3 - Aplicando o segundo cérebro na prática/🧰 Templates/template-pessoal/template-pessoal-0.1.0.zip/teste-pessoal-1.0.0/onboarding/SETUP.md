# SETUP — Camada Pixel sobre OpenClaw v2

> Instruções de instalação completas estão no [`README.md`](../README.md). Este arquivo cobre só o pré-requisito.

## Pré-requisito: workspace OpenClaw v2

Esta camada não cria estrutura de pastas. Pré-requisito é ter um workspace OpenClaw v2 já inicializado pelo `wizard-workspace` do starter-kit do mini-curso.

Verificar se você tem workspace v2:

```bash
cd ~/seu-workspace
test -f MAPA.md && test -f memory/MAPA.md && test -d skills/ \
  && echo "✓ workspace v2 OK — pronto pra instalar Pixel" \
  || echo "✗ falta wizard-workspace — faça mini-curso v2 primeiro"
```

Se não passa: faça o [mini-curso OpenClaw v2](https://aihub.pixeleducacao.com.br/pre-lancamento) ou rode `wizard-workspace` standalone do starter-kit.

## Instalar a camada Pixel

Quando workspace v2 estiver OK:

1. **Clone este repo localmente:**
   ```bash
   git clone git@github.com:pixel-educacao/template-second-brain-pessoal.git ~/pixel-cerebro-pessoal
   ```

2. **Abra Claude Code no seu workspace v2** (não neste repo).

3. **Cole o prompt de instalação** do [`README.md`](../README.md) (seção "Como instalar"). O agente faz o resto: detecta o workspace, cruza com a proposta deste repo, propõe estrutura customizada, executa com sua confirmação item-a-item.

## Validar

Após instalação, no Claude Code:

```
/cerebro
```

Deve retornar 1 linha confirmando o boot:

```
Cérebro de {seu_nome} carregado: 0 dailies, 0 decisões em maio, 12 skills.
```

(Os zeros são esperados se workspace é fresco.)

E ao fim de uma conversa:

```
salva
```

Deve criar/atualizar `memory/{YYYY-MM-DD}.md` e commitar em main.

## Cross-brain (pra diretor)

Se você é diretor com cérebros coletivos, configure:

```
~/{empresa}/
├── pessoal/        ← seu workspace v2 + camada Pixel
├── empresa/        ← clone do template-second-brain-empresa
└── diretoria/      ← clone do template-second-brain-diretoria
```

Abra Claude Code na pasta-mãe `~/{empresa}/` e rode `/cerebro` — modo multi-brain detectado automaticamente.

## Suporte

Canal do Pixel AI Hub. Ou abra issue no repo.
