# template-second-brain-pessoal — Pixel AI Hub

> Camada **Pixel AI Hub** sobre o workspace OpenClaw v2 do mini-curso. Adiciona Claude Code + skills `/sync-pessoal` e `/cerebro` ao workspace que o aluno já configurou.

**Pré-requisito:** workspace OpenClaw v2 inicializado pelo `wizard-workspace` do starter-kit do mini-curso. Esta camada **não cria estrutura** — complementa.

---

## Como instalar — cole este prompt no seu Claude Code

Abra o Claude Code dentro do **seu workspace OpenClaw v2** (não dentro deste repo) e cole:

```
Lê o README deste repo Pixel (path: ~/pixel-cerebro-pessoal/, ou onde
você clonou) e me guia na instalação da camada Pixel sobre meu workspace
OpenClaw v2 (cwd atual). Detecta o que já existe aqui, cruza com o que
o repo traz, propõe estrutura final customizada por arquivo, e pede
minha confirmação antes de copiar/sobrescrever qualquer coisa.
```

O agente lê este README, detecta o estado do seu workspace, cruza com a estrutura proposta abaixo, e te apresenta um plano antes de executar.

---

## Pra o agente — fluxo de instalação em 6 passos

> Este README é estruturado pro Claude Code conseguir executar. Cada passo tem instruções concretas, comandos e tabelas de decisão.

### Passo 1 — Detectar estado atual do workspace

`$WORKSPACE = $PWD` (deve ser o workspace OpenClaw v2 do aluno, não este repo).

Checar se é um workspace v2 válido:

```bash
test -f "$WORKSPACE/MAPA.md"             || FALTA+="MAPA.md "
test -f "$WORKSPACE/memory/MAPA.md"      || FALTA+="memory/MAPA.md "
test -d "$WORKSPACE/skills"              || FALTA+="skills/ "
test -f "$WORKSPACE/skills/_registry.md" || FALTA+="skills/_registry.md "
```

Se algo falta, **abortar com orientação**:

> _"Workspace OpenClaw v2 não inicializado em `$WORKSPACE`. Falta: `$FALTA`. Antes de instalar a camada Pixel, rode o `wizard-workspace` do starter-kit do mini-curso OpenClaw v2."_

Se tudo presente, prosseguir.

### Passo 2 — Detectar estrutura proposta neste repo

`$TEMPLATE = path do repo Pixel clonado` (perguntar ao aluno se ambíguo; default: `~/pixel-cerebro-pessoal/` ou path onde está este README).

Arquivos que este repo traz pra instalação:

| Origem | Destino | Tipo |
|---|---|---|
| `$TEMPLATE/CLAUDE.md` | `$WORKSPACE/CLAUDE.md` | Camada Pixel |
| `$TEMPLATE/skills/operacional/sync-pessoal/SKILL.md` | `$WORKSPACE/skills/operacional/sync-pessoal/SKILL.md` | Skill |
| `$TEMPLATE/skills/operacional/cerebro/SKILL.md` | `$WORKSPACE/skills/operacional/cerebro/SKILL.md` | Skill |
| `$TEMPLATE/.claude/commands/cerebro.md` | `$WORKSPACE/.claude/commands/cerebro.md` | Slash command (opcional, só se aluno usa) |
| `$TEMPLATE/.claude/commands/sync-pessoal.md` | `$WORKSPACE/.claude/commands/sync-pessoal.md` | Slash command (opcional) |
| `$TEMPLATE/.claude/commands/save.md` | `$WORKSPACE/.claude/commands/save.md` | Slash command (opcional, alias) |

**Não copiar:** `README.md` (este arquivo), `onboarding/SETUP.md`, `LICENSE` — são meta-template.

### Passo 3 — Cruzar e classificar cada item

Pra cada item da tabela acima, classificar a ação:

| Estado destino | Conteúdo | Ação |
|---|---|---|
| Não existe | n/a | **COPIAR** sem perguntar |
| Existe e idêntico ao do template (`diff -q` igual) | n/a | **PULAR** silenciosamente |
| Existe e divergente | n/a | **PERGUNTAR** ao aluno: manter / sobrescrever / mostrar diff / merge manual |
| Existe e é template upstream (tem `{{...}}`) | n/a | **AVISAR** que aluno tem template inicial não-finalizado e oferecer rodar inicialização do mini-curso primeiro |

Para arquivos **divergentes**, mostrar `diff -u` ANTES de pedir decisão. Aluno escolhe item-a-item — não fazer escolha em lote.

### Passo 4 — Apresentar proposta ao aluno

Antes de tocar em qualquer arquivo, apresentar resumo claro:

```
Detectei seu workspace v2 em: ~/seu-workspace/

Plano de instalação:

✓ COPIAR (3 arquivos novos):
  - CLAUDE.md → raiz (instruções de boot pra Claude Code)
  - skills/operacional/sync-pessoal/SKILL.md
  - skills/operacional/cerebro/SKILL.md

⚠️ DIVERGENTES — vou perguntar antes de mexer (1 arquivo):
  - skills/_registry.md (você tem 5 skills, vou propor adicionar +2 da Pixel)

✓ SLASH COMMANDS — copio se você usar Claude Code (opcional):
  - .claude/commands/{cerebro,sync-pessoal,save}.md

(opções: [s]eguir / [m]ostrar diff de cada / [c]ancelar)
```

Esperar OK do aluno antes de executar.

### Passo 5 — Executar com confirmação item-a-item

Pra cada arquivo a ser copiado/sobrescrito:

1. Mostrar 1 linha do que vai fazer ("Copiando `skills/operacional/sync-pessoal/SKILL.md`...")
2. Se sobrescrita, mostrar diff antes
3. Executar (`cp` ou `Write` via Claude Code tools)
4. Confirmar sucesso (1 linha)

Atualizar `skills/_registry.md` adicionando as 2 skills Pixel — perguntar antes de modificar.

### Passo 6 — Validar instalação

Smoke test rápido:

```bash
test -f "$WORKSPACE/CLAUDE.md"                                       && echo "✓ CLAUDE.md instalado"
test -f "$WORKSPACE/skills/operacional/sync-pessoal/SKILL.md"        && echo "✓ /sync-pessoal instalada"
test -f "$WORKSPACE/skills/operacional/cerebro/SKILL.md"             && echo "✓ /cerebro instalada"
```

Confirmação final ao aluno:

```
✅ Camada Pixel instalada em ~/seu-workspace/

Próximos passos:

1) Reinicie o Claude Code (pra recarregar slash commands se aplicável)
2) Rode /cerebro pra ver o boot funcionar (deve listar suas dailies + decisões + skills)
3) Use /sync-pessoal (ou diga "salva") no fim de cada sessão
4) Se você é diretor com cérebros coletivos, considere clonar
   template-second-brain-empresa e template-second-brain-diretoria
   lado a lado em ~/{empresa}/{empresa,diretoria}/

Suporte: https://aihub.pixeleducacao.com.br
```

---

## O que esta camada faz (humano)

Adiciona ao seu workspace OpenClaw v2:

| O que | Função |
|---|---|
| `CLAUDE.md` na raiz | Instruções de boot pra Claude Code (rodar `/cerebro` no início, `/sync-pessoal` no fim) |
| `skills/operacional/cerebro/` | Boot da sessão — lê MAPA, USER, últimas 48h de daily notes, decisões do mês, skills |
| `skills/operacional/sync-pessoal/` | Flush de fim de sessão — roteia capturas pra `memory/{YYYY-MM-DD}.md`, `memory/decisoes/`, `memory/projects/` |

**Não cria** pastas (`memory/`, `skills/`, `content/`, `archive/`) — workspace v2 já tem do starter-kit do mini-curso.

## Cross-brain (opcional, pra diretor)

Se você é diretor com cérebros coletivos, layout recomendado:

```
~/{empresa}/
├── pessoal/        ← seu workspace v2 + camada Pixel (recém-instalada)
├── empresa/        ← clone do template-second-brain-empresa
└── diretoria/      ← clone do template-second-brain-diretoria
```

Abra Claude Code na pasta-mãe `~/{empresa}/` e rode `/cerebro` — modo multi-brain detectado automaticamente.

## Re-instalação / upgrade

Quando a Pixel atualizar este repo:

1. `git pull` no clone local (`cd ~/pixel-cerebro-pessoal && git pull`)
2. Voltar ao workspace v2 e colar de novo o prompt de instalação no Claude Code
3. Agente compara conteúdo, pergunta antes de sobrescrever cada arquivo divergente

## Estrutura deste repo (template)

```
template-second-brain-pessoal/
├── README.md                                       ← este arquivo (instrução pro humano + agente)
├── CLAUDE.md                                       ← vai pra raiz do workspace v2
├── LICENSE
├── .gitignore
├── onboarding/SETUP.md                             ← detalhes do fluxo de instalação
├── .claude/commands/                               ← slash commands (Pixel dev)
│   ├── cerebro.md
│   ├── save.md
│   └── sync-pessoal.md
└── skills/operacional/
    ├── cerebro/SKILL.md
    └── sync-pessoal/SKILL.md
```

## Princípios da camada Pixel

- **P11 — Detectar antes de instalar:** agente lê estado do workspace e cruza com proposta. Não copia cego.
- **P12 — Mapas distribuídos:** sem `TOOLS.md` monolítico. Cada pasta documenta a si mesma.
- **Reativa:** `/sync-pessoal` salva o que aluno pediu. Não escaneia menções.
- **Padrão OpenClaw:** daily notes em `memory/{YYYY-MM-DD}.md` direto.
- **Default conservador:** quando dúvida, não sobrescreve. Aluno confirma item-a-item.

## Licença

Uso restrito aos assinantes do Pixel AI Hub. Ver [LICENSE](LICENSE).
