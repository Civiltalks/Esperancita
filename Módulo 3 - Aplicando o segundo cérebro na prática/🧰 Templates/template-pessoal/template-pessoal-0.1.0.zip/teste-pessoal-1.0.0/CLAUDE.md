# CLAUDE.md — Cérebro Pessoal Pixel (sobre OpenClaw v2)

> **Este arquivo é instalado pela skill `instalar-cerebro-pixel` na raiz do seu workspace OpenClaw v2.**
> Complementa (não substitui) `MAPA.md`, `USER.md`, `SOUL.md`, `IDENTITY.md`, `AGENTS.md` que vieram do mini-curso v2.

## Você é o Claude Code aqui

Você não é o agente OpenClaw que roda na VPS — esse é a Vera/Atlas/Léo etc., 24/7 na Hostinger Managed. Você é o **Claude Code operando neste workspace local** (clone git do que está na VPS).

A Pixel adicionou aqui:
- Este `CLAUDE.md`
- Skills em `skills/operacional/`: `sync-pessoal`, `cerebro` (boot), `instalar-cerebro-pixel`

Tudo o mais (estrutura de pastas, MAPA, SOUL, USER) vem do **starter-kit v2** do mini-curso OpenClaw da Pixel.

## Início de sessão

```
/cerebro
```

A skill `/cerebro` faz **boot completo**: lê `MAPA.md` raiz, `USER.md`, últimas 48h de daily notes em `memory/{YYYY-MM-DD}.md`, decisões do mês corrente em `memory/decisoes/{YYYY-MM}.md`, skills instaladas. Em modo multi-brain (diretor com cérebros coletivos lado a lado), também carrega CLAUDE.md de empresa e diretoria.

Não decore o boot — chame `/cerebro` e a skill cuida.

## Fim de sessão

```
/sync-pessoal     (ou /save, "salva", "guarda", "comita")
```

Roteia capturas pra `memory/{YYYY-MM-DD}.md` (daily), `memory/decisoes/{YYYY-MM}.md` (decisões), `memory/projects/{nome}.md` (projetos). Commit + push em `main`. Reativa: salva o que você pediu, não escaneia menções.

## Skills da Pixel disponíveis

| Skill | Quando | Path |
|---|---|---|
| `/cerebro` | Início de sessão | `skills/operacional/cerebro/` |
| `/sync-pessoal` | Fim de sessão | `skills/operacional/sync-pessoal/` |
| `/instalar-cerebro-pixel` | Primeira instalação ou re-instalação | `skills/operacional/instalar-cerebro-pixel/` |

## Cross-brain (se aplicável)

Se você é diretor com `~/{empresa}/{empresa,diretoria}/` clonados ao lado deste pessoal, abrir Claude Code na pasta-mãe `~/{empresa}/` e rodar `/cerebro` — a skill detecta multi-brain automaticamente e carrega os 3 contextos.

Distribuir capturas pessoais pros cérebros coletivos é via `/sync-empresa` ou `/sync-diretoria` (skills que vivem nos respectivos repos, não aqui).

## Regras de comportamento

- **Skill-first:** antes de tarefa recorrente, checar `skills/_registry.md`.
- **Tudo vira registro:** decisão → `memory/decisoes/`, projeto → `memory/projects/`, sessão → `memory/{YYYY-MM-DD}.md`. Não confiar em "notas mentais".
- **Bias to action:** chegou tarefa → resolve. Não pedir confirmação pra ler arquivo.
- **`/sync-pessoal` antes de compactar:** buffer não-salvo é buffer perdido.

---

*Instalado pela skill `instalar-cerebro-pixel` (Pixel AI Hub). Estrutura de workspace vem do mini-curso OpenClaw v2.*
