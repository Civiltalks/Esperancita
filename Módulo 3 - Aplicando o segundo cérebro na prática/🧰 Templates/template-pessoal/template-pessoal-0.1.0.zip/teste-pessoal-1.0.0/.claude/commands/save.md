---
description: Alias para /sync-pessoal — flush de fim de sessão do cérebro pessoal.
---

Run the skill at `skills/operacional/sync-pessoal/SKILL.md`.
