---
description: Flush de fim de sessão do cérebro pessoal Pixel. Roteia capturas pra memory/{YYYY-MM-DD}.md (daily), memory/decisoes/{YYYY-MM}.md (decisões), memory/projects/{nome}.md (projetos). Reativa: salva o que foi pedido, não opina. Aceita LN ("salva", "guarda", "comita").
---

Run the skill at `skills/operacional/sync-pessoal/SKILL.md`.
