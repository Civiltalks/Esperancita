---
description: Boot do cérebro pessoal Pixel sobre OpenClaw v2. Lê MAPA, USER, últimas 48h de daily notes, decisões do mês, registry de skills. Funciona em standalone (1 cérebro) ou multi-brain (diretor com pessoal+empresa+diretoria lado a lado).
---

Run the skill at `skills/operacional/cerebro/SKILL.md`.
