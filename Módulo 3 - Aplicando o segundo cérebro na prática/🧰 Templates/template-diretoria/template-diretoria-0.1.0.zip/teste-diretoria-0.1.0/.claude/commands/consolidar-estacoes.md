---
description: Rotina de consolidação noturna das estações dos sócios. NA DIRETORIA SEMPRE abre PR — nunca promove direto. Roda automaticamente pelo agente gestor às 02:00 BRT.
---

Run the skill at `empresa/skills/consolidar-estacoes/SKILL.md`.
