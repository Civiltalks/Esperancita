---
description: Cria inbox/{slug}/ deste cérebro diretoria pra você capturar via /sync-diretoria. Default privado invertido (próprio da diretoria). Atômica.
---

Run the skill at `empresa/skills/setup-estacao-pessoal/SKILL.md`.
