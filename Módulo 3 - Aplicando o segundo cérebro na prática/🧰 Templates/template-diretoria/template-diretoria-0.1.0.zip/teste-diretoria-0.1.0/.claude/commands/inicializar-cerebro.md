---
description: Configurar este cérebro diretoria pela primeira vez após clonar o template. Preenche placeholders, renomeia pasta do agente. Roda 1 vez só.
---

Run the skill at `empresa/skills/inicializar-cerebro/SKILL.md`.
