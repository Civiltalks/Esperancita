---
description: Alias pra /sync-diretoria — empacota capturas pro inbox/{sócio}/ em staging via quiz rigoroso (3 gatilhos awareness, default privado, anonimização, varredura CPF/CNPJ, PR obrigatório). Mantido pra hábito muscular. Se você esperava flush filesystem-only (comportamento antigo), use /sync-pessoal no template-pessoal.
---

Run the skill at `empresa/skills/sync-diretoria/SKILL.md`.
