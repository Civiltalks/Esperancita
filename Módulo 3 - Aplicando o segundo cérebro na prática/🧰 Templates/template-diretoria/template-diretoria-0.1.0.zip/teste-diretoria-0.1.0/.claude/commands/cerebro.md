---
description: Carrega CLAUDE.md dos cérebros disponíveis em ~/{{EMPRESA_SLUG}}/ em paralelo (time, diretoria, pessoal — o que estiver presente). Use no INÍCIO de cada sessão multi-brain.
---

Run the skill at `empresa/skills/cerebro/SKILL.md`.
