---
description: Wizard guiado ponta-a-ponta pra novo sócio-diretor. 11 passos: modelo dos 2 cérebros, 3 gatilhos detalhados, default privado, estações nos 2 repos, OpenClaw pessoal, validação. ~30-40 min.
---

Run the skill at `empresa/skills/onboarding-diretor/SKILL.md`.
