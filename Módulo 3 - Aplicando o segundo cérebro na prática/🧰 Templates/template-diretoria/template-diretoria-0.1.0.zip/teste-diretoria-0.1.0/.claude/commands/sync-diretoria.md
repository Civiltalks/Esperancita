---
description: Empacota e empurra capturas pra inbox/{seu-slug}/ deste cérebro diretoria via quiz item-a-item COM GATES EXTRAS (3 gatilhos awareness, default privado, anonimização sugerida, varredura CPF/CNPJ, PR obrigatório, allowlist sócios). Detecta automaticamente modo cross-brain ou local. Substitui /save + /team-sync antigos. Sem triggers em linguagem natural.
---

Run the skill at `empresa/skills/sync-diretoria/SKILL.md`.
