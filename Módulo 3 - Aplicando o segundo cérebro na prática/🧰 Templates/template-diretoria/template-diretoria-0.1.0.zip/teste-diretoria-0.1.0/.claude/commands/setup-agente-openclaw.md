---
description: Configurar agente gestor da diretoria ({{AGENTE_NOME}}) em VPS/OpenClaw. 2 modos — NOVO ou MERGE. Consolidação SEMPRE abre PR (revisão humana obrigatória, propriedade deste repo).
---

Run the skill at `empresa/skills/setup-agente-openclaw/SKILL.md`.
