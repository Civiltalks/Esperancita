# MAPA — {{EMPRESA}} Second Brain (Diretoria)

## Função

Ponto de entrada pra navegar o cérebro sensível da diretoria.

## ⚠️ Este repo é sensível

Acesso restrito aos sócios. Todo conteúdo aqui dispara a regra dos 3 gatilhos: dinheiro nominal, pessoa específica, peso contratual/jurídico. **Na dúvida, não commite. Pergunte antes.**

## Dois cérebros disjuntos

Sua empresa opera com dois repositórios:

1. **Cérebro do time** (clonado do `template-second-brain-empresa`) — operacional. Acesso: todo o time.
2. **Este** (cérebro da diretoria) — sensível. Acesso: só sócios.

Ver [`empresa/contexto/ARQUITETURA.md`](empresa/contexto/ARQUITETURA.md).

## Áreas canônicas (4)

| área | escopo | agente executor |
|---|---|---|
| financeiro | fluxo de caixa, contas, obrigações fiscais, remuneração | {{AGENTE_NOME}} |
| rh | recrutamento, avaliações, conflitos, desligamentos | {{AGENTE_NOME}} |
| juridico | contratos, compliance, litígios, LGPD | {{AGENTE_NOME}}, com revisão humana obrigatória |
| governanca | decisões estratégicas, atas de board, relação com investidores | {{AGENTE_NOME}} |

## Estrutura

- `agentes/geral-diretoria/` — agente da diretoria (você renomeia se quiser)
- `empresa/` — princípios, arquitetura, segurança reforçada, skills gerais
- `areas/` — 4 áreas sensíveis
- `inbox/` — triagem (default: **privado**)

## Regra de ouro

Se uma captura não dispara nenhum dos 3 gatilhos, **ela não pertence a este repositório**. Mova pro cérebro do time.

---

*Template gerado pela Pixel Educação — Pixel AI Hub.*
