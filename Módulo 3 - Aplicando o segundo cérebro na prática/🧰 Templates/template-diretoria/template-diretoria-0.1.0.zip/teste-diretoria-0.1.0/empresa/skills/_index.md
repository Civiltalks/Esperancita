# Skills da Empresa — Índice (Diretoria)

> Skills transversais. Vivem em `empresa/skills/`.

## Ordem de uso após clonar o template

1. **`inicializar-cerebro`** — primeiro uso (preenche placeholders, renomeia pasta do agente). Tutorial + configurador.
2. **`setup-estacao-pessoal`** — você (diretor) cria sua `inbox/{slug}/` (default privado aqui).
3. **`setup-agente-openclaw`** — sobe o agente gestor desta diretoria em VPS 24/7 (modo NOVO ou MERGE).
4. Cria seu cérebro pessoal (3º repo, na sua conta GitHub pessoal) a partir de `template-second-brain-pessoal`. É onde você trabalha no dia a dia (com `/sync-pessoal` pra flush local) e distribui pros 2 coletivos via `/sync-empresa` (pessoal → empresa) e `/sync-diretoria` (pessoal → diretoria, com gates extras).
5. [Cada novo sócio-diretor] roda **`onboarding-diretor`** — wizard completo end-to-end que orquestra 2-4 (e explica o modelo + valida compreensão).

## Skills essenciais (vêm com o template)

| Skill | Quando usar |
|-------|-------------|
| `inicializar-cerebro` | **Primeiro uso** após clone do template. Tutorial + preenche placeholders + renomeia `agentes/geral-diretoria/` pro slug do seu agente + cria `.cerebro-inicializado`. Roda **UMA VEZ**. |
| `onboarding-diretor` | Wizard guiado **ponta-a-ponta** pra novo sócio-diretor. 11 passos: modelo dos 2 cérebros, 3 gatilhos detalhados, default privado, estações nos 2 repos, OpenClaw pessoal (modo NOVO/MERGE), validação final. ~30-40 min. Use quando: novo sócio entrando, diretor voltando de afastamento. |
| `setup-estacao-pessoal` | Skill **atômica** — cria `inbox/{sócio}/` com CLAUDE.md próprio. Default de privacidade é **privado**. Sem parte pedagógica — use direto se o diretor já sabe o modelo (senão use `onboarding-diretor`). |
| `setup-workstation` | Configura o layout LOCAL `~/{{EMPRESA_SLUG}}/` da pessoa — organiza repos (time/diretoria/pessoal) lado a lado + symlinks pra `/cerebro`, `/sync-empresa`, `/sync-diretoria`, `/sync-pessoal` etc. em `~/{{EMPRESA_SLUG}}/.claude/skills/`. Camada de **máquina local**, acima do escopo-repo das demais. |
| `cerebro` | Carrega em paralelo os `CLAUDE.md` dos cérebros presentes em `~/{{EMPRESA_SLUG}}/`. Espelho da skill canônica do cérebro do time (fonte canônica). Aqui pra consistência do catálogo — `setup-workstation` prefere a versão do time ao criar o symlink. |
| `setup-agente-openclaw` | Em VPS dedicado do agente da diretoria. Modo NOVO ou MERGE. **Consolidação sempre abre PR** (nunca promove direto) — propriedade deste repo. |
| `sync-diretoria` | Empacota e empurra capturas pro staging com quiz rigoroso. Cobre 2 modos: (1) **diretor cross-brain** (lê `~/{empresa}/pessoal/` e copia pra diretoria); (2) **diretor local** (lê inbox local não-commitado). Gates extras vs `/sync-empresa`: 3 gatilhos como awareness, default privado invertido, anonimização sugerida, varredura de dados sensíveis (CPF/CNPJ), PR obrigatório, allowlist sócios. Substitui `/save` + `/team-sync` antigos. Sem triggers em linguagem natural — invocação explícita pra evitar mandar pra repo errado. |
| `consolidar-estacoes` | Rotina noturna. **Na diretoria, sempre abre PR**, nunca promove direto (mesmo em `pronto-para-canonico`). |

## Skills por área

| Área | Índice |
|------|--------|
| Financeiro | [areas/financeiro/skills/_index.md](../../areas/financeiro/skills/_index.md) |
| RH | [areas/rh/skills/_index.md](../../areas/rh/skills/_index.md) |
| Jurídico | [areas/juridico/skills/_index.md](../../areas/juridico/skills/_index.md) |
| Governança | [areas/governanca/skills/_index.md](../../areas/governanca/skills/_index.md) |

## Templates

`_templates/SKILL-TEMPLATE.md` — base pra criar novas skills.

---

Adicione suas próprias skills em `empresa/skills/{nome}/SKILL.md` ou na área específica.
