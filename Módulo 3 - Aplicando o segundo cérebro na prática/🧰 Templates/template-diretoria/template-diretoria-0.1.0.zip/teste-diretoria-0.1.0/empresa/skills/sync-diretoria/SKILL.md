---
name: sync-diretoria
description: >
  Empacota capturas pro cérebro da diretoria via quiz item-a-item COM GATES EXTRAS.
  Cobre 2 modos: (1) DIRETOR cross-brain — lê do cérebro pessoal `~/{empresa}/pessoal/`
  e empurra pra inbox/{sócio}/ deste cérebro diretoria em staging; (2) DIRETOR local —
  lê inbox/{sócio}/ local não-commitado e commita em staging. Diferenças vs /sync-empresa:
  default privado invertido, anonimização sugerida, varredura de dados sensíveis
  (CPF/CNPJ/contratos), PR obrigatório na consolidação, allowlist de sócios.
---

# /sync-diretoria — Cérebro da Diretoria

> Empurra capturas pro cérebro diretoria via quiz item-a-item rigoroso. Substitui `/save` + `/team-sync` antigos. Cobre cross-brain (diretor) e flush local (diretor) numa skill só, com gates extras pra material sensível.

## ⚠️ Acesso restrito a sócios

Esta skill **só roda pra sócios da {{EMPRESA}}**. Verificação de identidade no Passo 0:

- `~/.cowork/{{EMPRESA_SLUG}}-diretoria-identity` deve existir
- Slug deve estar na allowlist (`empresa/contexto/SEGURANCA.md` define quem)
- Se falhar: skill aborta com mensagem _"acesso negado — só sócios"_

## 2 modos detectados automaticamente

| Modo | Quando | O que faz |
|---|---|---|
| **DIRETOR cross-brain** | `~/{{EMPRESA_SLUG}}/pessoal/` existe | Lê commits novos do pessoal → quiz rigoroso → copia pra `inbox/{sócio}/` deste diretoria em staging |
| **DIRETOR local** | Só `~/{{EMPRESA_SLUG}}/diretoria/` existe | Lê `inbox/{sócio}/` local não-commitado → quiz rigoroso → commita em staging |

**Sempre manual e item-a-item.** Default: não distribuir. **Default privado invertido**: a captura tende a ficar em `privado/` a não ser que o diretor confirme explicitamente que é compartilhável com toda a diretoria.

## Gates extras vs `/sync-empresa`

| Gate | `/sync-empresa` | `/sync-diretoria` |
|---|---|---|
| 3 gatilhos | Bloqueiam envio (vai pra diretoria) | **Disparam awareness** (sócio confirma item-a-item; alguns nem aqui devem ficar) |
| Default destino | público ao time | **privado/ por default** (sócio escolhe sair) |
| Anonimização | n/a | **Sugerida no quiz** (nome próprio → "Diretor X" quando possível) |
| Varredura de dados sensíveis | n/a | **Sim** — Claude scan procura CPF/CNPJ/valores/nomes completos antes de commitar |
| Consolidação | promoção direta possível | **PR obrigatório sempre** (mesmo `pronto-para-canonico`) |
| Allowlist | qualquer slug do time | **só sócios** (verifica `~/.cowork/...-identity`) |

## Quando usar

- Fim de expediente do diretor — distribuir o que produziu no pessoal que tem escopo-diretoria (3 gatilhos)
- Quando decidiu compartilhar algo específico com a diretoria imediatamente
- Capturas locais de governança/board/M&A/jurídico/RH/financeiro que vivem só aqui

## Quando NÃO usar

- Você é **{{AGENTE_NOME}}** (gestor deste cérebro) — escreve direto em canônico, não usa esta skill
- Material **não-sensível** que cabe no cérebro do time → use `/sync-empresa` (vive em `template-second-brain-empresa`)
- Material puramente pessoal — fica só no pessoal
- Você não é sócio com acesso à diretoria

## Princípios

1. **Interativa, não proativa.** Skill faz quiz item-a-item das capturas que o sócio **apresenta** (modo cross-brain: lê commits novos do pessoal; modo local: lê inbox local não-commitado). Skill NÃO escaneia menções da sessão pra perguntar "quer guardar URL X?" — esse comportamento proativo não existe aqui (alinhado com `/sync-pessoal`).
2. **Default conservador, ainda mais conservador que empresa.** Default do quiz é `[1] Privado` (`inbox/{sócio}/privado/`, gitignored uniforme — Cayo decisão item #4). Sai desse default só com confirmação explícita.
3. **Detecta antes de escrever (P11).** Pré-checagem no Passo 0 confirma identity de sócio (allowlist), `inbox/{slug}/` existe, branch `staging` ativa. Aborta limpo se falhar.
4. **3 gatilhos disparam awareness, não bloqueiam.** Diferente do empresa (que bloqueia 3 gatilhos), aqui sócio confirma item-a-item ciente do gate. Anonimização é oferecida (não obrigatória).
5. **Scan de dados sensíveis ANTES de commitar.** CPF/CNPJ/valores monetários/nomes completos disparam alerta. Default: bloqueia upload do conteúdo, só permite URL pra storage encriptado.
6. **PR obrigatório na consolidação** — mesmo `pronto-para-canonico` passa por PR. Propriedade do repo, não negociável.
7. **Allowlist de sócios.** `~/.cowork/{empresa}-diretoria-identity` checado antes de qualquer operação. Não-sócio: aborta.
8. **Read-only no pessoal** (modo cross-brain). Skill nunca edita ou deleta lá — só lê.
9. **Sem triggers LN.** `/sync-diretoria` exige invocação explícita pra evitar mandar pra repo errado.

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| `~/.cowork/{{EMPRESA_SLUG}}-diretoria-identity` existe com slug do sócio | `cat ~/.cowork/{{EMPRESA_SLUG}}-diretoria-identity` | Aborta com _"acesso negado — só sócios"_; sugere rodar `setup-estacao-pessoal` se for sócio legítimo |
| Slug está na allowlist documentada em `empresa/contexto/SEGURANCA.md` | grep no arquivo | Aborta; orientar admin (default {{FUNDADOR_1}}) a adicionar |
| `inbox/{slug}/` existe em `origin/staging` | `git ls-tree origin/staging:inbox/$SLUG` | Rodar `setup-estacao-pessoal` antes |
| Branch ativa é `staging` | `git branch --show-current` = `staging` | `git checkout staging` (criar com `-b` se não existir) |
| **Modo cross-brain:** `~/{{EMPRESA_SLUG}}/pessoal/` é repo git válido | `test -d $PESSOAL/.git` | Tratar como modo local (sem cross-brain) |
| Branch protection ativada em `main` (no GitHub) | `gh api repos/{org}/{repo}/branches/main/protection` | Avisar — sem isso a regra "PR obrigatório" só vale verbalmente |
| Hook `.githooks/pre-commit` aceita `PIXEL_BRAIN_COMMIT_OK=1` | Tentar commit | Aborta com mensagem clara |
| Storage encriptado configurado (drive 2FA) pra contratos/PDFs | Ver `empresa/contexto/SEGURANCA.md` | Avisar antes de aceitar capturas que mencionam contrato assinado |

## Ferramentas necessárias

- `Bash` — git log, copy, commit, push, scan
- `Read` / `Write` — gerar sidecar
- `Grep` — varredura de dados sensíveis
- (Modo cross-brain) Acesso de leitura ao cérebro pessoal

## Detecção de modo (passo 0)

```bash
SLUG=$(cat ~/.cowork/{{EMPRESA_SLUG}}-diretoria-identity 2>/dev/null) || {
  echo "acesso negado — só sócios. Configure via setup-estacao-pessoal."; exit 1;
}

# TODO no template: validar slug contra allowlist (empresa/contexto/SEGURANCA.md)

DIRETORIA="${DIRETORIA:-$(git rev-parse --show-toplevel)}"
PESSOAL="${PESSOAL:-$HOME/{{EMPRESA_SLUG}}/pessoal}"

test -d "$DIRETORIA/inbox/$SLUG" || { echo "inbox/$SLUG não existe"; exit 1; }

if [ -d "$PESSOAL/.git" ]; then
  MODO="cross-brain"
else
  MODO="local"
fi
```

---

## MODO CROSS-BRAIN — fluxo 8 passos

### 1. Validar contexto + allowlist

Já feito no passo 0. Confirmar `$PESSOAL` e `$DIRETORIA` apontam pra repos válidos. Se sócio não está na allowlist, abortar.

### 2. Identificar capturas novas no pessoal (git log diff)

Lê `.team-sync-log` na raiz do cérebro pessoal pra pegar último commit sincronizado. Filtra commits autônomos:

```bash
cd "$PESSOAL"
LAST_SYNCED=$(tail -1 .team-sync-log 2>/dev/null | awk '{print $2}')
RANGE="${LAST_SYNCED:+$LAST_SYNCED..HEAD}"
RANGE="${RANGE:---since=1.day.ago}"

git log $RANGE \
  --invert-grep \
  --grep='^sync: amora auto-commit' \
  --grep='^cases:' \
  --grep='^wiki: ingest' \
  --grep='^docs: index' \
  --name-only --diff-filter=AM --format= -- '*.md' '*.html' \
  | sort -u | grep -v '^$'
```

### 3. Quiz item-a-item COM AWARENESS DOS 3 GATILHOS

Pra cada arquivo, mostrar resumo + análise dos 3 gatilhos:

```
Arquivo: areas/governanca/contexto/decisoes/2026-04.md
Resumo: "Decisão do board sobre Apollo, meta Q3 R$500k. Cayo aprovou..."

3 gatilhos detectados:
  [X] Dinheiro com nome próprio (R$ 500k associado a "Cayo aprovou")
  [X] Pessoa específica ("Cayo")
  [ ] Peso contratual

Antes de subir pra diretoria, considere:
  1. Há nome próprio? Anonimizar → "Diretor X" em vez de "Cayo"?
  2. Há valor financeiro/dado contratual? Confirmar referencia URL, não documento original
  3. Esse item está claro pra TODA a diretoria? Se só alguns sócios participaram, marcar tag "parcial"

Onde esse conteúdo vai?
[1] Diretoria — privado/{slug}/ (default — fica local no laptop, gitignored, nunca sobe; é seu scratch space)
[2] Diretoria — público (todos sócios leem)
[3] Anonimizar e subir como público
[4] Só pessoal (não distribui)
[5] Ver conteúdo completo antes de decidir
```

Default: **[1] Privado** (na diretoria, default invertido). Sai do default só com confirmação explícita.

### 4. Varredura automática de dados sensíveis

Antes de commitar, Claude faz scan rápido do conteúdo procurando padrões:

```bash
# Padrões sensíveis (regex aproximado)
grep -E '[0-9]{3}\.[0-9]{3}\.[0-9]{3}-[0-9]{2}|[0-9]{2}\.[0-9]{3}\.[0-9]{3}/[0-9]{4}-[0-9]{2}|R\$ ?[0-9]+\.?[0-9]*|[A-Z][a-z]+ [A-Z][a-z]+' "$arquivo"
```

Se encontrar:

> _"⚠️ Detectei 'CPF 123.456.789-00' no arquivo X. Dados pessoais (CPF, RG) **nunca** vão pro canônico, nem na diretoria — só URL pra storage encriptado. Quer editar? [editar/subir mesmo assim/cancelar]"_

### 5. Copiar pro inbox + gerar sidecar com flag de revisão

```bash
DEST_DIR="$DIRETORIA/inbox/$SLUG"
[ "$ESCOLHA" = "privado" ] && DEST_DIR="$DEST_DIR/privado"
DEST="$DEST_DIR/$(date +%Y-%m-%d-%H%M)-$(basename $arquivo)"
cp "$PESSOAL/$arquivo" "$DEST"
```

Sidecar:

```yaml
autor: {{slug-do-sócio}}
data: 2026-04-28T18:32
fonte: sync-diretoria
tipo: proposta-canonica         # default na diretoria — sempre passa por PR
maturidade: draft
destino_sugerido: areas/{area}/contexto/{arquivo}.md
revisao_humana_obrigatoria: true   # SEMPRE true na diretoria
anonimizado: false                  # ou true se passou pela opção [3]
relacionado:
  - pessoal:areas/governanca/contexto/decisoes/2026-04.md
tags: [sync-diretoria, governanca]
```

### 6. Quiz opcional de destino canônico

Por item, pergunta rápida (Enter pra pular):

> _"Sugerir destino canônico? (ex: `areas/governanca/contexto/decisoes/2026-04.md`) ou deixa a consolidação decidir? [Enter]"_

### 7. Commit + push em staging

```bash
cd "$DIRETORIA"
git fetch origin
git checkout staging
git pull --rebase origin staging
PIXEL_BRAIN_COMMIT_OK=1 git add "inbox/$SLUG/"
PIXEL_BRAIN_COMMIT_OK=1 git commit -m "sync-diretoria: $SLUG ({N} capturas)"
git push origin staging
```

**`git add` só de `inbox/$SLUG/`** — nunca `git add -A` ou `git add .`.

A env var `PIXEL_BRAIN_COMMIT_OK=1` é exigida pelo `.githooks/pre-commit` (se configurado).

### 8. Atualizar `.team-sync-log` no pessoal

```bash
cd "$PESSOAL"
echo "$(date -Iseconds) $(git rev-parse HEAD)" >> .team-sync-log
git add .team-sync-log
git commit -m "sync-diretoria: marca ultimo sync ($(date +%Y-%m-%d))"
git push origin main
```

---

## MODO LOCAL — fluxo 6 passos

### 1. Listar capturas locais não commitadas

```bash
cd "$DIRETORIA"
git status --short "inbox/$SLUG/"
```

Lista arquivos `A`, `M`, `??` em `inbox/$SLUG/`. **`privado/` é gitignored uniforme** (decisão Cayo) — nem aparece no `git status`, fica só no filesystem local.

### 2. Quiz item-a-item COM AWARENESS DOS 3 GATILHOS

Igual ao Modo cross-brain Passo 3: detecta 3 gatilhos, sugere anonimização, oferece privado vs público.

### 3. Varredura automática de dados sensíveis

Igual ao Passo 4 do Modo cross-brain.

### 4. Sidecar obrigatório com flag de revisão

Toda captura sai com `revisao_humana_obrigatoria: true` no sidecar — propriedade do repo, não negociável.

### 5. Commit + push em staging

```bash
cd "$DIRETORIA"
git fetch origin
git checkout staging
git pull --rebase origin staging

# adiciona só os confirmados, paths explícitos
for arquivo in $confirmados; do
  PIXEL_BRAIN_COMMIT_OK=1 git add "$arquivo" "${arquivo}.meta.yaml" 2>/dev/null
done

PIXEL_BRAIN_COMMIT_OK=1 git commit -m "sync-diretoria: $SLUG ({N} capturas)"
git pull --rebase origin staging
git push origin staging
```

### 6. Confirmação

> _"✅ sync-diretoria completo._
> _- {N} capturas publicadas em staging (default privado, salvo se você marcou público)_
> _- {M} capturas mantidas local (não confirmadas)_
> _- {K} capturas bloqueadas por dados sensíveis (CPF/CNPJ detectados)_
> _- **Todas terão PR com revisão humana** na consolidação noturna (02:00 BRT)"_

---

## Confirmação final (qualquer modo)

```
✅ sync-diretoria completo

  Modo: {cross-brain | local}
  → {N} capturas enviadas pra diretoria (inbox/{slug}/ ou inbox/{slug}/privado/ em staging)
  → {M} capturas mantidas só pessoal (não distribuídas)
  → {K} capturas bloqueadas por dados sensíveis

  Próxima consolidação: ~02:00 BRT pelo {{AGENTE_NOME}}.
  Todas as promoções abrirão PR pra revisão humana — inclusive 'pronto-para-canonico'.
```

## Regras duras

- **Só Markdown e HTML** são copiados. Outros formatos viram URL no MD.
- **Default privado invertido** — captura tende a ir pra `privado/` a não ser que sócio confirme público.
- **Anonimização sugerida** — quiz oferece "Diretor X" no lugar do nome próprio.
- **Varredura de dados sensíveis** — Claude scan antes de commitar; CPF/CNPJ/valores monetários/nomes completos disparam alerta.
- **Sidecar obrigatório com `revisao_humana_obrigatoria: true`** — sempre.
- **PR obrigatório na consolidação** — mesmo `pronto-para-canonico` passa por PR.
- **Allowlist de sócios** — verifica identity antes de rodar.
- **Commit exige `PIXEL_BRAIN_COMMIT_OK=1`** (se hook configurado).
- **`git add` com paths explícitos** — nunca `.` ou `-A`.
- **Read-only no cérebro pessoal** (modo cross-brain). Skill nunca edita ou deleta lá.
- **Sem triggers em linguagem natural** — `/sync-diretoria` exige invocação explícita pra evitar mandar pra repo errado.

## Variações conhecidas

| Cenário | Como o agente adapta |
|---|---|
| Sócio fundador (default `{{FUNDADOR_1}}`) | Modo cross-brain quando tem pessoal lado a lado; modo local caso contrário |
| Sócio adicional (CTO, COO etc.) | Idem, mas verificar allowlist em SEGURANCA.md primeiro |
| Aluno tenta `/sync-diretoria` sem ser sócio | Aborta com mensagem clara: _"acesso restrito a sócios. Fala com {{FUNDADOR_1}} se acha que devia ter acesso."_ |
| `.team-sync-log` não existe (1ª vez) | Default: capturas das últimas 24h. Cria após primeiro sync |
| Captura menciona valor monetário (R$, USD) | Scan automático detecta; quiz oferece anonimização ou bloqueio |
| Captura menciona CPF/CNPJ | Scan automático bloqueia; orienta usar URL pra storage encriptado |
| Captura menciona nome próprio de sócio/funcionário | Quiz oferece [3] "anonimizar e subir" — substitui por "Diretor X" / "Funcionário Y" |
| Captura é decisão de board já tomada | Default `tipo: proposta-canonica` no sidecar; vai pra PR mesmo |
| Captura é rascunho de contrato | Bloqueia upload do conteúdo; só URL de storage encriptado |
| Sem cérebro empresa configurado | Skill ignora — opera só pessoal ↔ diretoria |
| Sócio em outra timezone | Sync funciona normal; consolidação noturna é 02:00 BRT, então sócios fora do BR podem ver delay |
| Múltiplos sócios em sessões paralelas | Cada um opera seu `inbox/{slug}/`; sem colisão |
| Pasta `privado/` tem material que sócio quer subir | Quiz pergunta caso a caso: _"esse aqui sai do privado/ pra inbox público da diretoria?"_ |
| Sócio recém-aprovado mas sem acesso ao GitHub | Aborta no `git push`; orienta {{FUNDADOR_1}} adicionar ao Org |

## Quando algo não funciona

| Sintoma | Causa provável | O agente deve |
|---|---|---|
| `acesso negado — só sócios` | Identity ausente OU slug não na allowlist | Verificar `~/.cowork/{empresa}-diretoria-identity`; orientar contato com `{{FUNDADOR_1}}` |
| `inbox/$SLUG não existe` | `setup-estacao-pessoal` não rodou no diretoria ainda | Oferecer rodar agora |
| `error: src refspec staging does not match any` | Branch local não é staging ou remote sem branch | `git checkout -b staging && git push -u origin staging` |
| Push falha com `protected branch` | Tentou push em `main` (deveria ser `staging`) | Sempre `staging`; promoção pra main é via PR pela consolidação |
| Hook bloqueia commit | Falta `PIXEL_BRAIN_COMMIT_OK=1` no env | Set env var; orientar |
| Scan detecta CPF/CNPJ | Material com dado pessoal tentando ir pro git | Bloqueia; orienta substituir por URL pra storage encriptado |
| Scan detecta valor monetário grande | Pode ser sensível dependendo do contexto | Avisa + pergunta antes de subir |
| Quiz rejeitou tudo (default privado) | Comportamento esperado | Confirma com sócio: _"5 capturas mantidas em privado/ (gitignored). OK assim ou alguma específica vai pra público?"_ |
| Captura referencia contrato físico | Tentativa de subir documento sensível | Bloqueia upload; só permite link |
| Branch protection não ativada | Setup incompleto no GitHub | Avisar — PR obrigatório só vale verbalmente sem isso. Apontar URL: `github.com/{org}/{repo}/settings/branches` |
| `git log` no pessoal vazio (cross-brain) | Cérebro pessoal sem commits novos | Mensagem: _"Nada novo no pessoal pra distribuir. /sync-pessoal recentemente?"_ |
| Sócio quer descartar captura subida indevidamente | Material vazou pra staging | Não há revert auto; orientar PR de remoção pra mainshow + `git filter-branch` em casos extremos (envolver Cayo) |

## Adaptando pra realidade do usuário

Se o setup do sócio diverge do esperado, leia esta seção e converse antes de forçar:

- **Empresa só com 1 sócio** — `/sync-diretoria` ainda faz sentido (para isolar material sensível das outras pessoas que entrarem no time). Mas sócio único pode achar PR-required excessivo. Respeitar; adaptar `revisao_humana_obrigatoria` pode ser opção (mas custa governança futura).
- **Sócio sem familiaridade com git** — quiz é mais importante que nunca. Não pressupor que sócio entende `staging` vs `main`. Mensagens de confirmação devem usar linguagem natural ("sua revisão fica no rascunho coletivo da diretoria — vai pro oficial só depois de outro sócio aprovar").
- **Sócio em VPS via OpenClaw** — agente OpenClaw da diretoria (Atena, Aurora) **não roda `/sync-diretoria`**. Decisão Cayo. Se sócio pergunta como fazer via Telegram, explicar: "vai precisar abrir Claude Code no laptop pra rodar, ou Pixel pode oferecer concierge."
- **Material que mistura empresa + diretoria** (ex: estratégia que envolve P&L) — sugerir fragmentar: parte pública vai pra empresa via `/sync-empresa`; parte com nome próprio fica privada via `/sync-diretoria`.
- **Sócio com contrato pra fechar agora** — agente não acelera nem opina. Apenas posiciona: "esse contrato é peso jurídico, vai pra inbox/{slug}/privado/. Quando assinar, atualizar URL pro storage encriptado e referenciar aqui."
- **Captura grande e estruturada** (relatório, ata) — quebrar por seção; cada seção vai com seu sidecar e `destino_sugerido` apropriado. Evitar 1 arquivo monolítico que mistura múltiplos contextos.

## Interação com outras skills

| Skill | Relação |
|---|---|
| `setup-estacao-pessoal` | Pré-requisito. Estação tem que existir antes. |
| `consolidar-estacoes` | Consumidora. PR obrigatório pra promover. |
| `/sync-pessoal` (template-pessoal) | Skill irmã no cérebro pessoal — flush local lá. |
| `/sync-empresa` (template-empresa) | Skill irmã pra material **não-sensível**. |
| `/cerebro` | Pré-requisito multi-brain. Carrega CLAUDE.md dos 3 cérebros. |

## Notas

- **Substitui:** `/save` (filesystem-only) + `/team-sync` (publish git) antigos. A separação save→team-sync deixou de existir; a única skill `/sync-diretoria` faz quiz rigoroso e commit no mesmo passo.
- **Triggers em linguagem natural:** **NÃO**. Decisão Bruno 02/05 — só `/sync-pessoal` aceita LN. Cross-brain (`/sync-empresa`, `/sync-diretoria`) exige invocação explícita.
- **Modo automático OpenClaw:** rejeitado por Cayo no review 23/04 (item #3). OpenClaw não roda `sync-*` cross-brain.
- **Privacidade:** `inbox/{sócio}/privado/` é **gitignored uniforme nos 3 cérebros** (decisão Cayo review 23/04 item #4). Privado é scratch space local — nunca sobe pro git. Sócio que precisa sincronizar scratch entre máquinas usa o cérebro pessoal dele (clone separado, conta GitHub pessoal).
- **Override de paths:** `PESSOAL=/path/customizado` ou `DIRETORIA=/path/customizado` via env var.
