---
name: cerebro
description: Carrega em paralelo os CLAUDE.md dos cérebros presentes em `~/{{EMPRESA_SLUG}}/` (time, diretoria, pessoal — o que estiver lá). Use no INÍCIO de cada sessão aberta na pasta-mãe `~/{{EMPRESA_SLUG}}/`, porque Claude Code só auto-carrega o CLAUDE.md do cwd e pastas pai, não desce em subpastas.
---

# /cerebro — Carregar contexto dos cérebros em `~/{{EMPRESA_SLUG}}/`

> **Limitação real do Claude Code** que a skill resolve: ele só lê automaticamente o `CLAUDE.md` do diretório atual e pastas pai. Quando a sessão abre em `~/{{EMPRESA_SLUG}}/` (pasta-mãe), os `CLAUDE.md` dos cérebros irmãos (subpastas) **não** são lidos. Esta skill corrige em 1 turno, N reads paralelos.

## Quem precisa

**Sócios-diretores** que operam na pasta-mãe `~/{{EMPRESA_SLUG}}/` com os 3 cérebros irmãos (time, diretoria, pessoal). A skill carrega os 3 em paralelo.

Esta cópia da skill vive no cérebro da diretoria pra garantir que `/cerebro` esteja disponível mesmo se a sessão for aberta de dentro do repo da diretoria. O `setup-workstation` prefere a cópia do cérebro do time quando cria o symlink em `~/{{EMPRESA_SLUG}}/.claude/skills/cerebro/` (fonte canônica é o time — esta é espelho).

## O que faz

1. Detecta pastas filhas de `~/{{EMPRESA_SLUG}}/` que sejam repos git com `CLAUDE.md` na raiz:
   ```bash
   for d in "$HOME/{{EMPRESA_SLUG}}/"*/; do
     [ -f "$d/CLAUDE.md" ] && [ -d "$d/.git" ] && echo "$d"
   done
   ```
2. Lê o `CLAUDE.md` de cada um **em paralelo** (1 turno, N tool calls `Read` simultâneos).
3. Confirma em **1 linha curta** quais carregaram. Exemplo:

   > 3 cérebros carregados: {{AGENTE_PESSOAL_NOME}} (pessoal), {{AGENTE_TIME_NOME}} (time), {{AGENTE_DIRETORIA_NOME}} (diretoria).

   Se algum falhou:

   > 2/3 cérebros carregados: {{AGENTE_DIRETORIA_NOME}} ✓, {{AGENTE_TIME_NOME}} ✓, pessoal ✗ (não encontrado).

## Quando rodar

- **Primeiro turno** de toda sessão aberta em `~/{{EMPRESA_SLUG}}/` (pasta-mãe)
- **Depois de `/clear`** ou compactação — o contexto dos cérebros foi descartado, precisa recarregar
- Quando alguém pergunta algo que pode envolver outro cérebro e você não tem certeza do conteúdo atual dele

## O que NÃO faz

- Não faz `git pull` — pra sincronizar com remoto, rodar manualmente.
- Não distribui capturas — pra isso, `/sync-empresa` ou `/sync-diretoria` (skills que vivem nos respectivos repos coletivos).
- Não persiste sessão pessoal — pra isso, `/sync-pessoal` (alias `/save`, ou linguagem natural: "salva", "guarda", "comita").
- Não executa nenhuma rotina de agente (consolidação etc).

## Paths esperados

Default: `$HOME/{{EMPRESA_SLUG}}/{nome-do-cerebro}/CLAUDE.md`

Cérebros esperados em ambiente :
- `$HOME/{{EMPRESA_SLUG}}/empresa/CLAUDE.md` — time (agente: {{AGENTE_TIME_NOME}})
- `$HOME/{{EMPRESA_SLUG}}/diretoria/CLAUDE.md` — diretoria (agente: {{AGENTE_DIRETORIA_NOME}})
- `$HOME/{{EMPRESA_SLUG}}/pessoal/CLAUDE.md` — pessoal de cada diretor

## Relação com outras skills

| Skill | Quando roda | Papel |
|-------|-------------|-------|
| `setup-workstation` | **1x por máquina** | Monta `~/{{EMPRESA_SLUG}}/` + symlinks das slash commands |
| `/cerebro` | **Início de toda sessão** | Carrega `CLAUDE.md` dos cérebros |
| `/sync-pessoal` | Fim de sessão / checkpoint (LN: "salva", "guarda") | Flush buffer → cérebro pessoal |
| `/sync-empresa` | Quando quer publicar pra empresa | Pessoal → empresa (ou flush local empresa pra funcionário) |
| `/sync-diretoria` | Quando quer publicar pra diretoria | Pessoal → diretoria, com gates extras |

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| Sessão Claude Code aberta na pasta-mãe `~/{empresa}/` | `pwd` retorna o path da pasta-mãe | Avisa: skill é no-op se cwd é um repo só. Sugere abrir em `~/{empresa}/` |
| Pelo menos 1 cérebro existe como subpasta | `ls ~/{empresa}/` lista `pessoal/`, `empresa/` ou `diretoria/` | Sugere clonar template apropriado e rodar `inicializar-cerebro` |
| Cada subpasta detectada tem `CLAUDE.md` | `test -f ~/{empresa}/{tipo}/CLAUDE.md` | Avisa qual cérebro não foi inicializado |
| Permissão de leitura nos arquivos | `cat <arquivo>` funciona | Reporta path com erro; segue com os que conseguiu ler |

## Variações conhecidas

| Cenário | Como o agente adapta |
|---|---|
| Sócio com 3 cérebros lado a lado | Caso canônico — carrega 3 em paralelo |
| Sócio com `pessoal/` + `diretoria/` (sem `empresa/`) | Carrega 2; reporta "2/3 cérebros carregados, empresa ✗ (não clonado)" |
| Sessão aberta dentro de uma subpasta (ex: `~/{empresa}/diretoria/`) | Skill detecta e avisa: _"vc tá em diretoria/, não em ~/{empresa}/. /cerebro é mais útil na pasta-mãe — quer que eu suba e leia?"_ |
| Layout não-canônico (clones em paths diferentes) | Tenta env vars `BRAIN_PESSOAL`/`BRAIN_EMPRESA`/`BRAIN_DIRETORIA`. Se ausentes, pergunta paths |
| Sessão recém-compactada | Carregamento perde contexto — rodar `/cerebro` de novo é prática recomendada |

## Quando algo não funciona

| Sintoma | Causa provável | O agente deve |
|---|---|---|
| `Permission denied` ao ler `CLAUDE.md` da diretoria | Sócio sem acesso ao repo (ou GitHub Org não configurado) | Reportar; orientar contatar `{{FUNDADOR_1}}` |
| `CLAUDE.md` existe mas é template upstream (com `{{...}}`) | `inicializar-cerebro` não rodou naquele cérebro | Avisa e oferece rodar agora |
| Subpasta é symlink quebrado | Setup workstation criou symlink mas alvo sumiu | Reportar path quebrado; sugerir reclone ou re-setup |
| 0 cérebros carregados | Pasta-mãe vazia ou cwd errado | Avisa cwd, lista subpastas, sugere clonar |
| Sócio acessa diretoria de máquina não autorizada | Identity ausente em `~/.cowork/` | Diretoria carrega CLAUDE.md, mas `/sync-diretoria` posterior vai bloquear. Avisar agora pra evitar surpresa |

## Adaptando pra realidade do usuário

- **Sócio em laptop pessoal vs corporativo** — `/cerebro` lê arquivo, não toca em git. Funciona mesmo sem permissão de push. Mas avisa: ações posteriores (sync, consolidar) vão exigir permissões.
- **Sócio recém-aprovado** — pode não ter clonado todos os 3 ainda. Skill carrega o que tem; sugere clonar o que falta.
- **Setup customizado** — aceitar env vars `BRAIN_PESSOAL`, `BRAIN_EMPRESA`, `BRAIN_DIRETORIA` e gravar em `~/.cerebro-paths` pra próxima sessão.
- **Cliente Pixel com múltiplas empresas** (consultor com diretoria em várias) — skill opera em 1 pasta-mãe por sessão. Pra outra empresa, fechar e abrir nova sessão.

---

*Espelho da skill canônica do cérebro do time. Mantida aqui pra consistência do catálogo.*
