---
name: [nome-da-skill]
description: >
  [Descrição curta do que a skill faz. 1-2 frases.
  Incluir palavras-chave que o agente usa pra identificar quando ativar.]
---

# [Nome da Skill]

## O que faz
[Descrição clara do que essa skill entrega]

## Quando usar
[Em que situação o agente deve ativar essa skill. Ex: "Quando alguém pedir relatório de vendas"]

## Ferramentas necessárias
- [Ferramenta/API 1] — [como acessar]
- [Ferramenta/API 2] — [como acessar]

## Passo a passo

1. [Primeiro passo]
2. [Segundo passo]
3. [Terceiro passo]

## Output esperado

```
[Formato da resposta — exemplo de como o resultado deve ser apresentado]
```

## Notas
- [Limitações, edge cases, cuidados]
