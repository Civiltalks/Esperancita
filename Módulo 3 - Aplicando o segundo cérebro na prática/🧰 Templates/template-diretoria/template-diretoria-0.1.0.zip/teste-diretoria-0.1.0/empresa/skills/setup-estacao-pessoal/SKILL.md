---
name: setup-estacao-pessoal
description: >
  Configura a estação pessoal de trabalho de uma pessoa no Pixel Second Brain.
  Ativar no primeiro uso do Claude Code / Cowork na raiz do repositório, quando
  ainda não existe inbox/{nome}/ para a pessoa.
  Palavras-chave: primeira vez, setup, estação pessoal, onboarding, inbox pessoal.
---

# setup-estacao-pessoal

## O que faz

Cria a estação pessoal de uma pessoa dentro do Pixel Second Brain. Gera a pasta `inbox/{nome}/` com `CLAUDE.md` e `README.md` personalizados, deixa `privado/` pronta, e faz o primeiro commit na branch `staging`.

## Quando usar

Três situações:

1. **Primeira vez no repositório (sem identidade local).** `~/.cowork/pixel-identity` não existe. Perguntar, criar, salvar, pushar.
2. **Identidade local existe mas pasta remota não.** Ex: pessoa clonou o repo numa máquina nova, ou a pasta foi removida por acidente. Modo "recuperar": recria `inbox/{slug}/` a partir de `_TEMPLATE/` usando a identidade já salva, sem perguntar de novo.
3. **Adicionar nova pessoa ao time.** Rodar manualmente pra configurar a estação de um novo membro.

## Como saber se é a primeira vez (fonte de verdade)

A "fonte de verdade" de que a pessoa já fez o setup é **a combinação** de dois sinais:

| Sinal | Onde mora | O que significa |
|---|---|---|
| `~/.cowork/pixel-identity` | Arquivo local na máquina do usuário, fora do repo | "Esta máquina já foi configurada — o slug é X" |
| `inbox/{slug}/` | Pasta no repo, em `origin/staging` | "Esta pessoa tem estação no repo da Pixel" |

Matriz de decisão:

- **ambos existem** → já está configurado, seguir sessão normal
- **só arquivo local existe** → pasta foi perdida no remoto (raro); rodar modo "recuperar"
- **só pasta remota existe** → máquina nova; pular pergunta de identidade (descobrir slug perguntando ao usuário curtinho: "você é o X?"), salvar arquivo local, continuar
- **nenhum existe** → primeira vez de verdade; fluxo completo

Nunca confiar só na pasta remota: em Cowork, mesmo usuário pode ter várias máquinas, e cada máquina precisa do arquivo local pra saber qual estação é dela sem perguntar todo dia.

## Ferramentas necessárias

- `Bash` — criar pastas, rodar git
- `Read` / `Write` — ler templates e escrever arquivos personalizados

## Passo a passo

### 1. Detectar se já existe estação para a pessoa

```bash
ls inbox/ | grep -v _TEMPLATE
```

Se já existe `inbox/{nome}/` para essa pessoa, parar aqui e seguir pra sessão normal.

### 2. Coletar identidade (pergunta ao usuário)

Perguntar diretamente ao usuário:

- "Primeira vez aqui — como você quer ser identificado? (nome curto, lowercase, sem acento — ex: `{{SEU_SLUG}}`, `{{MEMBRO_EQUIPE_SLUG}}`, `{{FUNDADOR_2_SLUG}}`)"
- "Qual seu papel na Pixel?"
- "Em quais projetos você está ativo hoje?"
- "Alguma preferência de captura? (idioma default, estilo de notas, nível de detalhe)"

Guardar as respostas.

### 3. Criar a estrutura

```bash
NOME="<slug da pessoa>"
mkdir -p "inbox/${NOME}/privado"
```

### 4. Gerar `inbox/{nome}/CLAUDE.md` a partir do template

Ler `inbox/_TEMPLATE/CLAUDE.md` e substituir:

- `{nome}` → slug escolhido (ex: `{{SEU_SLUG}}`)
- `{email}` → email do usuário, quando disponível
- `{area}` / `{papel}` / `{projetos}` → respostas da etapa 2

Escrever em `inbox/${NOME}/CLAUDE.md`.

### 5. Gerar `inbox/{nome}/README.md` a partir do template

Ler `inbox/_TEMPLATE/README.md` e substituir `{nome}` pelo slug. Escrever em `inbox/${NOME}/README.md`.

### 6. Garantir branch `staging`

```bash
git fetch origin
git checkout staging 2>/dev/null || git checkout -b staging origin/staging
git pull --rebase origin staging
```

Se `staging` não existe no remoto, criar a partir de `main`:

```bash
git checkout -b staging main
git push -u origin staging
```

### 7. Primeiro commit da estação

```bash
git add "inbox/${NOME}/"
git commit -m "setup: estação pessoal de ${NOME}"
git pull --rebase origin staging
git push origin staging
```

Note: `inbox/${NOME}/privado/` está no `.gitignore` da raiz, então não vai pro servidor — correto.

### 8. Registrar identidade local

Salvar em `~/.cowork/pixel-identity` (arquivo local, fora do repo) o slug da pessoa. Nas próximas sessões, o Claude lê esse arquivo e já sabe qual estação é a da pessoa, sem perguntar de novo.

```bash
mkdir -p ~/.cowork
echo "${NOME}" > ~/.cowork/pixel-identity
```

### 9. Confirmação

Responder ao usuário com resumo curto:

- Estação criada em `inbox/{nome}/`
- Push feito em `staging`
- Identidade salva localmente
- "Tudo que você capturar nesta e nas próximas sessões vai pra sua estação (conteúdo `.{ext}` + sidecar `.meta.yaml` ao lado) e sobe pra staging em tempo real. O {{AGENTE_NOME}} consolida de madrugada."

## Output esperado

```
✓ Estação pessoal criada: inbox/{{SEU_SLUG}}/
✓ CLAUDE.md e README.md personalizados
✓ Branch staging sincronizada
✓ Primeiro commit enviado: "setup: estação pessoal de {{SEU_SLUG}}"
✓ Identidade salva em ~/.cowork/pixel-identity
```

## Notas

- Slug da pessoa é case-sensitive no path mas sempre lowercase por convenção.
- Se o usuário já tem slug configurado em `~/.cowork/pixel-identity` mas a pasta `inbox/{slug}/` não existe no repo, é possível que ele esteja trabalhando num clone novo — nesse caso, só fazer `git pull` resolve. Só rodar setup completo se realmente não existe a pasta nem no remoto.
- Esta skill **não** é idempotente para a etapa de perguntas — se já existe estação, sair cedo em vez de sobrescrever identidade.
