---
name: onboarding-diretor
description: Wizard guiado ponta-a-ponta pra um novo sócio-diretor entrando no sistema dos 2 cérebros. Ensina modelo + regras específicas da diretoria (3 gatilhos, default privado invertido, revisão humana obrigatória), cria estação pessoal nos 2 repos (time + diretoria), detecta se o diretor já tem OpenClaw pessoal próprio e invoca `setup-agente-openclaw` no modo certo (NOVO ou MERGE). Valida que o diretor entendeu tudo antes de encerrar. Use quando: novo sócio entrando, diretor voltando de afastamento, ou migração de sistema anterior.
---

# Onboarding Diretor

> Skill orquestradora pedagógica pra **sócio-diretor novo**. Invoca em sequência `setup-estacao-pessoal` (2x — uma em cada repo) e `setup-agente-openclaw` (com modo adequado). É **mais longa** que o onboarding do time porque cobre 2 cérebros + agente pessoal.

## Quando usar

- Novo sócio-diretor entrando (após addendum de confidencialidade assinado)
- Sócio existente que nunca operou o cérebro da diretoria (migração)
- Quando o humano é claramente diretor e pede: _"como funciona?"_

## Quando **não** usar

- Pessoa é **membro de time** (não diretor) → use `onboarding-membro-time` no repo do time
- Diretor já tem estações nos 2 repos e só quer capturar → abrir Claude e capturar
- Só quer uma das skills atômicas (setup-estacao ou setup-openclaw) → invocar direto

## Pré-condições

- [ ] Diretor já tem **acesso GitHub** aos 2 repos (`{{EMPRESA_SLUG}}-second-brain` + `{{EMPRESA_SLUG}}-diretoria`) com permissão "Write"
- [ ] Diretor já **clonou os 2 repos** localmente (ou será orientado a clonar no fluxo)
- [ ] [Opcional mas recomendado] Addendum de confidencialidade assinado

## Fluxo — 11 passos

### Passo 1 — Boas-vindas + identificação

Pergunte:

- Nome do diretor
- Slug preferido (ex: `cayo`, `ana-s`) — será o mesmo nos 2 repos
- Papel formal (CEO, COO, etc.)
- Email corporativo

Salve pra personalizar os próximos passos.

Diga:

> _"Bem-vindo à diretoria da {{EMPRESA}}. Você vai operar em **dois cérebros** — o do time (operacional, visível pra empresa toda) e este (sensível, só diretores). Vou te guiar em ~30-40 min: explicação do modelo, criar suas estações nos 2 repos, e conectar seu OpenClaw pessoal (se tiver). Prefere agora ou depois?"_

### Passo 2 — O que é "cérebro" + modelo dos 2 cérebros

Explique (mais denso que o onboarding do time, porque diretor precisa entender os 2):

- **Cérebro** = repo Git, fonte canônica. Substitui Notion/Drive pra conhecimento durável.
- **Dois repos disjuntos:**
  - `{{EMPRESA_SLUG}}-second-brain` — time, operacional, acesso a todos do time
  - `{{EMPRESA_SLUG}}-diretoria` — sensível, **só diretores**
- Nenhum conteúdo aparece nos dois. O que vai pra onde é definido pela **regra dos 3 gatilhos** (veremos no Passo 4).
- **Agentes:**
  - `{{AGENTE_TIME_NOME}}` é o gestor do cérebro do time
  - `{{AGENTE_NOME}}` é o gestor deste (diretoria)
  - Os dois **não compartilham contexto** — memória disjunta, propositalmente
- Você (diretor) é o **ponto de ponte** humana entre os 2 quando algo precisa atravessar

Pergunte: _"Entendeu o modelo dos 2 cérebros?"_

### Passo 3 — Seu papel: visitante dos 2

Explique:

- Você é **visitante** do canônico em ambos — nunca edita `empresa/`, `areas/`, `agentes/` direto
- Em cada repo, captura em `inbox/{seu-slug}/`
- Branch de trabalho em ambos = **`staging`**
- **Especificidade da diretoria:** promoção pra `main` neste repo sempre passa por PR (revisão humana obrigatória), mesmo pra `pronto-para-canonico`. No time, a consolidação pode promover direto.

### Passo 4 — Regra dos 3 gatilhos (detalhada)

O diretor **precisa** saber isso na ponta da língua — é o que decide em qual repo cada coisa vai:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual, pró-labore, dívida nominal
2. **Pessoa específica** — avaliação, feedback nominal, conflito entre pessoas, contratação em andamento, desligamento
3. **Peso contratual / jurídico** — contratos assinados, NDAs, litígios, LGPD, compliance

Qualquer dos 3 → **cérebro da diretoria** (este).

Se não dispara nenhum → cérebro do time.

Exemplos práticos:

| captura | onde? | gatilho |
|---|---|---|
| "Campanha Dia das Mães fechou ROAS 3x" | time | nenhum (agregado) |
| "Ana fechou R$ 45k em abril" | diretoria | 1 (dinheiro + nome) |
| "Bruno teve conflito com Carla" | diretoria | 2 (pessoa específica) |
| "Contrato com Empresa Y assinado" | diretoria | 3 (contratual) |
| "Vendas do time bateram R$ 200k" | time | nenhum (agregado) |
| "Comissão do time em abril = 8%" | time | nenhum (política, sem nome) |

Rodar 3-5 exercícios com ele **inventando** casos do dia a dia dele e pedir classificação. Não avançar até acertar consistentemente.

### Passo 5 — Privacidade: default invertido

**Importante que o diretor entenda a diferença:**

- **No cérebro do time** — default é **público**. Sua captura em `inbox/{slug}/` fica visível pro time inteiro. Pra marcar privado, vai em `inbox/{slug}/privado/` (gitignored).
- **Neste cérebro (diretoria)** — default é **privado**. Captura vai em `inbox/{slug}/privado/` por padrão. Só sai pra público (da estação) quando é claramente compartilhável com toda a diretoria.

Mesmo no `privado/`, consolidação **não processa** — isso nunca sobe pro canônico, mesmo que seja do seu interesse. Privado é seu workspace pessoal.

Pergunte: _"Entendeu que aqui errar no lado 'privado' é mais seguro que no 'público'?"_

### Passo 6 — Regras duras (comuns aos 2 repos)

1. **Sidecar `.meta.yaml` obrigatório** em toda captura
2. **`git add inbox/{seu-slug}/` sempre** — nunca `-A` ou `.`
3. **Branch: staging** — nunca commitar em main direto
4. **Anonimização quando possível** — mesmo aqui, "Diretor X" > "Cayo" se nome não for essencial

### Passo 7 — Criar estação no cérebro do time

Diga:

> _"Agora vamos criar sua estação no cérebro do TIME primeiro. Você precisa abrir o outro repo aqui também."_

Instruir a abrir no Claude Code uma sessão paralela em `{{EMPRESA_SLUG}}-second-brain/` e rodar `setup-estacao-pessoal` lá. Quando voltar, confirmar:

```bash
ls ../{{EMPRESA_SLUG}}-second-brain/inbox/{slug}/
```

Deve existir.

### Passo 8 — Criar estação neste cérebro (diretoria)

Invoque `setup-estacao-pessoal` neste repo. Deixe ela conduzir. Confirmar ao fim:

```bash
ls inbox/{slug}/
```

Com `CLAUDE.md` próprio + `privado/` já pronta (gitignored).

### Passo 9 — OpenClaw pessoal: você tem?

Pergunte:

> _"Você já tem um OpenClaw pessoal rodando? Isso seria um agente próprio seu (ex: Amora do Bruno), 24/7 em VPS dedicado, que te serve pra tarefas pessoais/profissionais além da empresa."_

Duas respostas possíveis:

**(A) Não tem / primeira vez**
Continue pro Passo 10, modo **NOVO**.

**(B) Já tem**
Pergunte o nome do agente e o path do workspace no VPS dele. Continue pro Passo 10, modo **MERGE**.

### Passo 10 — Setup do cérebro pessoal (template-second-brain-pessoal)

**Mudança de 2026-04:** a skill antiga `setup-agente-openclaw` foi **aposentada**. Agora cada diretor tem um **terceiro cérebro** — o pessoal, individual, que vive na conta GitHub pessoal dele.

Diga:

> _"Vou te orientar a clonar o template do cérebro pessoal. Esse cérebro é **seu**, não da empresa — fica na sua conta GitHub pessoal, não na Org. Ele é o workspace canônico do seu OpenClaw pessoal (se você for rodar um em VPS) e onde você faz `/sync-pessoal` (alias `/save`, ou linguagem natural: 'salva', 'guarda', 'comita') no dia a dia. Cross-brain pros 2 coletivos é via `/sync-empresa` e `/sync-diretoria` (skills que vivem nos respectivos repos)."_

Passos:

1. Acessar `github.com/pixel-educacao/template-second-brain-pessoal`
2. **"Use this template"** → owner: **conta pessoal dele** → nome sugerido: `{{EMPRESA_SLUG}}-{nome-do-agente}`
3. Clonar localmente **lado a lado** dos outros 2 cérebros:
   ```bash
   cd ~/brains  # ou diretório que ele escolheu
   git clone git@github.com:{conta-pessoal}/{{EMPRESA_SLUG}}-{nome-agente}.git
   ```
4. Abrir no Claude Code / Cowork → rodar `/inicializar-cerebro` nesse repo pessoal
5. (Opcional) Subir em VPS 24/7 pra ter agente próprio rodando — docs no HEARTBEAT.md do template pessoal

Desse ponto em diante, o diretor **opera principalmente no cérebro pessoal dele**. Usa:
- `/sync-pessoal` (alias `/save`, ou LN: "salva", "guarda") pra materializar capturas no cérebro pessoal (automático antes de compactar)
- `/sync-empresa` pra distribuir pessoal → cérebro do time (skill vive em `template-second-brain-empresa`)
- `/sync-diretoria` pra distribuir pessoal → este cérebro da diretoria, com gates extras (skill vive aqui)

### Passo 11 — Validação final

3 perguntas:

1. _"Um sócio te pergunta no Telegram: 'achei que vale aumentar o salário da Ana'. Como você captura?"_
   - Esperado: neste repo (diretoria), `inbox/{seu-slug}/` ou `inbox/{seu-slug}/privado/` dependendo de se já quer discutir com os outros sócios. Nunca no repo do time.
2. _"Sua campanha de marketing teve ideia nova. Onde captura?"_
   - Esperado: repo do time, `inbox/{seu-slug}/` (operacional, nenhum gatilho).
3. _"Seu OpenClaw pessoal pensa num insight estratégico que vale registrar. Em qual lugar ele escreve?"_
   - Esperado: **não** no canônico. Sempre em `inbox/{diretor}/` de um dos 2 repos em staging. A consolidação do repo correspondente decide o que vira canônico (via PR no caso da diretoria).

Se errar: volte pro passo relevante.

Ao fim: _"Você está plenamente operacional nos 2 cérebros. Registra suas capturas tranquilo — os agentes processam à noite."_

## Links úteis

- [`README.md`](../../../README.md)
- [`CLAUDE.md`](../../../CLAUDE.md)
- [`empresa/contexto/PRINCIPIOS.md`](../../contexto/PRINCIPIOS.md) — regras duras
- [`empresa/contexto/ARQUITETURA.md`](../../contexto/ARQUITETURA.md) — modelo dos 2 cérebros
- [`empresa/contexto/SEGURANCA.md`](../../contexto/SEGURANCA.md) — revogação, backup, LGPD
- `empresa/skills/setup-agente-openclaw/SKILL.md` — detalhes da skill do OpenClaw pessoal

## Regras de segurança

- **Não** rodar sem confirmar que a pessoa é diretor (acesso aos 2 repos validado)
- **Não** apressar o Passo 4 (3 gatilhos) — é onde a pessoa mais erra depois
- **Backup**: antes do Passo 10 modo MERGE, a skill `setup-agente-openclaw` faz backup do workspace pessoal do diretor. Confirmar que foi feito.

## Recursos desta skill

Nenhum script. É conversa guiada que invoca `setup-estacao-pessoal` (2 vezes) e `setup-agente-openclaw` (1 vez).

---

*Tutorial + orquestração. Invoca skills atômicas como sub-passos. Mais denso que `onboarding-membro-time` porque cobre 2 cérebros + OpenClaw pessoal.*
