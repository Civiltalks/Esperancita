---
name: consolidar-estacoes
description: >
  Rotina de consolidação noturna das estações pessoais dos diretores.
  Lê tudo que foi capturado em inbox/{nome}/ ao longo do dia, promove para main
  o que está maduro, abre PR pro que precisa revisão humana, arquiva o processado
  e reseta staging. É a rotina de "sono" do cérebro da diretoria.
  Quem executa: {{AGENTE_NOME}}. Quando: ~02:00 BRT todo dia.
  Palavras-chave: consolidação, consolidar, estações, inbox, rotina noturna, sono, PR.
---

# consolidar-estacoes

## O que faz

Roda a rotina de consolidação noturna do Pixel Second Brain. É a contraparte da captura que acontece durante o dia nas estações pessoais (`inbox/{nome}/`). No final do ciclo, `staging` volta a estar idêntica a `main`, com os inboxes zerados e o conteúdo capturado promovido, arquivado ou proposto como PR conforme a maturidade.

## Quando usar

- **Automático:** `heartbeat` do {{AGENTE_NOME}} dispara às ~02:00 BRT todos os dias.
- **Manual:** quando precisar consolidar fora do ciclo (ex: antes de uma reunião importante de manhã).

## Ferramentas necessárias

- `Bash` — git, movimentação de arquivos
- `Read` / `Write` — ler sidecar `.meta.yaml` e escrever digest
- `gh` (GitHub CLI) — abrir pull requests

## Regras de segurança (invioláveis)

1. **Nunca resolver conflito sozinho.** Se houver conflito, parar a rotina, alertar a diretoria (canal privado) e não mexer em nada.
2. **Nunca perder captura.** Antes de qualquer remoção de arquivo em staging, o conteúdo já deve estar arquivado em `inbox/{nome}/_historico/{data}/` ou incluído no PR de consolidação. Se houver dúvida, manter o arquivo onde está.
3. **Staging reflete o dia inteiro do {{AGENTE_NOME}} — inclusive writes dele em canônico.** {{AGENTE_NOME}} é o agente deste cérebro e é o **único** que escreve direto em `areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/` durante o dia (humanos e agentes pessoais só mexem em `inbox/`). A skill **não audita** autoria nem trata isso como violação. Tudo entra no PR único de consolidação.
4. **Nunca promover direto pra main.** Propriedade do repo: toda entrada em `main` passa por PR pra revisão de sócio. Mesmo com `maturidade: pronto-para-canonico` + `destino_sugerido`, vira PR — nunca merge direto.

## Passo a passo

### 1. Preparação — commit do próprio trabalho PRIMEIRO

{{AGENTE_NOME}} é o agente que **roda esta skill** e também é o **único** que escreve direto em canônico (`areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/`) durante o dia. Como ele faz os dois papéis, o repo local dele tende a ter mudanças pendentes no working tree quando chega a hora da consolidação. **Essas mudanças são pré-condição da rotina, não ruído** — o próprio {{AGENTE_NOME}} precisa garantir que commitou e pushou o próprio trabalho antes de começar a classificar os inboxes dos visitantes. Sócios só mexem em `inbox/` (e já pushem via `/sync-diretoria`), então canônico só aparece em staging se o {{AGENTE_NOME}} subir — e aí entra incompleto no PR único do dia.

```bash
cd /root/.openclaw/workspace-{{AGENTE_SLUG}}/{{EMPRESA_SLUG}}-diretoria
git fetch origin

# 1.a. Sobe o trabalho local do {{AGENTE_NOME}} pro staging (writes canônicos do dia)
git checkout staging
git pull --rebase origin staging

git add .
git diff --cached --quiet || git commit -m "{{AGENTE_SLUG}}: writes canônicos do dia $(date -u +%Y-%m-%d)"
git push origin staging

# 1.b. Atualiza main pra comparação no step 2
git checkout main
git pull --rebase origin main
```

**Não pular 1.a.** Se o working tree local tem mudanças e você só faz `git pull` sem commitar antes, a consolidação vai processar apenas as capturas dos visitantes — e o canônico do {{AGENTE_NOME}} do dia fica órfão no VPS, invisível pros sócios no PR.

### 2. Inventariar staging (sem gate)

```bash
git diff --name-status main..staging
```

Staging acumula 2 tipos de mudança durante o dia — **ambos entram no PR único de consolidação**:

- **`inbox/*/`** — capturas de visitantes (diretores, agentes pessoais). Vão pra classificação no step 3.
- **Fora de `inbox/*/`** (`areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/`, etc.) — writes canônicos diretos do {{AGENTE_NOME}} durante o dia (subidos no step 1.a). {{AGENTE_NOME}} é o único que mexe em canônico; a skill **não valida autoria nem bloqueia**.

Esta skill **não** audita violação de regra. Processa inbox, junta tudo no PR e segue.

### 3. Classificar cada arquivo

Para cada arquivo em `inbox/{nome}/` — **qualquer formato** (`.md`, `.html`, `.pdf`, `.png`, `.pptx`, etc.) —
ignorar:
- `privado/` — gitignored uniforme nos 3 cérebros (Cayo review 23/04 item #4); nem aparece no remoto. Skill ignora explicitamente como defesa em profundidade.
- `_historico/`
- `README.md` e `CLAUDE.md` (infra da estação, não captura)
- próprios sidecars `*.meta.yaml` (não se classificam; apenas alimentam a classificação dos arquivos-par)

a. Para cada captura `foo.ext`, procurar sidecar `foo.ext.meta.yaml` no mesmo diretório.
b. Ler o sidecar YAML.
c. Aplicar a matriz de classificação:

| maturidade | tipo | ação |
|---|---|---|
| `pronto-para-canonico` | (qualquer) com `destino_sugerido` válido | **incluir no PR** — aplicar em `destino_sugerido` na branch de consolidação |
| `pronto-para-canonico` | sem `destino_sugerido` | **incluir no PR** — {{AGENTE_NOME}} sugere destino com base em tags/relacionado; sócio ajusta na revisão |
| `draft` | `proposta-canonica` | **incluir no PR** direcionado ao `destino_sugerido` |
| `draft` | `nota` / `referencia` | manter em `inbox/{nome}/` — ainda verde |
| `cru` | (qualquer) | manter; se já passou de 7 dias sem evoluir, arquivar em `_historico/` |
| `diario` | (qualquer) | arquivar em `_historico/{data}/diario.md` no fim do dia |

**Na diretoria, nenhuma ação é "promover direto". Tudo que for promovível entra no mesmo PR único do dia** — sócios revisam e aprovam em bloco (ou em commits separados dentro do mesmo PR).

d. **Sidecar ausente ou malformado:** marcar pra revisão manual, **não promover**, avisar no digest. Mensagem: *"captura {arquivo} sem sidecar — pedir frontmatter ao autor"*. Exceção: arquivos do sistema (`README.md`, `CLAUDE.md`) não exigem sidecar.

e. Ao promover ou mover captura, **mover o sidecar junto**. Ao promover pra canônico: **descartar o sidecar** (canônico não carrega metadata de consolidação).

### 4. Preparar o PR único de consolidação do dia

Criar UMA branch a partir de main e **juntar nela todas as mudanças do dia**: writes do {{AGENTE_NOME}}, promoções classificadas, rearranjos. Sócios revisam e aprovam em bloco.

```bash
git checkout main
git pull --rebase origin main
git checkout -b consolidacao/{data}

# 1. Traz os writes diretos do {{AGENTE_NOME}} do dia (fora de inbox)
#    via merge do staging, resolvendo só arquivos fora de inbox/*
git merge origin/staging --no-commit --no-ff || true
git reset HEAD 'inbox/*' 2>/dev/null || true   # tira inbox do staged
git checkout HEAD -- 'inbox/*' 2>/dev/null || true   # descarta mudanças em inbox aqui
git commit -m "consolidacao {data}: writes do {{AGENTE_NOME}} do dia" 2>/dev/null || true

# 2. Aplica promoções classificadas (cp de inbox em staging pro destino canônico)
for cada arquivo classificado pra incluir no PR:
  git show origin/staging:inbox/{nome}/{arquivo}.{ext} > {destino-canonico}
  git add {destino-canonico}
done
git commit -m "consolidacao {data}: promoções de inbox classificadas" 2>/dev/null || true
```

**Importante:** canônico é sempre **livre de metadata de consolidação**. Nada de YAML de classificação embutido no arquivo promovido. Se precisa persistir origem, registrar no commit message ou no digest.

### 5. Abrir o PR único de consolidação

```bash
git push -u origin consolidacao/{data}

# abrir PR via gh (reviewer = {{FUNDADOR_1_SLUG}})
gh pr create \
  --base main \
  --title "Consolidação diretoria {data}" \
  --body "$(cat <<BODY
## Consolidação automática do dia

**Writes do {{AGENTE_NOME}} durante o dia:**
[lista de arquivos fora de inbox que vieram via merge de staging]

**Promoções classificadas de inbox:**
[lista de promoções, cada uma com: autor, arquivo-fonte em staging, destino sugerido]

**Arquivamentos em staging:**
[lista de arquivos processados — ver branch staging]

**Capturas mantidas no inbox** (ainda verdes, não entram neste PR):
[lista]

Revisar arquivo a arquivo. Sócios podem mergear em bloco, aprovar arquivos individuais ou pedir ajustes antes de mergear.

Digest completo: empresa/consolidacao/{data}.md
BODY
)" \
  --reviewer {{FUNDADOR_1_SLUG}}
```

### 6. Arquivar processados

Para cada arquivo que foi promovido ou virou PR, mover o arquivo **e seu sidecar** pro histórico:

```bash
DATA=$(date -u +%Y-%m-%d)
mkdir -p inbox/{nome}/_historico/${DATA}
git mv inbox/{nome}/{arquivo}.{ext} inbox/{nome}/_historico/${DATA}/
# mover sidecar junto — historico preserva o par completo pra auditoria
git mv inbox/{nome}/{arquivo}.{ext}.meta.yaml inbox/{nome}/_historico/${DATA}/ 2>/dev/null || true
```

Arquivos classificados como **manter** não são arquivados — seguem disponíveis no inbox no dia seguinte (com sidecar).

Arquivos classificados como `diario` são movidos pro histórico automaticamente no fim do dia, junto com seus sidecars.

### 7. Finalizar arquivamentos em staging — aguardar merge do PR

Na diretoria, staging **não é sincronizada com main imediatamente** — ela espera o sócio mergear o PR primeiro.

```bash
# Commita arquivamentos de inbox processado na própria staging
git checkout staging
git pull --rebase origin staging
git add .
git diff --cached --quiet || git commit -m "consolidacao {data}: arquivamento de estações processadas"
git push origin staging
```

**Depois que o sócio mergear o PR `consolidacao/{data}`**, staging será sincronizada com main pela próxima execução da skill (no dia seguinte) ou manualmente:

```bash
# Sync staging com main depois de PR aprovado (manual ou na próxima consolidação)
git checkout staging
git merge main --no-ff -m "consolidacao {data}: sync staging com main pós-merge do PR"
git push origin staging
```

Resultado: staging continua "à frente" de main enquanto o PR está aberto. Isso é **esperado e correto** na diretoria — diferente do cérebro do time, onde main sempre fica em dia.

### 8. Escrever o digest — "jornal da manhã"

Criar `empresa/consolidacao/{YYYY-MM-DD}.md` com:

- **Promovido direto** — lista de arquivos que foram pra canônico automaticamente, com origem e destino
- **PRs abertos** — links dos PRs criados, com resumo de cada um
- **Arquivado sem promoção** — capturas que estavam há mais de 7 dias cru
- **Mantido no inbox** — capturas ainda verdes, com idade
- **Problemas encontrados** — frontmatters ausentes, arquivos malformados, violações de regra
- **Heartbeat de cada estação** — quantas capturas cada pessoa fez no dia (sinal de uso do sistema)

```bash
git add empresa/consolidacao/${DATA}.md
git commit -m "consolidacao {data}: digest"
git push origin main
```

### 9. Notificação

Postar no canal do Telegram da Pixel um resumo curto:

> 🌙 Consolidação {data} feita.
> • X promovidos, Y PRs abertos, Z arquivados.
> • Jornal completo: empresa/consolidacao/{data}.md
> • PRs esperando revisão: [lista]

Se houve alerta (regra violada, conflito, volume anômalo), usar emoji 🚨 e alertar nominalmente o {{FUNDADOR_1}}.

## Output esperado

- `main` atualizada com promoções
- `staging` sincronizada com `main` (inboxes processados arquivados, imaturos mantidos)
- PRs abertos no GitHub com reviewers atribuídos
- Digest salvo em `empresa/consolidacao/{data}.md`
- Mensagem no Telegram

## Notas

- **Frequência:** 1x por dia às ~02:00 BRT. Nunca rodar mais de uma vez no mesmo dia (cria duplicata no histórico).
- **Quem aprova PRs:** default é {{FUNDADOR_1}}. Pode expandir pra lista de reviewers quando a diretoria crescer.
- **Privacidade:** `inbox/{nome}/privado/` é **gitignored uniforme nos 3 cérebros** (decisão Cayo review 23/04 item #4) — não aparece no remoto. Esta rotina ignora explicitamente como defesa em profundidade no Step 3. Sócio que precisa sincronizar scratch entre máquinas usa o cérebro pessoal dele.
- **Edge case — conflito no merge main → staging:** parar, criar issue, alertar. Não tentar adivinhar.
- **Edge case — mesmo tema capturado por 2+ pessoas:** detectar por overlap de tags/relacionado, destacar no digest como "atenção: duplicação detectada", abrir PR unificado quando possível.
- **Edge case — sidecar sem arquivo-par:** captura foi deletada mas o sidecar ficou. Marcar pra limpeza no próximo ciclo (mover ambos pro histórico se idade > 1 dia).
- **Edge case — arquivo sem sidecar (não-sistema):** não promover. Avisar no digest. Deixar no inbox até o autor criar o sidecar.
- **Modelo de inferência:** Sonnet (não Opus, por custo — seguir AGENTS.md do {{AGENTE_NOME}}).

## Protocolo relacionado

Esta skill é a execução operacional do protocolo em `empresa/contexto/protocolo-consolidacao-memoria.md`, estendido para incluir as estações pessoais como fonte principal de captura.
