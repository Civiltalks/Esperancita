#!/usr/bin/env bash
# inicializar.sh — substitui placeholders e renomeia pasta do agente.
# Roda UMA vez após o clone do template-second-brain-diretoria.
# Aborta se .cerebro-inicializado já existir.
#
# Uso (CLI ou invocado pela skill inicializar-cerebro):
#
#   bash inicializar.sh \
#     --empresa "Acme Corp" \
#     --empresa-slug "acme" \
#     --org "acme-org" \
#     --empresa-dominio "acme.com" \
#     --tipo-empresa "LTDA" \
#     --timezone "America/Sao_Paulo" \
#     --idioma "pt-BR" \
#     --email-diretoria "diretoria@acme.com" \
#     --agente-nome "Atena" \
#     --agente-slug "atena" \
#     --agente-time-nome "Oliver" \
#     --fundador "Ana Silva" \
#     --fundador-slug "ana" \
#     --fundador-cargo "CEO" \
#     [ --fundador-2 "Bruno Costa" --fundador-2-slug "bruno" --fundador-2-cargo "CTO" ] \
#     [ --fundador-3 "Carla Dias" --fundador-3-cargo "COO" ]
#
# Obrigatórios: empresa, empresa-slug, org, empresa-dominio, tipo-empresa,
# agente-nome, agente-slug, agente-time-nome, fundador, fundador-slug,
# fundador-cargo. Demais flags têm default ou são opcionais (founders 2/3).

set -euo pipefail

# ======================
# Parse de argumentos
# ======================

EMPRESA=""
EMPRESA_SLUG=""
ORG=""
EMPRESA_DOMINIO=""
TIPO_EMPRESA=""
TIMEZONE="America/Sao_Paulo"
IDIOMA="pt-BR"
EMAIL_DIRETORIA=""
AGENTE_NOME=""
AGENTE_SLUG=""
AGENTE_TIME_NOME=""
FUNDADOR=""
FUNDADOR_SLUG=""
FUNDADOR_CARGO=""
FUNDADOR_2=""
FUNDADOR_2_SLUG=""
FUNDADOR_2_CARGO=""
FUNDADOR_3=""
FUNDADOR_3_SLUG=""
FUNDADOR_3_CARGO=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    --empresa)            EMPRESA="$2"; shift 2;;
    --empresa-slug)       EMPRESA_SLUG="$2"; shift 2;;
    --org)                ORG="$2"; shift 2;;
    --empresa-dominio)    EMPRESA_DOMINIO="$2"; shift 2;;
    --tipo-empresa)       TIPO_EMPRESA="$2"; shift 2;;
    --timezone)           TIMEZONE="$2"; shift 2;;
    --idioma)             IDIOMA="$2"; shift 2;;
    --email-diretoria)    EMAIL_DIRETORIA="$2"; shift 2;;
    --agente-nome)        AGENTE_NOME="$2"; shift 2;;
    --agente-slug)        AGENTE_SLUG="$2"; shift 2;;
    --agente-time-nome)   AGENTE_TIME_NOME="$2"; shift 2;;
    --fundador-1)         FUNDADOR="$2"; shift 2;;
    --fundador-1-slug)    FUNDADOR_SLUG="$2"; shift 2;;
    --fundador-1-cargo)   FUNDADOR_CARGO="$2"; shift 2;;
    --fundador-2)         FUNDADOR_2="$2"; shift 2;;
    --fundador-2-slug)    FUNDADOR_2_SLUG="$2"; shift 2;;
    --fundador-2-cargo)   FUNDADOR_2_CARGO="$2"; shift 2;;
    --fundador-3)         FUNDADOR_3="$2"; shift 2;;
    --fundador-3-slug)    FUNDADOR_3_SLUG="$2"; shift 2;;
    --fundador-3-cargo)   FUNDADOR_3_CARGO="$2"; shift 2;;
    *) echo "flag desconhecida: $1" >&2; exit 1;;
  esac
done

# Default derivado pra email da diretoria, se não informado
if [ -z "$EMAIL_DIRETORIA" ] && [ -n "$EMPRESA_DOMINIO" ]; then
  EMAIL_DIRETORIA="diretoria@${EMPRESA_DOMINIO}"
fi

# Validar obrigatórios
for var in EMPRESA EMPRESA_SLUG ORG EMPRESA_DOMINIO TIPO_EMPRESA TIMEZONE IDIOMA \
           AGENTE_NOME AGENTE_SLUG AGENTE_TIME_NOME \
           FUNDADOR FUNDADOR_SLUG FUNDADOR_CARGO; do
  if [ -z "${!var}" ]; then
    flag_name=$(echo "$var" | tr '[:upper:]_' '[:lower:]-')
    echo "erro: argumento --${flag_name} obrigatório" >&2
    exit 1
  fi
done

# Validar slugs (incluindo opcionais quando preenchidos)
for slug in "$EMPRESA_SLUG" "$AGENTE_SLUG" "$ORG" "$FUNDADOR_SLUG"; do
  if ! [[ "$slug" =~ ^[a-z0-9][a-z0-9-]*[a-z0-9]$ ]]; then
    echo "erro: slug inválido '$slug'. Use lowercase, números, hífen." >&2
    exit 1
  fi
done
for slug in "$FUNDADOR_2_SLUG" "$FUNDADOR_3_SLUG"; do
  if [ -n "$slug" ] && ! [[ "$slug" =~ ^[a-z0-9][a-z0-9-]*[a-z0-9]$ ]]; then
    echo "erro: slug opcional inválido '$slug'. Use lowercase, números, hífen." >&2
    exit 1
  fi
done

# Coerência: se tem --fundador-2-slug ou --fundador-2-cargo, tem que ter --fundador-2
if { [ -n "$FUNDADOR_2_SLUG" ] || [ -n "$FUNDADOR_2_CARGO" ]; } && [ -z "$FUNDADOR_2" ]; then
  echo "erro: --fundador-2-slug/--fundador-2-cargo informados sem --fundador-2." >&2
  exit 1
fi
if { [ -n "$FUNDADOR_3_SLUG" ] || [ -n "$FUNDADOR_3_CARGO" ]; } && [ -z "$FUNDADOR_3" ]; then
  echo "erro: --fundador-3-slug/--fundador-3-cargo informados sem --fundador-3." >&2
  exit 1
fi

# ======================
# Pré-checagens
# ======================

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

if [ -f ".cerebro-inicializado" ]; then
  echo "erro: este cérebro da diretoria já foi inicializado (.cerebro-inicializado existe)." >&2
  echo "       Se quer resetar, apague o arquivo e rode de novo (risco: sobrescreve substituições)." >&2
  exit 1
fi

# Deve haver placeholders pra substituir (senão alguém já rodou e apagou o arquivo de trava)
if ! grep -rq "{{EMPRESA}}" . --include='*.md' --exclude-dir=.git 2>/dev/null; then
  echo "aviso: não encontrei placeholders {{EMPRESA}} nos arquivos." >&2
  echo "       O repo pode já ter sido inicializado. Continue com -y pra forçar, ou aborte." >&2
  read -r -p "continuar mesmo assim? (s/N) " confirma
  [[ "$confirma" =~ ^[sS]$ ]] || exit 1
fi

# Garantir branch 'staging' (cérebro coletivo da diretoria trabalha em staging; main só via PR)
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")
if [ "$CURRENT_BRANCH" != "staging" ]; then
  if git show-ref --verify --quiet refs/heads/staging; then
    echo "-> trocando da branch '$CURRENT_BRANCH' pra 'staging'"
    git checkout staging
  else
    echo "-> branch 'staging' não existe — criando a partir de '$CURRENT_BRANCH'"
    git checkout -b staging
  fi
fi

# Backup tag
BACKUP_TAG="pre-inicializacao-$(date +%Y%m%d-%H%M%S)"
git tag "$BACKUP_TAG" 2>/dev/null || true
echo "-> tag de backup criada: $BACKUP_TAG"

# ======================
# Substituição de placeholders
# ======================

echo "-> aplicando substituições em arquivos .md / .sh / .yaml / .yml / .html"

# sed portátil (BSD/macOS vs GNU)
if sed --version 2>/dev/null | grep -q GNU; then
  SED_INPLACE=(-i)
else
  SED_INPLACE=(-i '')
fi

# IMPORTANTE: o find exclui o diretório scripts/ do próprio inicializar — senão
# o sed substituiria placeholders dentro deste script (ex: {{EMPRESA}} em strings
# de erro/aviso), poluindo o script com hardcode da empresa atual e quebrando
# re-execução em outro contexto.
SCRIPTS_DIR_EXCLUDE='./empresa/skills/inicializar-cerebro/scripts'

# Função helper
replace_in_tree() {
  local key="$1"
  local value="$2"
  # escapa para sed (barras e &)
  local escaped
  escaped=$(printf '%s\n' "$value" | sed -e 's/[\/&|]/\\&/g')
  find . -type f \( -name '*.md' -o -name '*.sh' -o -name '*.yaml' -o -name '*.yml' -o -name '*.html' -o -name 'CODEOWNERS' \) \
    -not -path './.git/*' \
    -not -path "${SCRIPTS_DIR_EXCLUDE}/*" \
    -print0 | xargs -0 sed "${SED_INPLACE[@]}" "s|{{${key}}}|${escaped}|g"
}

# Pré-processamento: remover linhas dos fundadores 2/3 quando não informados.
# (Evita bullets vazios "**** — ****" no USER.md depois das substituições.)
remove_lines_with_token() {
  local token="$1"
  find . -type f \( -name '*.md' -o -name '*.sh' -o -name '*.yaml' -o -name '*.yml' -o -name '*.html' -o -name 'CODEOWNERS' \) \
    -not -path './.git/*' \
    -not -path "${SCRIPTS_DIR_EXCLUDE}/*" \
    -print0 | xargs -0 sed "${SED_INPLACE[@]}" "/{{${token}}}/d"
}
if [ -z "$FUNDADOR_2" ]; then remove_lines_with_token "FUNDADOR_2"; fi
if [ -z "$FUNDADOR_3" ]; then remove_lines_with_token "FUNDADOR_3"; fi

# Pré-processamento: remover blocos delimitados por marker template-only.
# Tudo entre <!-- template-only-start --> e <!-- template-only-end --> some
# (inclusive os marcadores). Útil pra instruções meta-template tipo "substitua os
# placeholders {{...}}" que só fazem sentido enquanto o repo é template upstream.
find . -type f -name '*.md' -not -path './.git/*' \
  -not -path "${SCRIPTS_DIR_EXCLUDE}/*" \
  -print0 | xargs -0 sed "${SED_INPLACE[@]}" \
  '/<!-- template-only-start -->/,/<!-- template-only-end -->/d'

# Substituições principais
replace_in_tree "EMPRESA"               "$EMPRESA"
replace_in_tree "EMPRESA_SLUG"          "$EMPRESA_SLUG"
replace_in_tree "ORG"                   "$ORG"
replace_in_tree "SUA_ORG"               "$ORG"
replace_in_tree "EMPRESA_DOMINIO"       "$EMPRESA_DOMINIO"
replace_in_tree "TIPO_EMPRESA"          "$TIPO_EMPRESA"
replace_in_tree "TIMEZONE"              "$TIMEZONE"
replace_in_tree "IDIOMA"                "$IDIOMA"
replace_in_tree "EMAIL_DIRETORIA"       "$EMAIL_DIRETORIA"
replace_in_tree "AGENTE_NOME"           "$AGENTE_NOME"
replace_in_tree "AGENTE_DIRETORIA_NOME" "$AGENTE_NOME"
replace_in_tree "AGENTE_SLUG"           "$AGENTE_SLUG"
replace_in_tree "AGENTE_TIME_NOME"      "$AGENTE_TIME_NOME"
replace_in_tree "FUNDADOR_1"            "$FUNDADOR"
replace_in_tree "FUNDADOR_1_SLUG"       "$FUNDADOR_SLUG"
replace_in_tree "FUNDADOR_1_CARGO"      "$FUNDADOR_CARGO"
replace_in_tree "PAPEL_FUNDADOR_1"      "$FUNDADOR_CARGO"
# Fundadores 2 e 3 — só substituem se informados (linhas órfãs já removidas acima)
if [ -n "$FUNDADOR_2" ]; then
  replace_in_tree "FUNDADOR_2"          "$FUNDADOR_2"
  replace_in_tree "FUNDADOR_2_SLUG"     "$FUNDADOR_2_SLUG"
  replace_in_tree "FUNDADOR_2_CARGO"    "$FUNDADOR_2_CARGO"
  replace_in_tree "PAPEL_FUNDADOR_2"    "$FUNDADOR_2_CARGO"
fi
if [ -n "$FUNDADOR_3" ]; then
  replace_in_tree "FUNDADOR_3"          "$FUNDADOR_3"
  replace_in_tree "FUNDADOR_3_SLUG"     "$FUNDADOR_3_SLUG"
  replace_in_tree "FUNDADOR_3_CARGO"    "$FUNDADOR_3_CARGO"
  replace_in_tree "PAPEL_FUNDADOR_3"    "$FUNDADOR_3_CARGO"
fi

# ======================
# Renomear pasta do agente
# ======================

if [ -d "agentes/geral-diretoria" ] && [ ! -d "agentes/$AGENTE_SLUG" ]; then
  echo "-> renomeando agentes/geral-diretoria/ → agentes/$AGENTE_SLUG/"
  git mv "agentes/geral-diretoria" "agentes/$AGENTE_SLUG"
elif [ -d "agentes/$AGENTE_SLUG" ]; then
  echo "-> pasta agentes/$AGENTE_SLUG/ já existe, preservando"
fi

# ======================
# Criar arquivo de trava
# ======================

cat > ".cerebro-inicializado" <<EOF
inicializado_em: $(date --iso-8601=seconds 2>/dev/null || date +"%Y-%m-%dT%H:%M:%S%z")
tipo: diretoria
empresa: $EMPRESA
empresa_slug: $EMPRESA_SLUG
empresa_dominio: $EMPRESA_DOMINIO
tipo_empresa: $TIPO_EMPRESA
org: $ORG
agente_nome: $AGENTE_NOME
agente_slug: $AGENTE_SLUG
agente_time_nome: $AGENTE_TIME_NOME
fundador_principal: $FUNDADOR
fundador_principal_slug: $FUNDADOR_SLUG
fundador_principal_cargo: $FUNDADOR_CARGO
fundador_2: ${FUNDADOR_2:-}
fundador_3: ${FUNDADOR_3:-}
email_diretoria: $EMAIL_DIRETORIA
timezone: $TIMEZONE
idioma: $IDIOMA
versao_template: 1.0
tag_backup: $BACKUP_TAG
EOF

echo "-> .cerebro-inicializado criado"

# ======================
# Verificação de placeholders residuais (gate fatal)
# ======================
#
# Allowlist: placeholders que INTENCIONALMENTE permanecem após o init.
# Eles são preenchidos por outras skills no momento de uso (per-diretor /
# per-membro / per-agente-pessoal). Documentado em
# empresa/skills/inicializar-cerebro/SKILL.md (seção Allowlist).
ALLOWED_PLACEHOLDERS=(
  "AGENTE_PESSOAL_NOME"   # preenchido pelo agente pessoal de cada diretor
  "SEU_SLUG"              # exemplo em setup-estacao-pessoal (slug do usuário corrente)
  "MEMBRO_EQUIPE_SLUG"    # exemplo em setup-estacao-pessoal (slug genérico)
)

echo
echo "-> verificando placeholders residuais..."

# regex: {{(A|B|C)}} pra excluir da contagem
ALLOW_REGEX=$(IFS='|'; echo "${ALLOWED_PLACEHOLDERS[*]}")
RESIDUAL=$(grep -rnE '\{\{[A-Z_0-9]+\}\}' . \
  --include='*.md' --include='*.sh' --include='*.yaml' --include='*.yml' --include='*.html' --include='CODEOWNERS' \
  --exclude-dir=.git 2>/dev/null \
  | grep -v 'empresa/skills/inicializar-cerebro/scripts/' \
  | grep -vE "\\{\\{(${ALLOW_REGEX})\\}\\}" || true)

if [ -n "$RESIDUAL" ]; then
  echo "ERRO: placeholders {{...}} não substituídos (fora da allowlist):" >&2
  echo "$RESIDUAL" >&2
  echo >&2
  echo "Allowlist documentada (não conta como falha):" >&2
  for ph in "${ALLOWED_PLACEHOLDERS[@]}"; do echo "  - {{${ph}}}" >&2; done
  echo >&2
  echo "Causas comuns:" >&2
  echo "  1) Você adicionou um placeholder novo sem estender este script." >&2
  echo "  2) Falta uma flag --xxx na invocação." >&2
  echo "  3) O placeholder devia entrar na allowlist (intencional pós-init)." >&2
  exit 1
fi

echo "✅ todos os placeholders substituídos (ou na allowlist)"

# ======================
# Commit
# ======================

echo
echo "-> preparando commit em staging"

git add -A
git -c user.name="$FUNDADOR" -c user.email="${AGENTE_SLUG}@${EMPRESA_DOMINIO}" commit -m "init: $EMPRESA second brain da diretoria inicializado

Placeholders substituídos, agente '$AGENTE_NOME' configurado, pasta agentes/$AGENTE_SLUG/ criada.
Arquivo .cerebro-inicializado grava metadados. Backup: tag $BACKUP_TAG."

# Cleanup do backup tag em sucesso (se algo abortou antes, tag fica preservada pra rollback)
git tag -d "$BACKUP_TAG" >/dev/null 2>&1 || true

echo
echo "== inicialização concluída =="
echo "próximos passos:"
echo "  1) git push -u origin staging"
echo "  2) rodar skill 'setup-estacao-pessoal' no Claude Code (cria sua inbox)"
echo "  3) em VPS, rodar skill 'setup-agente-openclaw' (sobe $AGENTE_NOME 24/7)"
echo
echo "ver roadmap completo em empresa/skills/inicializar-cerebro/SKILL.md (Passo 7)"
echo
echo "⚠️   AÇÃO MANUAL OBRIGATÓRIA — branch protection"
echo "   A regra de \"revisão humana em todo PR pra main\" só vira realidade"
echo "   se você ativar branch protection na GitHub. Sem isso, qualquer pessoa"
echo "   com acesso de escrita pode mergear direto e quebrar a propriedade"
echo "   central deste cérebro."
echo
echo "   Configure agora em:"
echo "     https://github.com/${ORG}/${EMPRESA_SLUG}-diretoria/settings/branches"
echo
echo "   Checklist completo: onboarding/SETUP.md, seção \"branch protection\"."
echo
