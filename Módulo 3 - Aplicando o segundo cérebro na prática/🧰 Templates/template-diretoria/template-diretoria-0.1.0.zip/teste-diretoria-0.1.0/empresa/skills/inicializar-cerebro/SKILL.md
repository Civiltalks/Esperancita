---
name: inicializar-cerebro
description: Configurar o cérebro da diretoria pela primeira vez após clonar o template-second-brain-diretoria. Preenche placeholders em todos os arquivos, renomeia a pasta do agente pro nome escolhido, e apresenta o roadmap de próximos passos (estação pessoal, agente em VPS, agente pessoal dos diretores). Roda **UMA VEZ** após o clone — aborta se já foi executada. Use logo após o "Use this template" do GitHub.
---

# Inicializar Cérebro — Template Diretoria

> Esta skill é um **tutorial + configurador**. Ela ensina como o cérebro da diretoria funciona enquanto configura ele pra sua empresa. Rode **uma única vez**, no primeiro uso do repo clonado.

## Quando usar

Você acabou de clicar em "Use this template" em `template-second-brain-diretoria` no GitHub, clonou localmente, e já tem o outro cérebro (do time) rodando. Este é o primeiro comando que você roda no Claude Code / Cowork no workspace deste repo.

## Pré-condições

- Cérebro do time (`{{EMPRESA_SLUG}}-second-brain`) já existe, inicializado e com time operando há ~60 dias
- Você é sócio-diretor (acesso restrito)
- Primeira captura que disparou os 3 gatilhos já aconteceu — sinal de que você precisa mesmo do 2º cérebro

Se não cumpriu, volte pro template do time e opere lá até maturar.

## Quando **não** usar

- Se `.cerebro-inicializado` já existe, a skill aborta
- Se você só quer criar sua estação pessoal, use `setup-estacao-pessoal`
- Se você quer subir o agente em VPS, use `setup-agente-openclaw`
- Se você quer conectar seu OpenClaw pessoal aos 2 cérebros, use `setup-agente-openclaw`

## Fluxo da skill (7 passos + roadmap final)

### Passo 1 — Contexto: modelo de 2 cérebros + revisão humana obrigatória

Antes de configurar, o agente (Claude Code) deve **explicar ao humano** o modelo, com ênfase nas especificidades da diretoria:

- Este é o **2º cérebro** da empresa — o sensível.
- Escopo é restrito à **regra dos 3 gatilhos**: dinheiro com nome próprio, pessoa específica, peso contratual/jurídico.
- Diferença estrutural em relação ao cérebro do time:
  - **Default de privacidade invertido** — `inbox/{sócio}/privado/` é o padrão; só saia pra público quando for claramente compartilhável com toda a diretoria
  - **Revisão humana obrigatória** — mesmo o agente gestor (Leo Boss / análogo) nunca promove canônico direto: sempre abre PR pra revisão de sócio
- Cada diretor normalmente tem um **agente pessoal OpenClaw** próprio (ex: Amora do Bruno) que é **visitante** dos 2 cérebros — escreve em `inbox/{diretor}/` em staging.

Pergunte: _"Entendeu as especificidades da diretoria? Alguma dúvida?"_

### Passo 2 — Coleta de dados

Perguntar em sequência:

**Empresa**
1. **Nome da empresa** → `{{EMPRESA}}` (mesmo valor do outro cérebro)
2. **Slug da empresa** → `{{EMPRESA_SLUG}}` (idem)
3. **Organização GitHub** → `{{ORG}}` (também substitui `{{SUA_ORG}}`)
4. **Domínio de email** → `{{EMPRESA_DOMINIO}}`
5. **Tipo da empresa** → `{{TIPO_EMPRESA}}` (ex: "LTDA", "S.A.", "MEI")
6. **Timezone** → `{{TIMEZONE}}` (default: `America/Sao_Paulo`)
7. **Idioma principal** → `{{IDIOMA}}` (default: `pt-BR`)
8. **Email da diretoria** → `{{EMAIL_DIRETORIA}}` (default: `diretoria@{{EMPRESA_DOMINIO}}`)

**Agentes**
9. **Nome do agente da diretoria** → `{{AGENTE_NOME}}` (ex: "Leo Boss", "Atena", "Hermes"). Escolha algo que evoque **prudência** — é um agente cuidadoso por design. Também substitui `{{AGENTE_DIRETORIA_NOME}}`.
10. **Slug do agente da diretoria** → `{{AGENTE_SLUG}}` (ex: "leo-boss", "atena")
11. **Nome do agente do time** → `{{AGENTE_TIME_NOME}}` (pra referências cross-repo, ex: "Íris", "Oliver"). **Deve ser idêntico** ao que você definiu no outro repo.

**Sócios-diretores** (até 3; o 1 é obrigatório, os demais opcionais)
12. **Fundador 1 (principal)** → `{{FUNDADOR_1}}` (nome), `{{FUNDADOR_1_SLUG}}` (slug pra revisões em PR), `{{FUNDADOR_1_CARGO}}` / `{{PAPEL_FUNDADOR_1}}` (cargo)
13. **Fundador 2** *(opcional)* → `{{FUNDADOR_2}}`, `{{FUNDADOR_2_SLUG}}`, `{{FUNDADOR_2_CARGO}}` / `{{PAPEL_FUNDADOR_2}}`
14. **Fundador 3** *(opcional)* → `{{FUNDADOR_3}}`, `{{FUNDADOR_3_SLUG}}`, `{{FUNDADOR_3_CARGO}}` / `{{PAPEL_FUNDADOR_3}}`

> **Nota:** se um fundador opcional não for informado, o script remove a linha correspondente no `USER.md` antes de aplicar substituições — sem bullets vazios.

### Passo 3 — Confirmação

Mostrar resumo e pedir confirmação explícita antes de aplicar.

```
Vou aplicar estas substituições em ~35 arquivos:
  {{EMPRESA}}              = Acme Corp
  {{AGENTE_NOME}}          = Atena
  {{AGENTE_SLUG}}          = atena
  {{AGENTE_TIME_NOME}}     = Oliver  (agente do outro cérebro)
  ...
E renomear: agentes/geral-diretoria/ → agentes/atena/

Confirma? (sim/não)
```

### Passo 4 — Aplicar substituições

Rodar o script `scripts/inicializar.sh`:

```bash
bash empresa/skills/inicializar-cerebro/scripts/inicializar.sh \
  --empresa "Acme Corp" \
  --empresa-slug "acme" \
  --org "acme-org" \
  --empresa-dominio "acme.com" \
  --tipo-empresa "LTDA" \
  --timezone "America/Sao_Paulo" \
  --idioma "pt-BR" \
  --email-diretoria "diretoria@acme.com" \
  --agente-nome "Atena" \
  --agente-slug "atena" \
  --agente-time-nome "Oliver" \
  --fundador-1 "Ana Silva" \
  --fundador-1-slug "ana" \
  --fundador-1-cargo "CEO" \
  --fundador-2 "Bruno Costa" --fundador-2-slug "bruno" --fundador-2-cargo "CTO" \
  --fundador-3 "Carla Dias" --fundador-3-slug "carla" --fundador-3-cargo "COO"
```

> Flags `--fundador-2-*` e `--fundador-3-*` são opcionais; omita se a diretoria tem
> menos de 3 sócios.

### Passo 5 — Verificação

`grep -rE '\{\{[A-Z_]+\}\}'` pra garantir zero residuais. Se sobrou, listar pro humano.

### Passo 6 — Push

```bash
git push -u origin staging
```

### Passo 7 — Roadmap de próximos passos

```
✅ Cérebro da diretoria inicializado com sucesso!

Este é o 2º cérebro. Você tem 4 próximos passos:

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
1) AGORA — Criar sua estação pessoal neste cérebro
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Se você já tem estação no cérebro do time, o slug aqui deve ser IGUAL.

→ Rode a skill: setup-estacao-pessoal

Atenção: default de privacidade é INVERTIDO em relação ao time:
- No time: público é default, privado é opt-in
- AQUI: privado é default (inbox/{slug}/privado/)

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
2) DEPOIS — Subir o agente Atena em VPS (24/7)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

O agente da diretoria (Atena) precisa rodar em VPS dedicado — de
preferência SEPARADO do VPS do agente do time (isolamento estrutural).

→ Rode a skill em VPS: setup-agente-openclaw

A skill te guia com 2 modos:
- NOVO: sobe Atena do zero no VPS
- MERGE: você já tem OpenClaw no VPS e quer adaptar pra este cérebro

Especificidade da diretoria: o cron de consolidação desta aqui SEMPRE
abre PR — nunca promove direto pra main. Revisão humana obrigatória.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
3) DEPOIS — Conectar seu OpenClaw pessoal aos 2 cérebros
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Este passo é ESPECÍFICO do diretor. Cada sócio tem (ou vai ter) um
OpenClaw pessoal próprio — agente 24/7 que serve APENAS o diretor
(pessoal + profissional). Ele precisa estar conectado aos 2 cérebros
da empresa como VISITANTE — escrevendo em inbox/{diretor}/ em staging.

→ Rode a skill: setup-agente-openclaw

A skill tem 2 modos:
- NOVO: você ainda não tem OpenClaw pessoal. Ela sobe do zero.
- MERGE: você já tem OpenClaw pessoal (ex: Amora do Bruno). Ela:
    * preserva a identidade/tom/skills do seu agente atual
    * adiciona instruções novas no AGENTS.md dele (que agora é visitante
      dos 2 cérebros, com regras de staging, sidecar, 3 gatilhos)
    * clona os 2 repos no workspace dele
    * cria inbox/{diretor}/ em cada
    * instala crons de sync
    * [OPCIONAL] te guia numa transferência inicial de contexto da
      memória do seu agente pessoal pros cérebros da empresa — você
      decide o que migra e pra qual inbox

Esse passo só precisa ser feito uma vez por diretor. Os outros
diretores rodam a mesma skill nos VPS deles quando entrarem.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
4) CONFORME DIRETORIA CRESCER — Convidar outros sócios
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cada novo sócio-diretor:
1. Ganha acesso ao repo (permissão Write)
2. Clona localmente
3. Roda setup-estacao-pessoal no Claude Code (cria inbox/{nome}/)
4. [Se tem OpenClaw pessoal] Roda setup-agente-openclaw no VPS

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dúvidas? Leia:
- README.md — visão geral
- CLAUDE.md — instruções operacionais
- empresa/contexto/PRINCIPIOS.md — regras duras (inclui default privado)
- empresa/contexto/ARQUITETURA.md — modelo dos 2 cérebros
- empresa/contexto/SEGURANCA.md — revogação de acesso, backup, LGPD
- onboarding/GLOSSARIO.md — termos
```

## Allowlist — placeholders intencionais pós-init

Os placeholders abaixo **não** são substituídos por `inicializar-cerebro`. Eles
são preenchidos por outras skills no momento de uso (per-diretor, per-membro,
per-agente-pessoal). O gate final do `inicializar.sh` ignora os itens desta lista
ao verificar resíduos.

| Placeholder | Onde aparece | Skill / momento que preenche |
|---|---|---|
| `{{AGENTE_PESSOAL_NOME}}` | `empresa/skills/cerebro/SKILL.md` (output exemplificado) | Renderizado pelo agente pessoal de cada diretor (ex: Amora) ao executar `/cerebro` |
| `{{SEU_SLUG}}` | `empresa/skills/setup-estacao-pessoal/SKILL.md` (exemplos pra usuário) | Substituído implicitamente pelo `setup-estacao-pessoal` na conversa com o usuário corrente |
| `{{MEMBRO_EQUIPE_SLUG}}` | `empresa/skills/setup-estacao-pessoal/SKILL.md` (exemplos pra usuário) | Idem — exemplo genérico de slug de membro |

Se você adicionar um placeholder novo a este template e ele cair na categoria
"intencionalmente não substituído", inclua-o aqui **e** no array
`ALLOWED_PLACEHOLDERS` em `scripts/inicializar.sh`. Se não, o gate de placeholders
residuais vai rejeitar a inicialização.

## Regras de segurança

Igual ao do template-empresa + extras específicos da diretoria:

- **Repo privado obrigatório** — nunca torne público
- **Addendum de confidencialidade** assinado antes de convidar sócio (recomendado)
- **Rotação de chaves de backup** trimestral (ver SEGURANCA.md)

## Recursos desta skill

- `scripts/inicializar.sh` — script bash (passo 4)

## Depois dessa skill

Arquivo `.cerebro-inicializado` com:

```yaml
inicializado_em: 2026-04-20T15:32:00-03:00
tipo: diretoria
empresa: Acme Corp
agente: Atena
agente_time: Oliver
fundador_principal: Ana Silva
versao_template: 1.0
```

---

*Skill de primeira execução. Roda 1 vez. Segue idêntica em lógica à da template-empresa, com defaults específicos da diretoria.*
