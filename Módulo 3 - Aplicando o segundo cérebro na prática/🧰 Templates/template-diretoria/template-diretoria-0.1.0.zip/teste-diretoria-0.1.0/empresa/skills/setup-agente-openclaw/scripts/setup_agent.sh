#!/usr/bin/env bash
set -euo pipefail

WORKSPACE="${1:-/root/.openclaw/workspace}"
AGENT="${2:?erro: passe o slug do agente como segundo argumento (ex: oliver, iris). Nenhum default é assumido neste template.}"
REPO_DIR="$WORKSPACE/{{EMPRESA_SLUG}}-diretoria"
AGENT_DIR="$REPO_DIR/agentes/$AGENT"

required=(AGENTS.md HEARTBEAT.md IDENTITY.md MEMORY.md SOUL.md TOOLS.md USER.md memory)

if [[ ! -d "$REPO_DIR/.git" ]]; then
  echo "ERRO: repo {{EMPRESA_SLUG}}-diretoria não encontrado em $REPO_DIR" >&2
  exit 1
fi

if [[ ! -d "$AGENT_DIR" ]]; then
  echo "ERRO: diretório do agente não encontrado em $AGENT_DIR" >&2
  exit 1
fi

for name in "${required[@]}"; do
  if [[ ! -e "$AGENT_DIR/$name" ]]; then
    echo "ERRO: arquivo obrigatório ausente: $AGENT_DIR/$name" >&2
    exit 1
  fi
done

ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/AGENTS.md" "$WORKSPACE/AGENTS.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/HEARTBEAT.md" "$WORKSPACE/HEARTBEAT.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/IDENTITY.md" "$WORKSPACE/IDENTITY.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/MEMORY.md" "$WORKSPACE/MEMORY.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/SOUL.md" "$WORKSPACE/SOUL.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/TOOLS.md" "$WORKSPACE/TOOLS.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/USER.md" "$WORKSPACE/USER.md"
ln -sfn "{{EMPRESA_SLUG}}-diretoria/agentes/$AGENT/memory" "$WORKSPACE/memory"

if [[ -f "$AGENT_DIR/.env.example" && ! -f "$AGENT_DIR/.env" ]]; then
  cp "$AGENT_DIR/.env.example" "$AGENT_DIR/.env"
  echo "INFO: .env criado a partir de .env.example em $AGENT_DIR/.env"
fi

echo "OK: symlinks configurados para $AGENT"
ls -l \
  "$WORKSPACE/AGENTS.md" \
  "$WORKSPACE/HEARTBEAT.md" \
  "$WORKSPACE/IDENTITY.md" \
  "$WORKSPACE/MEMORY.md" \
  "$WORKSPACE/SOUL.md" \
  "$WORKSPACE/TOOLS.md" \
  "$WORKSPACE/USER.md" \
  "$WORKSPACE/memory"
