---
name: setup-agente-openclaw
description: Configurar ou migrar o agente gestor do cérebro da diretoria ({{AGENTE_NOME}}) em VPS/OpenClaw, com {{EMPRESA_SLUG}}-diretoria como fonte de verdade. Tem 2 modos — NOVO (OpenClaw do zero) e MERGE (workspace OpenClaw já existente, adapta preservando customizações). O agente descobre suas próprias rotinas lendo `areas/*/rotinas/*.md` e registra os crons nativos do OpenClaw — sem cron Linux, sem CLI externa.
---

# Setup Agente OpenClaw — Diretoria

## Objetivo

Padronizar a subida do **agente gestor deste cérebro** ({{AGENTE_NOME}}) em VPS/OpenClaw, com `{{EMPRESA_SLUG}}-diretoria` como fonte de verdade.

## ⚠️ Especificidade da diretoria — VPS separado + revisão humana obrigatória

Este agente opera sobre conteúdo sensível (3 gatilhos). Recomendações:

1. **Usar VPS dedicado, separado do VPS do agente do time** — isolamento estrutural. Nunca rodar os 2 agentes no mesmo VPS.
2. **Canal de notificação privado** — `TELEGRAM_CHAT_ID` deve ser do grupo restrito dos sócios, nunca do grupo geral do time.
3. **Consolidação nunca promove direto.** Mesmo com `maturidade: pronto-para-canonico`, a consolidação abre **PR único do dia** pra revisão humana. Essa regra está codificada na skill `consolidar-estacoes` desta diretoria.
4. **Backup encriptado offsite semanal** obrigatório (ver `empresa/contexto/SEGURANCA.md`).

## Arquitetura

O agente do OpenClaw é **o LLM** que executa a rotina — não precisa de CLI externa nem de cron do Linux pra orquestrar nada. Setup é 4 blocos:

1. **Repo + identidade** — clone, symlinks dos arquivos canônicos do agente
2. **Segredos** — `.env.example` versionado, `.env` local ignorado
3. **Rotinas** — agente lê `areas/*/rotinas/*.md`, extrai frontmatter, registra crons no próprio OpenClaw
4. **Skills** — ficam disponíveis automaticamente porque estão no repo

Não há `install_crons.sh` nem `run_*.sh`. Cron é nativo do OpenClaw, agendado pelo próprio agente baseado no frontmatter das rotinas.

## Dois modos de setup

### Modo NOVO — OpenClaw do zero no VPS

Use quando:
- VPS recém-provisionado, OpenClaw acabou de ser instalado
- Workspace `/root/.openclaw/workspace-{{AGENTE_SLUG}}/` está vazio

Fluxo: clone do repo → symlinks → `.env.example` → registrar rotinas.

### Modo MERGE — já existe OpenClaw rodando no VPS

Use quando já tem arquivos preenchidos no workspace. Fluxo extra antes dos passos normais:

1. **Backup** do workspace atual → `/root/.openclaw/workspace-backup-YYYYMMDD/`
2. **Ler os arquivos do agente atual** (AGENTS, SOUL, USER, TOOLS etc.)
3. **Apresentar diffs ao humano** (arquivo a arquivo)
4. **AGENTS.md é crítico** — sempre aplicar as regras novas do cérebro da diretoria (VPS separado, canal privado, PR obrigatório). Se tinha regras próprias, preservar como apêndice.
5. **MEMORY.md** — simplificar pro novo formato (só dailies). Memórias temáticas antigas migram pro canônico (`areas/financeiro/contexto/`, `areas/governanca/contexto/`, etc.).

---

## Passos do setup

### Passo 1 — Clonar repo e criar identidade do agente

```bash
cd /root/.openclaw/workspace-{{AGENTE_SLUG}}
test -d {{EMPRESA_SLUG}}-diretoria || git clone https://github.com/{{ORG}}/{{EMPRESA_SLUG}}-diretoria.git
cd {{EMPRESA_SLUG}}-diretoria
git checkout staging
git pull --rebase origin staging
```

Garantir que os arquivos canônicos do agente vivem em `agentes/{{AGENTE_SLUG}}/`:

- `AGENTS.md` · `HEARTBEAT.md` · `IDENTITY.md` · `MEMORY.md` · `SOUL.md` · `TOOLS.md` · `USER.md` · `memory/` · `.env.example`

### Passo 2 — Symlinks no workspace raiz

Criar no `/root/.openclaw/workspace-{{AGENTE_SLUG}}/`:

- `AGENTS.md -> {{EMPRESA_SLUG}}-diretoria/agentes/{{AGENTE_SLUG}}/AGENTS.md`
- `HEARTBEAT.md -> ...` (idem pros outros arquivos + `memory/`)

O script `scripts/setup_agent.sh` faz idempotente.

### Passo 3 — `.env` do agente

- Copiar `agentes/{{AGENTE_SLUG}}/.env.example` → `.env` local (fora do git)
- Preencher: `GITHUB_TOKEN`, `TELEGRAM_BOT_TOKEN` (bot **exclusivo da diretoria**, não compartilhado com time), `TELEGRAM_CHAT_ID` (grupo **restrito aos sócios**)
- `.env` nunca vai pro git

### Passo 4 — Registrar rotinas no OpenClaw

**Esta é a parte que substitui o antigo `install_crons.sh`.** O agente lê as rotinas declaradas no repo e se auto-registra no scheduler do OpenClaw.

O agente faz:

1. **Varrer** todos os arquivos em `areas/**/rotinas/*.md` (ignorar `README.md`)
2. **Parsear o frontmatter YAML** de cada. Exemplo esperado na diretoria:

   ```yaml
   ---
   nome: consolidacao-second-brain
   schedule: "0 5 * * *"
   timezone: UTC
   schedule_legivel: "Diária 02:00 BRT / 05:00 UTC"
   agente: {{AGENTE_SLUG}}
   skill: empresa/skills/consolidar-estacoes/SKILL.md
   canal_notificacao: telegram_privado
   sempre_via_pr: true
   ---
   ```

3. **Filtrar** rotinas onde `agente == {{AGENTE_SLUG}}` (só as dele)
4. **Registrar cada uma no scheduler do OpenClaw** com nome, schedule, timezone, ação (skill apontada)
5. **Confirmar** com o humano: lista das rotinas registradas + próxima execução

Quando o cron do OpenClaw dispara, o agente acorda, lê a skill apontada, e executa usando o próprio LLM.

### Passo 5 — Skills ficam automáticas

Skills vivem em `empresa/skills/` e `areas/**/skills/`. O agente descobre elas sozinho porque estão no repo. Nenhum registro manual necessário.

## Fluxo completo — resumo

```
Setup (uma vez):
  ├─ clone repo + symlinks
  ├─ .env preenchido (tokens DO grupo privado da diretoria)
  ├─ agente lê areas/*/rotinas/*.md
  └─ agente registra rotinas no scheduler do OpenClaw

Operação (contínua):
  └─ OpenClaw dispara cron no horário
     └─ agente lê rotina → lê skill apontada → executa com próprio LLM
        └─ [DIRETORIA] tudo vira PR pra revisão do sócio
```

Zero Linux cron. Zero bash runners. Zero CLI externa.

## Recursos desta skill

- Script idempotente de bootstrap: `scripts/setup_agent.sh`
- Referência operacional: `references/checklist.md`

## Validação final

Depois do setup, conferir:

1. `ls -l /root/.openclaw/workspace-{{AGENTE_SLUG}}/` — symlinks apontando pros canônicos em `agentes/{{AGENTE_SLUG}}/`
2. `.env` local com chaves preenchidas, e `TELEGRAM_CHAT_ID` é o grupo privado dos sócios (duplo-check — nunca canal geral)
3. `.env` não está no `git status`
4. Agente reportou rotinas registradas no scheduler
5. Backup offsite configurado (cron separado ou serviço do provedor)
