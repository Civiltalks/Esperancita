---
name: setup-workstation
description: >
  Configura a estação de trabalho LOCAL de uma pessoa — o layout `~/{{EMPRESA_SLUG}}/` com os repos
  de cérebro (time / diretoria / pessoal) lado a lado + symlinks de skills
  (`sync-empresa`, `sync-diretoria`, `sync-pessoal`, `cerebro`, etc.) em
  `~/{{EMPRESA_SLUG}}/.claude/skills/` pra virarem slash commands no Claude Code.
  Interativa, faz perguntas, não clona nada sem confirmar.
  Use quando: novo membro/diretor acabou de clonar o primeiro repo e está na máquina
  dele sem o layout montado; quando a pessoa trocou de máquina; ou quando
  `~/{{EMPRESA_SLUG}}/.claude/skills/` não existe.
  Palavras-chave: estação de trabalho, workstation, layout local, primeira máquina,
  máquina nova, ~/brains, symlinks, slash commands.
---

# setup-workstation — Layout local `~/{{EMPRESA_SLUG}}/`

> **Não confundir** com `setup-estacao-pessoal` (essa cria `inbox/{slug}/` dentro de um cérebro coletivo — é atômica, escopo repo). `setup-workstation` é um nível acima: configura a **máquina local** — clona os cérebros certos, organiza em `~/{{EMPRESA_SLUG}}/`, e habilita as slash commands do Claude Code.

## O que faz (resumo)

1. Detecta papel da pessoa (membro do time / sócio-diretor).
2. Garante `~/{{EMPRESA_SLUG}}/` com os repos certos lado a lado.
3. Cria `~/{{EMPRESA_SLUG}}/.claude/skills/` com symlinks pras skills (`sync-empresa`, `sync-diretoria`, `sync-pessoal`, `cerebro`, etc.) pra virarem slash commands.
4. Invoca `setup-estacao-pessoal` em cada cérebro coletivo aplicável.
5. Confirma e instrui o usuário a reiniciar o Claude Code.

## Quando usar

- **Primeira máquina.** Pessoa acabou de clonar `{{EMPRESA_SLUG}}-second-brain` em algum lugar e ainda não tem `~/{{EMPRESA_SLUG}}/` montado.
- **Máquina nova.** Identidade (`~/.cowork/{{EMPRESA_SLUG}}-identity`) pode existir no Cowork mas esta máquina local está crua.
- **Layout quebrado.** `~/{{EMPRESA_SLUG}}/.claude/skills/` foi apagado; slash commands sumiram.

## Quando **não** usar

- Já tem `~/{{EMPRESA_SLUG}}/` com os repos aplicáveis e `.claude/skills/` com os symlinks → não rodar.
- Só quer criar `inbox/{slug}/` num repo coletivo → use `setup-estacao-pessoal` direto.
- Pessoa ainda não entende o modelo dos cérebros → use `onboarding-membro-time` ou `onboarding-diretor` primeiro (eles invocam esta skill como parte do fluxo).

## Pré-condições

- [ ] Acesso GitHub aos repos aplicáveis (time sempre; diretoria se sócio; pessoal se sócio)
- [ ] Git configurado (`git config --global user.name/email`)
- [ ] Claude Code instalado
- [ ] `gh` CLI instalado e autenticado (`gh auth status`) — se faltar, sinalizar: `brew install gh && gh auth login`

## Fluxo — 7 passos

### Passo 1 — Perguntar papel

Uma pergunta só:

> _"Qual seu papel na {{EMPRESA}}? (1) membro do time, (2) sócio-diretor"_

Salva como `PAPEL=time` ou `PAPEL=diretor`. Isso define quantos repos vai ter.

| Papel | Repos que vai usar |
|-------|--------------------|
| `time` | só `{{EMPRESA_SLUG}}-second-brain` |
| `diretor` | `{{EMPRESA_SLUG}}-second-brain` + `{{EMPRESA_SLUG}}-diretoria` + cérebro pessoal |

### Passo 2 — Descobrir localização atual do `{{EMPRESA_SLUG}}-second-brain`

O usuário acabou de rodar esta skill de dentro de um clone do `{{EMPRESA_SLUG}}-second-brain`. Detectar via:

```bash
git -C . rev-parse --show-toplevel
```

Chamar esse path de `$TEAM_PATH`. Se não for uma pasta direta filha de `$HOME/{{EMPRESA_SLUG}}/`, avisar que o layout recomendado é `$HOME/{{EMPRESA_SLUG}}/empresa` e perguntar:

> _"O repo tá em `$TEAM_PATH`. Quer que eu mova pra `~/{{EMPRESA_SLUG}}/empresa` (recomendado) ou deixar onde está e usar symlink?"_

Defaults aceitáveis:
- **Mover** (se a pasta atual não tem nada mais importante)
- **Symlink** (`~/{{EMPRESA_SLUG}}/empresa` → path atual) se ele não quer mover

Criar `~/{{EMPRESA_SLUG}}/` se não existir. **Nunca apagar** pasta existente sem confirmar.

### Passo 3 — (Só `PAPEL=diretor`) Clonar diretoria

Checar se `$HOME/{{EMPRESA_SLUG}}/diretoria` já existe. Se não:

```bash
gh repo clone {{ORG}}/{{EMPRESA_SLUG}}-diretoria "$HOME/{{EMPRESA_SLUG}}/diretoria"
```

Se falhar (sem permissão), mostrar URL e pedir pra pessoa falar com o {{FUNDADOR_1_CARGO}}.

### Passo 4 — (Só `PAPEL=diretor`) Clonar cérebro pessoal

Perguntar:

> _"Você já tem cérebro pessoal clonado de `template-second-brain-pessoal`? Se sim, qual é a URL do repo? (ex: `github.com/{seu-user}/{seu-nome}-second-brain`) Se não, posso te ajudar a criar a partir do template."_

- **Já tem** → clonar em `$HOME/{{EMPRESA_SLUG}}/pessoal`
- **Não tem** → orientar:
  1. Fork do template pessoal pra conta pessoal dele (`gh repo fork` ou via web)
  2. Clone do fork em `$HOME/{{EMPRESA_SLUG}}/pessoal`
  3. Rodar `inicializar-cerebro` lá dentro (preenche placeholders)

Armazenar path em `$PESSOAL_PATH`.

### Passo 5 — Criar symlinks de slash commands

Symlinks vêm de **2 fontes diferentes**, dependendo do papel:

| Skill | Fonte | Quem recebe |
|-------|-------|-------------|
| `/cerebro`, `/sync-empresa` | `{{EMPRESA_SLUG}}-second-brain/empresa/skills/{cerebro,sync-empresa}/` | **Todos** (time + diretor) |
| `/sync-diretoria` | `{{EMPRESA_SLUG}}-diretoria/empresa/skills/sync-diretoria/` | **Só diretor** (cérebro diretoria clonado) |
| `/sync-pessoal` (alias `/save`) | `{pessoal}/empresa/skills/sync-pessoal/` | **Só diretor** (cérebro pessoal clonado) |

Cada skill `/sync-*` vive no repo de destino. Triggers em linguagem natural ("salva", "guarda", "comita") só são aceitos por `/sync-pessoal`; cross-brain (`/sync-empresa`, `/sync-diretoria`) exige invocação explícita pra evitar mandar pra repo errado.

```bash
mkdir -p "$HOME/{{EMPRESA_SLUG}}/.claude/skills"

# 1) Skills do cérebro do TIME — /cerebro, /sync-empresa (todos ganham)
TEAM_SKILLS="$HOME/{{EMPRESA_SLUG}}/empresa/empresa/skills"
for skill in cerebro sync-empresa; do
  if [ -d "$TEAM_SKILLS/$skill" ]; then
    ln -sfn "$TEAM_SKILLS/$skill" "$HOME/{{EMPRESA_SLUG}}/.claude/skills/$skill"
    echo "✓ $skill (do cérebro do time)"
  else
    echo "⚠️ $skill não existe em $TEAM_SKILLS — cérebro do time desatualizado?"
  fi
done

# 2) /sync-diretoria — só diretor com cérebro diretoria clonado
DIRETORIA_SKILLS="$HOME/{{EMPRESA_SLUG}}/diretoria/empresa/skills"
if [ "$PAPEL" = "diretor" ] && [ -d "$DIRETORIA_SKILLS/sync-diretoria" ]; then
  ln -sfn "$DIRETORIA_SKILLS/sync-diretoria" "$HOME/{{EMPRESA_SLUG}}/.claude/skills/sync-diretoria"
  echo "✓ sync-diretoria (do cérebro diretoria)"
fi

# 3) /sync-pessoal — só diretor com cérebro pessoal clonado
if [ "$PAPEL" = "diretor" ] && [ -d "$PESSOAL_PATH/empresa/skills/sync-pessoal" ]; then
  ln -sfn "$PESSOAL_PATH/empresa/skills/sync-pessoal" "$HOME/{{EMPRESA_SLUG}}/.claude/skills/sync-pessoal"
  echo "✓ sync-pessoal (do cérebro pessoal)"
fi

# 4) Skills extras do cérebro PESSOAL — só diretor, sem sobrescrever as já criadas
if [ "$PAPEL" = "diretor" ] && [ -d "$PESSOAL_PATH/empresa/skills" ]; then
  for d in "$PESSOAL_PATH/empresa/skills/"*/; do
    skill=$(basename "$d")
    [ -e "$HOME/{{EMPRESA_SLUG}}/.claude/skills/$skill" ] && continue
    ln -sfn "$d" "$HOME/{{EMPRESA_SLUG}}/.claude/skills/$skill"
  done
fi
```

**Resultado:**
- Membro do time → `/cerebro`, `/sync-empresa`
- Sócio-diretor → idem + `/sync-diretoria` + `/sync-pessoal` (alias `/save`) + skills extras do pessoal

### Passo 6 — Invocar `setup-estacao-pessoal` em cada coletivo

- Sempre: rodar `setup-estacao-pessoal` em `$HOME/{{EMPRESA_SLUG}}/empresa`
- Se `PAPEL=diretor`: rodar também em `$HOME/{{EMPRESA_SLUG}}/diretoria`

Cada invocação cria `inbox/{slug}/` e salva `~/.cowork/{{EMPRESA_SLUG}}-identity` / `~/.cowork/{{EMPRESA_SLUG}}-diretoria-identity`.

### Passo 7 — Confirmar e instruir reinício

Reportar em 1 bloco:

```
✓ ~/{{EMPRESA_SLUG}}/ montado com N repos
✓ symlinks de skills em ~/{{EMPRESA_SLUG}}/.claude/skills/ ({lista})
✓ inbox/{slug}/ criado em {time} [e {diretoria}]

Próximo passo: sair do Claude Code, abrir de novo em `~/{{EMPRESA_SLUG}}/`.
  cd ~/brains
  claude
No primeiro turno, rode /cerebro — carrega os CLAUDE.md dos cérebros
em paralelo e confirma que os contextos estão ativos. Durante o dia,
use /sync-empresa pra publicar capturas no time e /sync-diretoria pra
material sensível na diretoria. Diretor: também /sync-pessoal pra
flush local no cérebro pessoal (LN: "salva", "guarda").
```

## Idempotência

Esta skill é idempotente: detecta o que já existe e não sobrescreve. Seguro rodar de novo depois de uma queda parcial.

## Flags de erro

- **`~/{{EMPRESA_SLUG}}/` já existe mas não é uma pasta** → parar e avisar
- **`gh` não instalado** → sugerir `brew install gh && gh auth login`
- **Repo sem permissão** → não tentar clonar com URL com token hardcoded; mostrar só o URL público e pedir pra pessoa resolver acesso antes
- **Symlink destino ocupado por arquivo real** → mostrar path e pedir confirmação antes de sobrescrever

## Notas

- Esta skill **não edita** nenhum arquivo canônico em `empresa/` ou `areas/` do cérebro do time — opera fora do repo (em `~/{{EMPRESA_SLUG}}/` e `~/.cowork/`).
- Pra adicionar/atualizar a skill no template, o canal é proposta canônica em `inbox/{slug}/` com sidecar `tipo: proposta-canonica`.
- Claude Code **não carrega CLAUDE.md em subpastas automaticamente** — só lê do cwd e pastas pai. Por isso a recomendação é abrir o Claude Code em `~/{{EMPRESA_SLUG}}/` (e não dentro de um repo específico) pra que os `CLAUDE.md` dos cérebros sejam todos acessíveis.

## Relação com skills existentes

| Skill | Relação |
|-------|---------|
| `onboarding-membro-time` | Passa a invocar `setup-workstation` no passo de criar estação |
| `onboarding-diretor` (diretoria) | Passa a invocar `setup-workstation` no passo de clonar repos |
| `setup-estacao-pessoal` | É **invocada por** `setup-workstation` em cada coletivo |
| `setup-agente-openclaw` | Complementar — cuida do OpenClaw do agente geral do cérebro ({{AGENTE_NOME}}). Separada desta skill. |
