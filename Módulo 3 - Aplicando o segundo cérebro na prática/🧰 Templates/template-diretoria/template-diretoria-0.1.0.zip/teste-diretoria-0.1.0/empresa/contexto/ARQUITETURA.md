# Arquitetura dos cérebros

## Dois repos disjuntos

Sua empresa opera com dois repositórios complementares:

1. **Cérebro do time** (repo separado, clonado do `template-second-brain-empresa`) — operacional: marketing, vendas, atendimento, operações, produto. Acesso: todo o time.
2. **Este** (cérebro da diretoria) — sensível: financeiro, RH, jurídico, governança. Acesso: só sócios.

Formalmente:

```
C(time) ∩ C(diretoria) = ∅
C(time) ∪ C(diretoria) = conhecimento total da empresa
```

Nenhum conhecimento aparece nos dois. O que um não tem, o outro tem.

## Visão por papel

- Time → vê C(time)
- Sócios-diretores → vê C(time) ∪ C(diretoria) = tudo

## Eixos ortogonais

- **Domínio** (marketing, vendas, RH, jurídico, ...) = pasta em um dos dois repos
- **Sensibilidade** = qual repo o dado mora em

Exemplo: "vendas agregadas do mês" → cérebro do time; "comissão da Ana em abril" → aqui.

## Agentes

- **Agente do time** — tom pragmático, proativo.
- **Agente da diretoria** (este repo) — tom prudente, revisão humana obrigatória.

Agentes **não compartilham contexto**. Sócio (humano) é a ponte entre os dois.

## Fluxo de decisão ao capturar

1. Tem dinheiro com nome próprio? → diretoria (aqui).
2. Tem pessoa específica? → diretoria.
3. Tem peso contratual/jurídico? → diretoria.
4. Nada disso? → cérebro do time.

## Por que dois repos, não um só com filtro

Um cérebro só com filtros de permissão é frágil:
- LLM erra e expõe sensível
- GitHub só tem permissão por repo, não por pasta
- Rotinas automatizadas podem vazar em logs, backups ou MCPs mal configurados

Dois repos disjuntos dão **garantia estrutural** em vez de depender de lógica de runtime.

## Ordem de evolução

O cérebro do time vem primeiro (nasce com a empresa). Este cérebro nasce quando aparece:
- Primeira contratação formal com CLT/PJ
- Primeiro contrato com distribuição/equity/NDA
- Primeira decisão que envolve remuneração variável individual
- Primeira situação de RH que requer registro
