# Princípios do cérebro da diretoria

## 1. Fonte única de verdade

Este repositório é a fonte canônica dos dados sensíveis da sua empresa. Tudo que está fora dele é tráfego. O que importa na diretoria precisa chegar aqui.

## 2. Inbox é triagem, não memória

`inbox/{sócio}/` é staging pessoal. Qualquer coisa aqui é provisória até a rotina noturna abrir PR pra revisão humana.

## 3. Sidecar `.meta.yaml` é obrigatório

Toda captura vem com um sidecar `foo.ext.meta.yaml` irmão.

Schema:

```yaml
autor: {nome}
data: 2026-04-20T02:00
fonte: conversa | pesquisa | captura-solo | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
destino_sugerido: areas/governanca/contexto/decisoes/...
relacionado: []
tags: []
```

## 4. Privacidade é default

**Default: `inbox/{sócio}/privado/`** (gitignored). Só saia pra área pública quando o item for claramente compartilhável com toda a diretoria.

Contraste com o cérebro do time: lá default é público. **Aqui é privado.**

## 5. A regra dos 3 gatilhos

Um conteúdo pertence a **este repositório** se dispara qualquer um destes 3 gatilhos:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual, pró-labore, dívida nominal.
2. **Pessoa específica** — avaliação, feedback direto, conflito, contratação, desligamento.
3. **Peso contratual ou jurídico** — contratos assinados, NDAs, litígios, LGPD, compliance.

Se **não dispara nenhum** → fica no cérebro do time, não aqui.

## 6. Agente escreve em inbox, humano aprova canônico

**Especificidade da diretoria:** mesmo com `maturidade: pronto-para-canonico`, o agente NUNCA promove direto. Sempre abre PR pra revisão humana.

## 7. Anonimização quando possível

Mesmo aqui, preferir "Diretor X aprovou" quando o nome não é essencial. Menos risco de vazamento se o repo for auditado.

## 8. Revogação de acesso no desligamento

Desligamento de sócio ou mudança de papel que retire direito à diretoria → revogar invite do GitHub **no mesmo dia**. Detalhes em `SEGURANCA.md`.

---

_Nota para este template (diretoria):_
Este é o cérebro sensível. Acesso restrito. Qualquer item aqui deve cumprir a regra dos 3 gatilhos. Se não cumpre, mova pro cérebro do time.
