# Segurança do cérebro da diretoria

## ⚠️ Este repo é sensível

Todo commit aqui deve ser feito com cautela. **Na dúvida: não commite. Pergunte antes.**

## O que nunca commitar

- **Credenciais** — tokens, passwords, chaves privadas, `.env`, `google_*.json`, `.key`, `.pem`
- **Dados pessoais identificáveis** de funcionários além do estritamente necessário (CPF, RG, endereço residencial, dado bancário pessoal)
- **Números financeiros nominais** de funcionário sem anonimização quando possível
- **Contratos assinados digitalizados** — mantenha em storage encriptado separado (drive com 2FA), aqui só referência
- **Conversas privadas na íntegra** — resuma, anonimize, contextualize
- **Diagnóstico de saúde** de pessoa nomeada, em qualquer circunstância

## Default de privacidade

Invertido em relação ao cérebro do time: aqui, o **default é privado**. Use `inbox/{sócio}/privado/` (gitignored) como padrão. Só saia pra pública quando o item for claramente compartilhável com toda a diretoria.

## Convite de sócios

- Só quem é sócio-diretor é elegível
- Acesso exclusivo via GitHub Org, permissão "Admin" ou "Write" dependendo do papel
- Cada sócio deve rodar `setup-estacao-pessoal` na primeira sessão
- Recomendado: addendum de confidencialidade assinado antes do invite

## Revogação

- **Desligamento de sócio** → revogar invite do GitHub **no mesmo dia**
- **Mudança de papel** que retire direito à diretoria → revogar acesso a este repo, manter acesso ao cérebro do time se papel operacional permanecer

## Backup

- Backup encriptado offsite **semanal** (defina responsável)
- Rotação de chaves de backup **trimestral**
- Teste de restauração **semestral** (restaurar pra ambiente isolado, verificar integridade)

## Vazamento suspeito

- Reportar **imediatamente** a todos os sócios (canal privado)
- **Não apagar nada** sem combinar — perde evidência
- Se for erro próprio (commit acidental), ser honesto. Consertar é rápido; esconder cria dívida

Passos técnicos imediatos:
1. Rotacionar credenciais expostas
2. Remover do HEAD + adicionar ao `.gitignore`
3. Decidir se vale `git filter-repo` (reescreve histórico)
4. Documentar incidente em `areas/governanca/contexto/gestao/licoes.md`

## Integridade do repo

- `main` só é atualizada por PR revisado por um sócio
- `staging` aceita commits diretos em `inbox/{sócio}/`
- Nenhum commit aceita `git add .` ou `git add -A` — sempre `git add inbox/{sócio}/`

## LGPD

Se sua empresa processa dados pessoais de clientes/colaboradores, o controle formal (registro de operações, política de privacidade, relatório de impacto) vive em `areas/juridico/contexto/LGPD.md` — não aqui.
