# MAPA — empresa/

Pasta transversal a todas as áreas da diretoria. Princípios, arquitetura, segurança reforçada e skills compartilhadas.

## Conteúdo

- `contexto/PRINCIPIOS.md` — regra dos 3 gatilhos, privacidade **default privado**, sidecar obrigatório
- `contexto/ARQUITETURA.md` — modelo dos 2 cérebros disjuntos (ponto de vista da diretoria)
- `contexto/SEGURANCA.md` — o que nunca commitar, revogação de acesso, backup, LGPD
- `skills/consolidar-estacoes/` — rotina noturna (aqui sempre abre PR, nunca promove direto)
- `skills/setup-estacao-pessoal/` — cria estação pessoal pra novo sócio
- `skills/_index.md` — catálogo

## Arquivos que você pode adicionar

- `contexto/equipe.md` — lista nominal completa (sócios + equipe, se quiser registro aqui)
- `contexto/ADDENDUM-NDA.md` — modelo de addendum de confidencialidade pra novos sócios
