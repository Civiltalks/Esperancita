# template-second-brain-diretoria

Template de **cérebro sensível da diretoria** para empresas que operam com agentes de IA (OpenClaw + Claude Code). Construído pela Pixel Educação como parte do Pixel AI Hub.

> **Não use antes do `template-second-brain-empresa`.**
> Este repositório é o **segundo** cérebro da sua empresa — o primeiro é o `template-second-brain-empresa`.

## Leia isto antes de clonar

Este repo é desenhado para dados que disparam a **regra dos 3 gatilhos**:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual
2. **Pessoa específica** — avaliação, conflito, contratação
3. **Peso contratual/jurídico** — contrato, NDA, litígio

Nada que não dispare algum desses três deve entrar aqui.

## Quando abrir

Depois que sua empresa:

- Tem time rodando o `template-second-brain-empresa` como rotina (idealmente 60+ dias)
- Precisou registrar algo nominal/financeiro/jurídico pela primeira vez

## O que você ganha clonando

- Estrutura de cérebro sensível pronta (4 áreas: financeiro, rh, juridico, governanca)
- Agente da diretoria pré-configurado (`geral-diretoria`) com tom prudente e revisão humana obrigatória
- **3 skills essenciais:**
  - `setup-estacao-pessoal` — cria `inbox/{sócio}/` no primeiro uso
  - `consolidar-estacoes` — rotina noturna (sempre via PR aqui — revisão humana obrigatória)
  - `setup-agente-openclaw` — orquestra setup do **agente pessoal OpenClaw** de cada diretor em VPS dedicado, conectando aos 2 cérebros (time + diretoria) como visitante
- Wizard de setup em [`onboarding/SETUP.md`](onboarding/SETUP.md) com **checklist de maturidade** antes de começar
- Documentação dos princípios específicos da diretoria (sidecar, privacidade **default privado**, 3 gatilhos, 2 cérebros, gestor vs visitante)

## Começar

Depois de clonar este template via "Use this template", o **primeiro comando** é rodar a skill **`inicializar-cerebro`** no Claude Code / Cowork — tutorial + configurador (preenche placeholders, renomeia pasta do agente). Roda 1 vez só.

Roteiro completo (10 fases, inclui checklist de maturidade e setup dos 2 VPS — do agente da diretoria e do OpenClaw pessoal de cada sócio): [`onboarding/SETUP.md`](onboarding/SETUP.md).

## Estrutura

```
template-second-brain-diretoria/
├── README.md
├── CLAUDE.md
├── MAPA.md
├── LICENSE
├── onboarding/SETUP.md + GLOSSARIO.md
├── agentes/geral-diretoria/
├── areas/
│   ├── financeiro/
│   ├── rh/
│   ├── juridico/
│   └── governanca/
├── empresa/           # princípios, arquitetura, segurança reforçada
└── inbox/
```

**Áreas são diferentes** do template-empresa. Não há `marketing`, `vendas`, `atendimento`, `operacoes`, `produto` aqui — esses vivem no cérebro do time.

## Quem escreve onde

| ator | papel | como escreve |
|---|---|---|
| **Sócios (humanos)** | visitantes do canônico | sempre via `inbox/{slug}/` — nunca direto |
| **{{AGENTE_NOME}}** (agente da diretoria) | **gestor deste cérebro** | direto em `empresa/`, `areas/`, `agentes/{{AGENTE_NOME}}/`. Sem inbox próprio aqui. Promoção a `main` sempre via PR. |
| **Agente pessoal de cada diretor** (OpenClaw 24/7 em VPS do diretor) | visitante deste repo + do cérebro do time | escreve em `inbox/{diretor}/` em staging — nunca canônico. Setup via skill `setup-agente-openclaw`. |
| **{{AGENTE_TIME_NOME}}** (agente do time) | **sem acesso a este repo** | não existe `inbox/{{AGENTE_TIME_NOME}}/` — propagação time→diretoria é sempre feita por um sócio humano |

Propagação cross-brain (diretoria ↔ empresa) é responsabilidade de cada **sócio humano** via `/sync-empresa` ou `/sync-diretoria` em sessão Claude Code com os cérebros clonados lado a lado. Não há mais "canal diplomático" do agente da diretoria — cada diretor é o responsável pelo próprio fluxo cross-repo.

## Onboarding de diretor

Primeira vez como sócio-diretor no sistema? Seu setup completo é:

1. **Acesso aos 2 repos** — obtenha invite na Organização GitHub com permissão "Write" em ambos.
2. **Clonar os 2 repos** no seu laptop pra sessões on-demand via Claude Code / Cowork.
3. **Rodar `setup-estacao-pessoal` em cada repo** — cria suas `inbox/{seu-slug}/` em ambos.
4. **Subir o agente pessoal OpenClaw** em VPS dedicado seu — use a skill **`empresa/skills/setup-agente-openclaw/`** (ver [SKILL.md](empresa/skills/setup-agente-openclaw/SKILL.md)). Ela orquestra clone, estação em ambos, crons de sync, validação.
5. **Configurar `.env` local** com suas chaves pessoais (nunca commitar).
6. **Ler `CLAUDE.md` + `empresa/contexto/PRINCIPIOS.md` + `empresa/contexto/SEGURANCA.md`** pra entender a regra dos 3 gatilhos e a política de privacidade (default privado aqui).

O agente pessoal é **visitante** dos 2 cérebros — nunca escreve canônico. {{AGENTE_TIME_NOME}} (time) e {{AGENTE_NOME}} (diretoria) são os gestores que consolidam suas capturas.

## Relação com o outro repo

Dois repos disjuntos. Agentes independentes. Diretor tem acesso aos dois; time, só ao `template-second-brain-empresa` clonado. Diagrama em [`empresa/contexto/ARQUITETURA.md`](empresa/contexto/ARQUITETURA.md).

## Licença

Uso restrito aos assinantes do Pixel AI Hub. Ver [LICENSE](LICENSE).
