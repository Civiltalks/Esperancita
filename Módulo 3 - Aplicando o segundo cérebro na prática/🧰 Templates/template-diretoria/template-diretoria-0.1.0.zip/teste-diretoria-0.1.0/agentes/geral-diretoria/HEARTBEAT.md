# HEARTBEAT — {{AGENTE_NOME}}

## Rotinas ativas

| rotina                         | frequência       | skill                 |
|--------------------------------|------------------|-----------------------|
| Consolidação noturna (PR only) | 02:00 BRT diário | consolidar-estacoes   |

## Como agendar

Scheduled Task / cron:
- **Schedule:** `0 5 * * *` (02:00 BRT = 05:00 UTC)
- **Prompt:** `"Rodar skill consolidar-estacoes no repo {{EMPRESA_SLUG}}-diretoria"`

## Especificidade da diretoria

**Nunca promove direto.** Mesmo com `maturidade: pronto-para-canonico`, a consolidação deste repo sempre abre PR pra revisão humana.

## Verificações periódicas

### 1. Inboxes e capturas travadas
- Inspecionar `inbox/*/` (sócios + agentes pessoais de diretores)
- Se houver captura importante parada há mais de 5 dias sem sidecar ou sem evolução → alertar o sócio

### 2. Prazos de contratos
- Verificar `areas/juridico/contexto/CONTRATOS-ATIVOS.md` (quando existir)
- Se renovação/vencimento em menos de 30 dias → alertar

### 3. Saúde dos crons
- Listar crons do VPS do {{AGENTE_NOME}} e dos VPS dos agentes pessoais de diretor
- Se qualquer cron tiver `consecutiveErrors >= 2` → alertar sócio imediatamente

### 4. Consolidação de memória local
- Ler `memory/YYYY-MM-DD.md`
- Notas há mais de 5 dias → escrever direto no canônico (sou gestor), PR abre na próxima consolidação

### 5. Checagem de segurança semanal
- Verificar `.gitignore` cobre `agentes/*/google_*.json`, `.env`, `*.key`, `inbox/*/privado/`
- Se encontrar arquivo sensível no staging → alertar e sugerir remoção

## Canal de alertas

**Privado da diretoria** (configurar separado do canal do time). Nunca alertar em canal compartilhado com time.

---

*Template: ajuste canais e prazos conforme sua empresa.*
