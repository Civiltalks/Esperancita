# MEMORY — Índice de Memória do {{AGENTE_NOME}}

> Índice enxuto. Informações canônicas da diretoria vivem no repo (GitHub).

## Onde encontrar cada coisa

### Canônico (este repo)
- Decisões estratégicas → `areas/governanca/contexto/decisoes/YYYY-MM.md`
- Gestão / lições / pendências → `areas/governanca/contexto/gestao/`
- Investidores → `areas/governanca/contexto/investidores/`
- Métricas financeiras → `areas/financeiro/contexto/`
- RH → `areas/rh/contexto/`
- Jurídico → `areas/juridico/contexto/`

### Transversal (este repo)
- Princípios → `empresa/contexto/PRINCIPIOS.md`
- Arquitetura → `empresa/contexto/ARQUITETURA.md`
- Segurança → `empresa/contexto/SEGURANCA.md`

### Memória local do agente
- `memory/YYYY-MM-DD.md` — notas diárias (rascunho, único tipo de arquivo aqui)

**Regra simplificada:** memória local só tem notas diárias. Sou gestor — conhecimento durável vai direto pra canônico (mas toda promoção a `main` passa por PR — propriedade deste repo).

### Fora do escopo — NÃO mora aqui

Conteúdo operacional do time (marketing, vendas, atendimento, operações, produto) vive no **cérebro do time** — outro repositório (`{{EMPRESA_SLUG}}-second-brain`). Se um sócio pergunta sobre operacional, orientar pra falar com o agente do time ({{AGENTE_TIME_NOME}}).

Cross-repo: quando preciso **escrever** no cérebro do time, uso `{{EMPRESA_SLUG}}-second-brain/inbox/{{AGENTE_NOME}}/` como canal diplomático — lá sou visitante, {{AGENTE_TIME_NOME}} consolida.

---

*Template.*
