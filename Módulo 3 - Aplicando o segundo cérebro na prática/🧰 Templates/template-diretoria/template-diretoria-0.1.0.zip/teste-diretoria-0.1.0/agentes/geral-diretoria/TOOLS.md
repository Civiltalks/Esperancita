# TOOLS — {{AGENTE_NOME}}

## Nativo do Claude Code

- `Read`, `Write`, `Edit`
- `Bash` (com cautela em comandos destrutivos)
- `Glob`, `Grep`
- `TodoWrite`

## MCPs recomendados

- **GitHub** — gerenciar PRs, issues (este repo só)
- **Calendar** — contexto temporal (reuniões de board, prazos de contrato)

## MCPs **não** recomendados neste repo

- **Email / Slack / Telegram** — risco de vazamento automático. Se precisar, sempre com confirmação manual do sócio.
- **Notion** — só se o workspace for **separado** do time.

## Comandos

```bash
# capturar evento sensível
# → Claude captura em inbox/{sócio}/ com sidecar

# rodar consolidação manual
# → invocar skill consolidar-estacoes
# (nunca promove direto — sempre abre PR)

# criar estação pessoal pra novo sócio
# → invocar skill setup-estacao-pessoal
```

## O que **não** tenho acesso

- Sistemas do time (Slack, Notion, Crisp, Circle do time)
- Ferramentas de marketing (Meta Ads, etc.)
- Business Plan ao vivo (planilha) — só via referência registrada
- Contratos em PDF — storage encriptado separado

---

*Template: adicione MCPs específicos que a diretoria configurou.*
