# CLAUDE.md — Operação do Claude no cérebro da diretoria

<!-- template-only-start -->
> Instruções pro Claude Code / Cowork operar neste repositório (cópia do `template-second-brain-diretoria`). Substitua os placeholders `{{...}}` pelos dados da sua empresa via skill `inicializar-cerebro`.
<!-- template-only-end -->

## ⚠️ Contexto

Este repositório contém dados que disparam a **regra dos 3 gatilhos** — dinheiro nominal, pessoa específica, peso contratual/jurídico. Acesso restrito aos sócios. **Na dúvida, não commite. Pergunte antes.**

## Papel do Claude

O Claude Code atua como **estação local de trabalho** de um diretor específico. Cada diretor tem sua estação em `inbox/{sócio}/`.

Ele pode:
- explorar o repositório
- editar arquivos sob instrução explícita
- produzir drafts e propostas
- capturar o que surge na sessão

A consolidação do que vira memória oficial é do agente `{{AGENTE_NOME}}` (geral da diretoria), via skill `consolidar-estacoes`, **com revisão humana obrigatória em todo PR**.

## Fonte de verdade

- Este repositório é o cérebro **sensível** da sua empresa.
- O cérebro operacional (não-sensível) vive em repo separado, clonado do `template-second-brain-empresa`.
- **Não compartilhar contexto** entre os dois repos. Os agentes são independentes; diretor é a ponte.
- `inbox/` é triagem, não memória oficial.

## Regra estrutural (estrita)

Toda área tem apenas 3 pastas:

- `contexto/` — estado, conhecimento, artefatos
- `rotinas/` — automações (crons do agente)
- `skills/` — habilidades invocáveis

Cada área tem `MAPA.md` na raiz.

## Modelo de sincronização — branch `staging`

Todo mundo trabalha em `staging`. `main` só é atualizada pela rotina noturna de consolidação, com **revisão humana obrigatória** antes de merge (mesmo para `pronto-para-canonico`).

### Quem é gestor vs quem é visitante

- **{{AGENTE_NOME}} (agente da diretoria)** — gestor deste cérebro. Escreve **direto** em canônico (`empresa/`, `areas/`, `agentes/{{AGENTE_NOME}}/`) durante o dia. Não usa inbox próprio aqui. Mas mesmo gestor, promoção pra `main` passa por PR com revisão humana (propriedade deste repo).
- **Sócios humanos** (diretores) — visitantes do canônico. Capturam **sempre** em `inbox/{seu-slug}/`.
- **Agente pessoal de cada diretor** (OpenClaw 24/7 em VPS do diretor, um por sócio) — visitante deste repo. Escreve em `inbox/{diretor}/` em staging. Setup via skill `setup-agente-openclaw`.
- **Agente do time** ({{AGENTE_TIME_NOME}}, outro repo) — **não tem acesso aqui**. Não existe `inbox/{{AGENTE_TIME_NOME}}/` neste repo. Propagação time→diretoria é sempre feita por sócio humano.
- **Claude Code / Cowork em sessão humana** — opera sempre como visitante (comportamento de sócio).

### Regra dura (humanos e Claude em sessão)

```bash
git add inbox/{sócio}/
git commit -m "..."
```

**Nunca** `git add .` ou `git add -A`.

Esta regra **não se aplica ao {{AGENTE_NOME}}** rodando autonomamente no VPS dele — ele é gestor e escreve canônico direto (ainda passando por revisão humana em cada promoção a `main`).

### Edição de canônico

Qualquer pedido de edição em `areas/**` ou `empresa/**` vira **proposta** em `inbox/{sócio}/` com sidecar `.meta.yaml` (`tipo: proposta-canonica`). A consolidação noturna abre PR pra revisão humana.

### Fluxo de sessão

```bash
git fetch origin
git checkout staging
git pull --rebase origin staging

# ... trabalho em inbox/{sócio}/

git add inbox/{sócio}/
git commit -m "..."
git pull --rebase origin staging
git push origin staging
```

## Sidecar `.meta.yaml` obrigatório

Toda captura vem com sidecar irmão `{arquivo.ext}.meta.yaml`. Sem sidecar, a consolidação não promove.

## Privacidade — default é privado (UX, não versionamento)

Invertido em relação ao cérebro do time **como UX**. Aqui, o **default é `inbox/{sócio}/privado/`**. Só saia pra pública quando o item for claramente compartilhável com toda a diretoria.

> `inbox/{sócio}/privado/` é **gitignored uniforme nos 3 cérebros** (decisão Cayo, review 23/04 item #4). Privado é scratch space local — nunca sobe pro git, nem fica versionado. Sócio que precisa sincronizar entre máquinas do próprio scratch usa o **cérebro pessoal dele** (clone separado, na conta GitHub pessoal — sincroniza via push/pull). O agente {{AGENTE_NOME}} ignora `privado/` na consolidação — privado nunca vira canônico.

## Regras específicas da diretoria

1. **Nunca processar `inbox/{sócio}/privado/`** — o agente ignora essa pasta mesmo na consolidação.
2. **Nunca citar conteúdo deste repo em conversa com o agente do time** (no outro repo).
3. **Anonimizar quando possível.** "Diretor X aprovou" é preferível a "{{FUNDADOR_1}} aprovou" mesmo aqui.
4. **Revogação de acesso no desligamento** — procedimento em `empresa/contexto/SEGURANCA.md`.
5. **Contratos assinados ficam em storage encriptado separado** (drive com 2FA). Aqui só referência e resumo.

## Ordem de navegação

1. Raiz deste repo (`MAPA.md` + este `CLAUDE.md`)
2. `MAPA.md` da área
3. `skills/_index.md` pra skills
4. Arquivos específicos

## O que evitar

- Não tratar `inbox/` como memória oficial
- Não editar canônico sem proposta no inbox
- **Nunca** `git add .` ou `git add -A`
- **Nunca** commitar fora de `inbox/{sócio}/` na branch `staging`
- **Nunca** copiar conteúdo deste repo pro cérebro do time

---

<!-- template-only-start -->
*Gerado a partir do template-second-brain-diretoria (Pixel AI Hub). Substitua os `{{...}}` pelos dados da sua empresa via skill `inicializar-cerebro`.*
<!-- template-only-end -->
