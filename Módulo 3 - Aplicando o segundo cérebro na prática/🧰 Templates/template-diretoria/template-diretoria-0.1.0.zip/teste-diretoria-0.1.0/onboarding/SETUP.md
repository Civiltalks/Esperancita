# SETUP — Cérebro da diretoria

> Wizard do `template-second-brain-diretoria`. Este é o **segundo** cérebro da sua empresa. Leia o checklist de maturidade antes de começar.

## ⚠️ Você está pronto pra abrir este repo?

**Não abra antes de ter:**

- [ ] `template-second-brain-empresa` clonado e rodando há pelo menos **60 dias**
- [ ] Todo o time com estação pessoal funcional
- [ ] Rotina de consolidação noturna rodando sem problema
- [ ] Pelo menos 1 caso real de captura que disparou a regra dos 3 gatilhos

Se algum item está vazio, volte pro template-empresa e opere lá até completar.

---

## Você é qual aluno?

Igual ao SETUP do empresa, este template suporta **3 cenários**. Identifique o seu:

| Persona | O que tem hoje | Onde o agente da diretoria roda |
|---|---|---|
| **1. Só Claude Code** | Laptop. Sem VPS. | Consolidação via **Claude Code Scheduled Task** no laptop |
| **2. Só OpenClaw** | VPS com OpenClaw. | Consolidação no **OpenClaw VPS dedicado** da diretoria |
| **3. Claude Code + OpenClaw** | Laptop + VPS. | Cérebro é **um repo único, clonado nos 2 lugares** — git sincroniza |

**Especificidade da diretoria:** consolidação **sempre abre PR** (nunca promove direto a main), independente da persona — é propriedade do repo (`.github/CODEOWNERS` + branch protection).

## O que você vai conseguir

- Cérebro sensível da diretoria versionado no GitHub
- Sua estação pessoal de sócio (`inbox/{seu-slug}/`)
- Agente da diretoria (`geral-diretoria`) configurado com tom prudente, como gestor
- Revisão humana obrigatória em todo PR de canônico (propriedade deste repo)
- `/sync-diretoria` funcionando como slash command com gates extras
- Base pra operar 2 cérebros (empresa + diretoria) em paralelo

## Pré-requisitos

| Item | Persona 1 | Persona 2 | Persona 3 |
|---|---|---|---|
| Conta GitHub na **mesma Org** do template-empresa | ✓ | ✓ | ✓ |
| Time `@{{SUA_ORG}}/socios` criado na Org | ✓ | ✓ | ✓ |
| Claude Code instalado | ✓ | — | ✓ |
| VPS com OpenClaw | — | ✓ | ✓ |
| `gh` CLI + `gh auth login` | ✓ | ✓ | ✓ |
| Lista de sócios definida | ✓ | ✓ | ✓ |

Tempo: **~1h** + branch protection + lista de sócios.

---

## Skills (na ordem)

| # | Skill | Onde rodar |
|---|---|---|
| 1 | `inicializar-cerebro` | Claude Code (Persona 1, 3) ou VPS via bash (Persona 2). 1 vez só |
| 2 | `setup-workstation` | Claude Code (Persona 1, 3). Orquestra layout `~/{{EMPRESA_SLUG}}/` + symlinks |
| 3 | `setup-agente-openclaw` | VPS (Persona 2, 3). Modo NOVO ou MERGE. **Persona 1 pula** |
| 4 | `onboarding-diretor` | Claude Code, ponta-a-ponta pra novo sócio. Wizard ~30-40min |
| 5 | `/sync-diretoria` | Claude Code (Persona 1, 3) ou OpenClaw (Persona 2, 3). Diário com gates extras |
| 6 | `consolidar-estacoes` | Scheduled Task (Persona 1) ou cron OpenClaw (Persona 2, 3). **Sempre abre PR.** |

---

## Fase 1 — Definir diretoria

1. Lista de diretores (quem tem poder de decisão sobre pessoas, dinheiro, contratos)
2. Cada diretor já tem acesso ao cérebro do time
3. Addendum de confidencialidade assinado (opcional, recomendado)

## Fase 2 — Criar seu fork

1. Acesse `github.com/pixel-educacao/template-second-brain-diretoria`.
2. **"Use this template" → "Create a new repository"**.
3. Owner: sua Organização (mesma do template-empresa). Nome sugerido: `{{EMPRESA_SLUG}}-diretoria`.
4. Visibilidade: **Private** (obrigatório).

## Fase 3 — Clonar local

```bash
mkdir -p ~/{{EMPRESA_SLUG}}
cd ~/{{EMPRESA_SLUG}}
git clone git@github.com:{{SUA_ORG}}/{{EMPRESA_SLUG}}-diretoria.git diretoria
cd diretoria
git checkout -b staging
git push -u origin staging
```

Convenção: pasta local `diretoria/` (clones dos 3 cérebros ficam lado a lado em `~/{{EMPRESA_SLUG}}/`).

## Fase 3a — ⚠️ AÇÃO MANUAL OBRIGATÓRIA — branch protection

**Antes do primeiro uso do cérebro**, configure branch protection em
`https://github.com/{{SUA_ORG}}/{{EMPRESA_SLUG}}-diretoria/settings/branches`
para a branch `main`:

- [ ] **Require a pull request before merging**
- [ ] **Require approvals** — mínimo **1** (recomendado: número de sócios menos 1, pra um PR de qualquer sócio sempre exigir aprovação de pelo menos um outro)
- [ ] **Require review from Code Owners** (lê `.github/CODEOWNERS`, que aponta pra `@{{SUA_ORG}}/socios` — esse time precisa existir)
- [ ] **Dismiss stale pull request approvals when new commits are pushed**
- [ ] **Restrict who can push to matching branches** — apenas o agente da diretoria via deploy key (e bloqueia push direto de humanos)
- [ ] **Require linear history** *(opcional, recomendado)*

> **Sem essas configurações, a regra "revisão humana obrigatória" do CLAUDE.md é apenas verbal** — qualquer pessoa com permissão de escrita pode mergear direto em `main`. O `.github/CODEOWNERS` e o `.github/PULL_REQUEST_TEMPLATE.md` que vêm no template **só têm efeito quando branch protection está ativa**.

> Crie também o time `@{{SUA_ORG}}/socios` na sua organização (Settings → Teams) e adicione todos os diretores com permissão "Maintain" ou "Write" ao repo.

## Fase 3b — Inicializar o cérebro

**Persona 1 e 3 (Claude Code):**
> No Claude Code aberto em `~/{{EMPRESA_SLUG}}/diretoria/`:
>
> "Rode a skill inicializar-cerebro"

**Persona 2 (só OpenClaw):**
> No VPS, dentro do clone:
>
> ```bash
> bash empresa/skills/inicializar-cerebro/scripts/inicializar.sh \
>   --empresa "Acme Corp" --empresa-slug "acme" \
>   --tipo-empresa "LTDA" \
>   --email-diretoria "diretoria@acme.com" \
>   --agente-nome "Atena" --agente-slug "atena" \
>   ...  # ver SKILL.md pra lista completa
> ```

O que ela faz:
1. Explica especificidades da diretoria (3 gatilhos, default privado, revisão humana obrigatória)
2. Substitui placeholders em todos os arquivos
3. Renomeia `agentes/geral-diretoria/` → `agentes/{slug-do-seu-agente}/`
4. Remove blocos `<!-- template-only-* -->`
5. Cria `.cerebro-inicializado`
6. Commit em staging

Roda 1 vez só.

## Fase 4 — Configurar workstation local (Persona 1 e 3)

> Persona 2 (só OpenClaw): pula esta fase.

No Claude Code:

> "Rode a skill setup-workstation"

A orquestradora cuida de:
1. Detectar papel (sócio-diretor)
2. Garantir layout `~/{{EMPRESA_SLUG}}/{empresa,diretoria,pessoal}/` lado a lado
3. Criar symlinks de slash commands (`/cerebro`, `/sync-empresa`, `/sync-diretoria`, `/sync-pessoal` (alias `/save`))
4. Invocar `setup-estacao-pessoal` neste repo (cria `inbox/{seu-slug}/` com default privado invertido)
5. Confirmar e instruir a reiniciar Claude Code

Após reiniciar: abrir Claude na pasta-mãe `~/{{EMPRESA_SLUG}}/`, rodar `/cerebro` no primeiro turno.

## Fase 5 — Configurar o agente em VPS (Persona 2 e 3)

> Persona 1 (só Claude Code): pula esta fase. Sua consolidação roda via Scheduled Task local na Fase 7.

A `setup-agente-openclaw` configura o **agente da diretoria** (geral-diretoria) e/ou o **agente pessoal de cada diretor** — ambos via mesma skill (modos NOVO/MERGE).

**Para o agente da diretoria (gestor deste cérebro, em VPS dedicada coletiva):**

```bash
cd ~/openclaw/workspace/{{EMPRESA_SLUG}}-diretoria  # ou path do seu OpenClaw coletivo
bash empresa/skills/setup-agente-openclaw/scripts/setup_agent.sh
```

**Para o agente pessoal de um diretor (em VPS dele, opcional, recomendado):**

```bash
# No VPS pessoal do diretor:
cd ~/openclaw/workspace
git clone git@github.com:{{SUA_ORG}}/{{EMPRESA_SLUG}}-diretoria.git
cd {{EMPRESA_SLUG}}-diretoria
bash empresa/skills/setup-agente-openclaw/scripts/setup_agent.sh
# (modo MERGE se OpenClaw já existia; modo NOVO do zero)
```

Agente pessoal é **sempre visitante** dos 2 cérebros — escreve só em `inbox/{diretor}/` em staging via `/sync-diretoria` (que detecta o modo cross-brain quando `~/{{EMPRESA_SLUG}}/pessoal/` existe).

Ver [`../empresa/skills/setup-agente-openclaw/SKILL.md`](../empresa/skills/setup-agente-openclaw/SKILL.md).

## Fase 6 — Captura via `/sync-diretoria` (gates extras)

`/sync-diretoria` é **mais rigorosa** que `/sync-empresa` — propriedade do cérebro sensível:

| Gate | `/sync-empresa` | `/sync-diretoria` |
|---|---|---|
| 3 gatilhos | bloqueia | **awareness explícito** (sócio confirma item-a-item) |
| Default destino | público ao time | **privado/ por default** (invertido) |
| Anonimização | n/a | **sugerida no quiz** (nome próprio → "Diretor X") |
| Varredura sensível | n/a | **scan automático** (CPF/CNPJ/valores/nomes completos) |
| Consolidação | promoção direta possível | **PR obrigatório sempre** |
| Allowlist | qualquer slug do time | **só sócios** (verifica identity) |

> "Rode /sync-diretoria"

A skill detecta o modo:
- **Diretor cross-brain** → lê commits novos do `~/{{EMPRESA_SLUG}}/pessoal/`, copia pra `inbox/{seu-slug}/` em staging
- **Diretor local** → lê `inbox/{seu-slug}/` não-commitado, commita em staging

## Fase 7 — Agendar consolidação

### Persona 1 (só Claude Code) — Scheduled Task

- **Nome:** `consolidacao-diretoria-{{EMPRESA_SLUG}}`
- **Schedule:** `0 5 * * *` (02:00 BRT)
- **Prompt:** `"Rodar skill consolidar-estacoes no repo ~/{{EMPRESA_SLUG}}/diretoria"`

### Persona 2 e 3 (com OpenClaw) — scheduler nativo

A `setup-agente-openclaw` (Fase 5) já registrou. Verifique:

```bash
openclaw schedule list | grep consolidar-estacoes
```

**Importante:** esta consolidação **nunca promove direto**, sempre abre PR pra revisão humana — independente da persona.

## Fase 8 — Validação com os 3 gatilhos

Simule um caso de cada:

- **Gatilho 1:** `"Ana fechou 50k em abril, comissão 5k"` → captura aqui em `inbox/{seu-slug}/privado/` (default)
- **Gatilho 2:** `"Bruno teve conflito com Carla em reunião X"` → idem
- **Gatilho 3:** `"contrato de distribuição com Empresa Y foi assinado"` → idem

Captura que NÃO dispara ("time de vendas fechou 200k") → não entra aqui (vai pro empresa via `/sync-empresa`).

Rode `/sync-diretoria` confirmando subir 1 dos 3 (anonimizando se necessário). Force consolidação manual.

Verifique:
- [ ] PR aberto pra cada captura subida (nada promovido direto)
- [ ] Capturas em `privado/` NÃO subiram (gitignored uniforme — Cayo item #4)
- [ ] PR exige revisão de outro sócio (branch protection ativa)
- [ ] Digest em `empresa/consolidacao/{hoje}.md` existe

## Fase 9 — Convidar demais sócios

Pra cada sócio, use a skill orquestradora **`onboarding-diretor`**:

> "Rode a skill onboarding-diretor"

11 passos: modelo dos 2 cérebros, 3 gatilhos detalhados, default privado, estações nos 2 repos, OpenClaw pessoal (modo NOVO/MERGE), validação. ~30-40 min.

Adicione cada sócio ao GitHub Org com "Write" ou "Admin" antes.

## Fase 10 — Revogação

Defina agora o procedimento:
- Quem revoga? (default: {{FUNDADOR_1}})
- Em quais casos? (desligamento, mudança de papel)
- Registre em `areas/governanca/contexto/` quando o arquivo existir

## Fase 11 — Backup

- Backup encriptado offsite semanal
- Rotação de chaves trimestral
- Teste de restauração semestral

Detalhes em [`../empresa/contexto/SEGURANCA.md`](../empresa/contexto/SEGURANCA.md).

---

## Tempo total

| Fase | Persona 1 | Persona 2 | Persona 3 |
|---|---|---|---|
| 1-3 (lista, fork, clone, branch protection, init) | 25min | 25min | 25min |
| 4 (workstation) | 15min | — | 15min |
| 5 (VPS OpenClaw) | — | 30min | 30min |
| 6 (primeira `/sync-diretoria`) | 15min | 15min | 15min |
| 7 (agendar) | 5min | já feito | já feito |
| 8 (validação 3 gatilhos) | 20min | 20min | 20min |
| **Total solo** | **~80min** | **~90min** | **~105min** |
| 9 (convidar sócios) | +1 semana | +1 semana | +1 semana |

## Cross-uso Claude Code + OpenClaw (Persona 3)

Cérebro é **um repo único** — não duplica:

```
GitHub: {{SUA_ORG}}/{{EMPRESA_SLUG}}-diretoria (origem, branch-protected)
       ↓                                ↓
Laptop (Claude Code)         VPS (OpenClaw da diretoria)
~/{{EMPRESA_SLUG}}/diretoria/  ~/openclaw/workspace/{{EMPRESA_SLUG}}-diretoria/
```

- **Claude Code** edita em staging, push.
- **OpenClaw** pull periódico (cron `sync-github` 30min), edita canônico ou consolida em staging, push.
- Git resolve. Conflitos: `consolidar-estacoes` tem regra "nunca resolver conflito sozinha" — alerta sócios via canal privado.

## Links

- [`CLAUDE.md`](../CLAUDE.md)
- [`empresa/contexto/PRINCIPIOS.md`](../empresa/contexto/PRINCIPIOS.md)
- [`empresa/contexto/ARQUITETURA.md`](../empresa/contexto/ARQUITETURA.md)
- [`empresa/contexto/SEGURANCA.md`](../empresa/contexto/SEGURANCA.md)
- [`empresa/skills/sync-diretoria/SKILL.md`](../empresa/skills/sync-diretoria/SKILL.md)
- [`empresa/skills/setup-workstation/SKILL.md`](../empresa/skills/setup-workstation/SKILL.md)
- [`empresa/skills/onboarding-diretor/SKILL.md`](../empresa/skills/onboarding-diretor/SKILL.md)
- [`empresa/skills/consolidar-estacoes/SKILL.md`](../empresa/skills/consolidar-estacoes/SKILL.md)
- [`MAPA.md`](../MAPA.md)
