# GLOSSÁRIO — Diretoria

## Cérebro da diretoria

Repositório Git sensível — escopo restrito ao que dispara a regra dos 3 gatilhos. Vive ao lado do cérebro do time (outro repo). Os dois são disjuntos e não compartilham contexto.

## Agente da diretoria

Programa de IA que opera este cérebro. Tom **prudente** por design — diferente do agente do time (pragmático). Escreve em linguagem descritiva, preserva anonimato quando possível, nunca promove canônico sem revisão humana.

Neste template o agente padrão é `geral-diretoria`.

## Estação pessoal de sócio

Pasta `inbox/{sócio}/`. Default de privacidade: **privado**. Conteúdo sensível vai pra `inbox/{sócio}/privado/` (gitignored) a não ser que explicitamente compartilhável com toda a diretoria.

## Regra dos 3 gatilhos

Classificação que decide se um conteúdo vive neste repo ou no do time:

1. Dinheiro com nome próprio → diretoria
2. Pessoa específica → diretoria
3. Peso contratual/jurídico → diretoria

Se não dispara nenhum → time.

## Revisão humana obrigatória

Característica deste repo: **nenhum canônico é promovido automaticamente**. Consolidação sempre abre PR, um sócio revisa antes de merge.

## Consolidação (diretoria)

Rotina noturna (~02:00 BRT). Diferenças:
- Sempre abre PR, nunca promove direto
- Ignora `inbox/{sócio}/privado/` completamente
- Notifica canal restrito de sócios, não canal geral

## Revogação de acesso

Desligamento de sócio ou mudança de papel → revogar invite GitHub no **mesmo dia**. Procedimento em `empresa/contexto/SEGURANCA.md`.

## Anonimização

Mesmo aqui, preferir "Diretor X", "Candidato(a) Y" quando o nome não é essencial. Menos risco se o repo for auditado.

## Ponte humana

A passagem entre cérebro do time e da diretoria é **sempre feita por um sócio**. Agentes não compartilham.
