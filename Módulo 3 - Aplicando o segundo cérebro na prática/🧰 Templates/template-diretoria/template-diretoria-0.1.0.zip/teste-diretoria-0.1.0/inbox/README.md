# inbox/ — Diretoria

Área de **triagem** da diretoria. Toda captura do dia a dia de sócio cai aqui:

```
inbox/{sócio}/         ← estação pessoal de sócio
inbox/_TEMPLATE/       ← modelo pra criar uma estação nova
```

## Como funciona

O que entra aqui é **provisório**. A rotina noturna de consolidação (agente da diretoria, ~02:00 BRT) classifica cada captura e:

- **Sempre** abre PR pra revisão humana — mesmo com `maturidade: pronto-para-canonico`, esta diretoria **nunca** promove direto
- Mantém no inbox se ainda está verde (`maturidade: cru`)
- Arquiva em `inbox/{sócio}/_historico/` (gitignored) após processado

## Regras específicas da diretoria

- **Default de privacidade = privado.** Por padrão, captura vai em `inbox/{sócio}/privado/` (gitignored). Só sobe pra área pública da estação quando o item for claramente compartilhável com toda a diretoria.
- Toda captura tem **sidecar `.meta.yaml`** irmão
- O agente **nunca** processa `privado/`
- Durante sessão, Claude só commita dentro de `inbox/{seu-slug}/`

## Criar sua estação

Rodar a skill `setup-estacao-pessoal`.
