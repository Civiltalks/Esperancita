# Estação pessoal de {nome} — Diretoria

> Esta é a pasta de trabalho pessoal de {nome} dentro do cérebro **sensível** da
> diretoria. Acesso restrito aos sócios.

## ⚠️ Privacidade invertida (em relação ao cérebro do time)

| | cérebro do time | **cérebro da diretoria (aqui)** |
|---|---|---|
| Default | público (sobe pra staging) | **privado** (`privado/`, gitignored) |
| Opt-in | privado, quando marcado | **público**, quando marcado |
| Audiência | todo o time | **somente sócios-diretores** |

## Como funciona

Tudo que {nome} capturar durante uma sessão de Claude Code / Cowork (brainstorm,
notas, drafts, pesquisa, propostas, diário) cai aqui automaticamente — **por
default em `inbox/{nome}/privado/`** (gitignored, local-only).

Para promover uma captura à área pública da estação (visível aos demais sócios
via staging), basta movê-la pra `inbox/{nome}/` (fora de `privado/`) ou marcá-la
explicitamente no momento da captura.

De madrugada (~02h), o `{{AGENTE_NOME}}` roda a skill `consolidar-estacoes`:

- Processa **só** `inbox/{nome}/` (público) — `privado/` é sempre ignorado
- **Sempre abre PR** pra promover qualquer coisa em `main` — mesmo capturas com
  `maturidade: pronto-para-canonico` esperam revisão humana de sócio
- Mantém no inbox o que ainda está verde (`maturidade: cru`)
- Arquiva em `inbox/{nome}/_historico/` (gitignored) o que foi processado

> A consolidação aqui **nunca** mergeia direto em `main`. Esta é a propriedade que
> distingue o cérebro da diretoria do cérebro do time. Veja [`../CLAUDE.md`](../CLAUDE.md)
> para a regra completa.

## Regras

- **Privado é o default.** Captura entra em `privado/`; subir pra área pública
  da estação é opt-in explícito.
- **Sidecar `.meta.yaml` obrigatório** em todo arquivo capturado (qualquer extensão).
  O conteúdo fica limpo, sem frontmatter YAML embutido. Veja `CLAUDE.md` deste
  diretório.
- **Acesso restrito a sócios-diretores.** Equipe não-sócia, parceiros, investidores
  e clientes não têm acesso a este repo em nenhum nível.
- **Não editar arquivos fora desta estação** durante a sessão e commitar — só
  `inbox/{nome}/` sobe.
- **Revisão humana obrigatória** em todo PR de promoção a `main`. O agente da
  diretoria nunca mergeia sozinho.

## Subpastas que podem aparecer

- `privado/` — gitignored, local-only, **default de toda captura**
- `_historico/YYYY-MM-DD/` — criada automaticamente pela consolidação do
  `{{AGENTE_NOME}}` (também gitignored)

Fora isso, mantemos **flat**. A classificação sai no sidecar `.meta.yaml`, não na
pasta.

## Os 3 gatilhos como condição de aceitação

Diferente do cérebro do time (que rejeita conteúdo sensível), aqui o conteúdo
**precisa** disparar pelo menos um dos 3 gatilhos pra fazer sentido:

1. **Dinheiro com nome próprio** — valor associado a pessoa, contrato ou cliente
   identificável
2. **Pessoa específica num contexto sensível** — RH, conflito, avaliação,
   desligamento, remuneração
3. **Peso contratual ou jurídico** — contratos, compliance, litígios, LGPD

Captura que não dispara nenhum dos 3 é sinal de que talvez devesse estar no
cérebro do time, não aqui.
