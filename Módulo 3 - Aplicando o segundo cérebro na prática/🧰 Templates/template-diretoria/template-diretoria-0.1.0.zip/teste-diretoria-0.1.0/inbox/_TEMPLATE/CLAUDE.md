# CLAUDE.md — Estação pessoal de {nome} (Diretoria)

> **⚠️ Atenção:** este é o template de estação pessoal num **cérebro sensível** (diretoria).
> A política de privacidade aqui é **invertida** em relação ao cérebro do time:
> tudo é **privado por default** (`inbox/{nome}/privado/`, gitignored). Público (visível
> aos demais sócios via staging) só quando você marcar explicitamente.

> Instruções específicas para o Claude quando operar a estação pessoal de {nome}. Este arquivo empilha em cima do `CLAUDE.md` da raiz da diretoria.

## Identidade

- **Nome:** {nome}
- **Email:** {email}
- **Área:** {area}
- **Papel:** {papel}
- **Projetos ativos:** {projetos}

## Preferências de captura

{preferencias livres: formato de notas preferido, idioma, nível de detalhe, tom}

## Fluxo de sessão desta estação

Toda sessão nesta estação deve seguir:

### 1. Início da sessão

```bash
git fetch origin
git checkout staging
git pull --rebase origin staging
```

### 2. Durante a sessão

- Toda captura vai em `inbox/{nome}/privado/` **por default** — qualquer formato (`.md`, `.html`, `.pdf`, `.png`, `.pptx`, etc.).
- **Sidecar `.meta.yaml` obrigatório** pra cada captura (ver raiz `CLAUDE.md`). O conteúdo do arquivo-par fica **limpo, sem frontmatter YAML embutido** — toda metadata mora no sidecar.
- Público (`inbox/{nome}/`, fora de `privado/`) só quando o sócio marcar explicitamente que pode ser visto pelos demais sócios.
- Nada de editar arquivos canônicos durante sessão humana. Se precisar influenciar canônico, criar **proposta** em `inbox/{nome}/` (ou `inbox/{nome}/privado/`) com sidecar marcando `tipo: proposta-canonica` e `destino_sugerido: {caminho}`. A consolidação noturna abre PR pra revisão humana.

### 3. Depois de cada escrita em `inbox/{nome}/`

```bash
git add inbox/{nome}/
git commit -m "<mensagem curta>"
git pull --rebase origin staging
git push origin staging
```

> Conteúdo em `inbox/{nome}/privado/` está no `.gitignore` e **não sobe**.
> O `git add inbox/{nome}/` cobre só o público (correto).

### 4. A cada ~10 minutos

```bash
git pull --rebase origin staging
```

Mantém o contexto sincronizado com o que os outros sócios capturaram em público.

## Regra dura de commit

**Só commitar arquivos de `inbox/{nome}/`.** Nunca `git add .`, nunca `git add -A`. Se a sessão mexeu em qualquer outro arquivo (mesmo só pra ler/rascunhar), esses diffs ficam locais e **não** vão pro servidor.

Esta regra é **especialmente importante** aqui: um `git add .` acidental poderia subir conteúdo sensível pra área pública da estação ou propor edição direta em canônico — ambos contradizem a propriedade deste cérebro.

## Como nomear arquivos

Convenção: `YYYY-MM-DD-HHMM-{slug-curto}.{ext}` e, ao lado, `YYYY-MM-DD-HHMM-{slug-curto}.{ext}.meta.yaml`

Exemplos (par conteúdo + sidecar):
- `2026-04-19-1532-decisao-aporte.md` + `2026-04-19-1532-decisao-aporte.md.meta.yaml`
- `2026-04-19-1545-proposta-revisao-comissao.md` + `2026-04-19-1545-proposta-revisao-comissao.md.meta.yaml`
- `2026-04-19-1600-diario-confidencial.md` + `2026-04-19-1600-diario-confidencial.md.meta.yaml`
- `2026-04-20-0930-contrato-resumo.pdf` + `2026-04-20-0930-contrato-resumo.pdf.meta.yaml`

## Sidecar default pra esta estação

Conteúdo do `.meta.yaml` ao lado de cada captura:

```yaml
autor: {nome}
data: <timestamp automático>
fonte: conversa | captura-solo | pesquisa-web | screenshot | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
visibilidade: privado   # default; mude pra `socios` quando for compartilhável
destino_sugerido: <quando claro>
relacionado: []
tags: []
```

**O conteúdo do arquivo-par fica limpo.** Sem frontmatter YAML no topo. A metadata
toda mora no sidecar — assim, quando a consolidação abrir PR pra promover, o
conteúdo vai intocado pro destino canônico.

## Consolidação — sempre abre PR

A rotina noturna do agente da diretoria roda `consolidar-estacoes` e:

- **Nunca** promove direto pra `main`. **Sempre** abre PR.
- Aplica os 3 gatilhos como filtro: dinheiro nominal, pessoa específica, peso contratual/jurídico — captura sem nenhum dos 3 vira sinal de "talvez devesse estar no cérebro do time".
- **Nunca** lê `inbox/{nome}/privado/` (a pasta está no `.gitignore` e o agente também a ignora explicitamente).
- Capturas com `maturidade: pronto-para-canonico` entram no PR de revisão; ainda dependem de aprovação humana de sócio antes do merge.

## Quem pode ver o quê

| Pasta | Quem vê |
|---|---|
| `inbox/{nome}/privado/` | Só {nome} (gitignored, local-only) |
| `inbox/{nome}/` (raiz) | Demais sócios, via staging |
| `areas/**`, `empresa/**` (canônico) | Demais sócios, via main (após PR aprovado) |

Equipe não-sócia, parceiros, investidores e clientes **não** têm acesso a este repo
em nenhum nível. Para qualquer pessoa fora do círculo de sócios, a ponte é humana.

---

*Criada por: skill `setup-estacao-pessoal` (modo diretoria — privacidade invertida).*
