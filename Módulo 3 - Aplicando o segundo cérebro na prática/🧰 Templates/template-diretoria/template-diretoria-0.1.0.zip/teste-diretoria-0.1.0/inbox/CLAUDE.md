# CLAUDE.md — inbox/ (diretoria)

> Instruções gerais pro Claude operar em `inbox/` na diretoria. Estação pessoal adiciona contexto em `inbox/{sócio}/CLAUDE.md`.

## Regras duras

1. **Só commitar em `inbox/{sócio}/`** — nunca fora.
2. **Nunca `git add .` / `git add -A`** — sempre `git add inbox/{sócio}/`.
3. **Branch: staging.** `main` só muda via PR com revisão humana obrigatória.
4. **Default privado.** Na dúvida, captura vai em `inbox/{sócio}/privado/`.
5. **Sidecar `.meta.yaml` obrigatório** pra toda captura.
6. **Nunca citar conteúdo daqui em conversa com o agente do time** (no outro repo).

## Fluxo de sessão

```bash
git fetch origin
git checkout staging
git pull --rebase origin staging

# ... trabalho em inbox/{sócio}/

git add inbox/{sócio}/
git commit -m "<mensagem curta>"
git pull --rebase origin staging
git push origin staging
```

## Escolha entre `inbox/{sócio}/` e `inbox/{sócio}/privado/`

**Gatilhos pra `privado/` (default):**
- Sócio disse "privado", "só pra mim", "confidencial"
- Conteúdo claramente sensível (feedback sobre pessoa nomeada, valor individual, credencial)

**Pode ficar em inbox público da estação se:**
- Já é notoriamente compartilhável com todos os sócios
- Explicitamente marcado como "pode ir pra todos"

Na dúvida, perguntar. Aqui, errar pro lado privado é mais seguro que o contrário.
