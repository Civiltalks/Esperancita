# rotinas/ — rh/

Automações (crons do agente) desta área. Um arquivo `.md` por rotina, flat.

**Especificidade da diretoria:** rotinas aqui **nunca** promovem canônico automaticamente. Sempre abrem PR pra revisão humana.

Schema sugerido:

```yaml
---
nome: ...
schedule: "0 9 * * *"
skill: ...
topico: canal-privado-diretoria   # nunca canal do time
---

# Rotina: Nome

## O que faz
## Quando roda
## O que entrega
```
