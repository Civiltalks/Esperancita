# MAPA — rh/

Área sensível da diretoria. Escopo: recrutamento, avaliações, scorecards, conflitos, desligamentos.

## Estrutura

```
rh/
├── contexto/      → estado, conhecimento, políticas
├── rotinas/       → automações (crons do agente)
└── skills/        → habilidades invocáveis
```

## Regra de sensibilidade

Esta área dispara o gatilho 2 (pessoa específica) por definição.

Todo conteúdo aqui deve:
- Ter timestamp e autor
- Preservar nome só quando estritamente necessário (preferir anonimização)
- Manter linguagem descritiva, não valorativa

## Agente executor

{{AGENTE_NOME}} — agente da diretoria.

---

*Template: adicione arquivos em `contexto/` conforme formalizar processos. Veja `contexto/README.md` pra sugestões.*
