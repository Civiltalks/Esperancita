# contexto/ — rh/

Estado, políticas e artefatos da área de **rh**.

## Exemplos de arquivos que podem viver aqui

- `CARGOS.md` — estrutura organizacional, descrições de cargo
- `RECRUTAMENTO.md` — processo e histórico de vagas
- `AVALIACOES.md` — processo e registros (anonimizar quando possível)
- `CONFLITOS.md` — registro de situações delicadas, com contexto e desfecho
- `scorecards/{cargo}.md` — scorecards por cargo

## Regras de escrita

- Datas absolutas, valores com moeda explícita
- Nome completo no primeiro uso, iniciais depois
- Linguagem descritiva (data + fato + consequência), não valorativa
- Na dúvida, anonimizar
