# MAPA — governanca/

Área sensível da diretoria. Escopo: decisões estratégicas, gestão, atas, lições, relação com investidores.

## Estrutura

```
governanca/
├── contexto/      → estado, conhecimento, políticas
├── rotinas/       → automações (crons do agente)
└── skills/        → habilidades invocáveis
```

## Regra de sensibilidade

Esta área dispara o gatilho 3 (decisões vinculantes) + 1 (aprovações financeiras) + 2 (atas com participantes).

Todo conteúdo aqui deve:
- Ter timestamp e autor
- Preservar nome só quando estritamente necessário (preferir anonimização)
- Manter linguagem descritiva, não valorativa

## Agente executor

{{AGENTE_NOME}} — agente da diretoria.

---

*Template: adicione arquivos em `contexto/` conforme formalizar processos. Veja `contexto/README.md` pra sugestões.*
