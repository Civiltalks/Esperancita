# contexto/ — governanca/

Estado, políticas e artefatos da área de **governanca**.

## Exemplos de arquivos que podem viver aqui

- `gestao/` — licoes, pendencias, projetos estratégicos
- `decisoes/YYYY-MM.md` — decisões mensais datadas
- `atas/YYYY-MM-DD.md` — atas de reunião (se optar por separar de decisões)
- `investidores/` — relação com stakeholders de investimento
- `ROADMAP-ESTRATEGICO.md` — planejamento 12-24 meses

## Regras de escrita

- Datas absolutas, valores com moeda explícita
- Nome completo no primeiro uso, iniciais depois
- Linguagem descritiva (data + fato + consequência), não valorativa
- Na dúvida, anonimizar
