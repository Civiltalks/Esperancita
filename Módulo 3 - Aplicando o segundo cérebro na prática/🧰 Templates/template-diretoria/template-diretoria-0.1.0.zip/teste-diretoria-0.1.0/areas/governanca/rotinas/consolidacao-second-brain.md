---
nome: consolidacao-second-brain
schedule: "0 5 * * *"
timezone: UTC
schedule_legivel: "Diária 02:00 BRT / 05:00 UTC"
agente: {{AGENTE_SLUG}}
skill: empresa/skills/consolidar-estacoes/SKILL.md
canal_notificacao: telegram_privado
sempre_via_pr: true
---

# Rotina — Consolidação noturna do cérebro da diretoria

> Consolidação das estações pessoais (`inbox/*/`) e da memória operacional do {{AGENTE_NOME}} em canônico. **Na diretoria, consolidação sempre abre PR** — nunca promove direto.

## Fonte única de verdade

Este arquivo é **apenas declarativo** — descreve quando/como a rotina roda. A lógica operacional vive na skill canônica:

**→ [`empresa/skills/consolidar-estacoes/SKILL.md`](../../../empresa/skills/consolidar-estacoes/SKILL.md)**

Qualquer atualização de comportamento (o que promove, como classifica) vai lá, não aqui.

## Agente executor

**{{AGENTE_NOME}}** — agente da diretoria, VPS dedicado.

## Frequência

Diária, **02:00 BRT** (`0 5 * * *` em UTC).

## ⚠️ Especificidade da diretoria — PR obrigatório

Diferente do cérebro do time (onde `maturidade: pronto-para-canonico` é promovido direto pra `main`), **aqui toda consolidação abre PR**. Propriedade do repo:

- Conteúdo é sensível (3 gatilhos: dinheiro com nome próprio, pessoa específica, peso contratual)
- Sócios precisam revisar antes de virar decisão oficial
- Zero auto-promoção — mesmo com `maturidade: pronto-para-canonico` + `destino_sugerido` claro, abre PR

Essa regra está codificada na skill `consolidar-estacoes` deste repo.

## O que faz (resumo)

1. Lê `staging` — diffa `main..staging` (espera só mudanças em `inbox/*/`).
2. Classifica cada captura via sidecar `.meta.yaml`.
3. **Abre PR contra `main` pra TUDO que a classificação indicar como promovível** (sem auto-merge). Mesmo `pronto-para-canonico` abre PR — diferença da diretoria.
4. Mantém no inbox o que ainda está `cru` ou `draft` sem destino.
5. Arquiva processado em `inbox/{nome}/_historico/{data}/` (gitignored).
6. Sincroniza `staging` com `main` após merge dos PRs (manual, no dia seguinte).
7. Escreve digest em `empresa/consolidacao/{data}.md`.
8. Notifica no Telegram (canal privado da diretoria).

## Destinos canônicos

**Sensível (este repo):**

| Tipo | Destino |
|------|---------|
| Decisão estratégica de sócio | `areas/governanca/contexto/decisoes.md` |
| Métrica financeira (EBITDA, valuation, margem) | `areas/financeiro/contexto/` |
| Contratação, desligamento, avaliação | `areas/rh/contexto/` |
| Contrato, compliance, litígio, NDA | `areas/juridico/contexto/` |
| Ajuste de comissão / bônus individual | `areas/rh/contexto/comissoes.md` |
| Pendência sensível | `areas/{area}/contexto/pendencias.md` |

**Operacional do time (NÃO vai aqui):**

Se uma captura entrou por engano neste repo mas é operacional (sem disparar os 3 gatilhos), o {{AGENTE_NOME}} **não escreve** em canônico aqui. Abre PR marcando "redirecionar" e sinaliza ao humano: o conteúdo pertence ao `{{EMPRESA_SLUG}}-second-brain` ({{AGENTE_TIME_NOME}}), e tem que ir via ponte humana (cérebro pessoal do diretor + `/sync-empresa`).

## Regras invioláveis

- **Nunca promover direto** — PR obrigatório pra qualquer entrada em canônico. Sem exceção.
- Nunca resolver conflito de merge sozinho — escalar pro sócio responsável.
- Nunca deletar captura sem arquivar primeiro.
- Nunca vazar conteúdo deste repo pro repo do time (diretoria escreve pessoal → `/sync-empresa` → time; agente não propaga).
- Nunca transformar hipótese em decisão.

## Canal de notificação

**Privado da diretoria** — `TELEGRAM_CHAT_ID` do grupo restrito dos sócios. Nunca o grupo geral do time.

## Mensagem esperada aos sócios

Ao final da rotina, postar no canal privado:

```
Consolidação diretoria 2026-04-20 ✅
- X PRs abertos pra revisão
- Y capturas mantidas no inbox (ainda verdes)
- Z redirecionadas (operacional — ver digest pra próximos passos)
- digest: empresa/consolidacao/2026-04-20.md
```

## Backup

Backup encriptado offsite semanal é **obrigatório** — ver `empresa/contexto/SEGURANCA.md`.

---

*Atualizado: 2026-04-22 — consolidação sempre via PR; canal privado; VPS separado.*
