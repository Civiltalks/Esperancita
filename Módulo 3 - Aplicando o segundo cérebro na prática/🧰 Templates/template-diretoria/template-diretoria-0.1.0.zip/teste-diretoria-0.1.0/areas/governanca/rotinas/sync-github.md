---
nome: sync-github
schedule: "0 0 * * *"
timezone: UTC
schedule_legivel: "Diária 21:00 BRT / 00:00 UTC"
agente: {{AGENTE_SLUG}}
skill: null
branch_alvo: staging
canal_notificacao: telegram_privado
---

# Rotina — Sync para GitHub ({{AGENTE_NOME}} → staging)

> Sincroniza configuração e memória operacional local do {{AGENTE_NOME}} pro repositório da diretoria, na branch `staging`. Esta rotina é **mecânica pura** (rsync + git) — não invoca skill nem LLM. O agente executa diretamente os passos descritos aqui.

## Agente executor

**{{AGENTE_NOME}}** — rodando em **VPS dedicado, separado do VPS do agente do time** (`/root/.openclaw/workspace/`).

## Frequência

1x/dia — 00:00 UTC (21:00 BRT), via crontab do sistema do VPS.

## Branch alvo

**`staging`** (**não** `main`).

`main` só é atualizada pela rotina de consolidação noturna (`consolidacao-second-brain.md`) que — na diretoria — **sempre abre PR pra revisão humana**, nunca promove direto. Este cron só empurra o trabalho do dia pra camada de staging.

## O que sincroniza

Copia do workspace do {{AGENTE_NOME}} (`/root/.openclaw/workspace/`) pro repo local (`{{EMPRESA_SLUG}}-diretoria/agentes/{{AGENTE_SLUG}}/`):

**Config do agente** (sempre):
- `IDENTITY.md`, `SOUL.md`, `USER.md`, `AGENTS.md`, `TOOLS.md`, `HEARTBEAT.md`, `MEMORY.md`

**Memória operacional** (só notas diárias):
- `memory/YYYY-MM-DD.md`

## O que **não** sincroniza (exclusões duras)

Memória local do {{AGENTE_NOME}} só tem notas diárias. Qualquer outro arquivo em `memory/` é ignorado pelo sync. Em particular, os seguintes **nunca** entram neste repo:

```
memory/.dreams/                    (runtime)
memory/people.md                   (legado — deve virar canônico em areas/rh/)
memory/decisions.md                (legado — deve virar canônico em areas/governanca/)
memory/metrics.md                  (legado — deve virar canônico em areas/financeiro/)
```

Se o VPS do {{AGENTE_NOME}} ainda tem esses arquivos localmente (herança de migração anterior), eles precisam ser migrados pro canônico manualmente (via PR) antes de serem removidos do workspace local.

O comando de sync usa `rsync --exclude` pra garantir que não vazem pra este repo mesmo se ainda existirem no workspace.

## Comando

```bash
cd /root/.openclaw/workspace
test -d {{EMPRESA_SLUG}}-diretoria || git clone https://github.com/{{ORG}}/{{EMPRESA_SLUG}}-diretoria.git

cd {{EMPRESA_SLUG}}-diretoria
git fetch origin
git checkout staging
git pull --rebase origin staging

# sincronizar configs + memória filtrada
mkdir -p agentes/{{AGENTE_SLUG}}
rsync -a --delete \
  --include='memory/' \
  --include='memory/[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9].md' \
  --exclude='memory/*' \
  --exclude='memory/.dreams/' \
  /root/.openclaw/workspace/IDENTITY.md \
  /root/.openclaw/workspace/SOUL.md \
  /root/.openclaw/workspace/USER.md \
  /root/.openclaw/workspace/AGENTS.md \
  /root/.openclaw/workspace/TOOLS.md \
  /root/.openclaw/workspace/HEARTBEAT.md \
  /root/.openclaw/workspace/MEMORY.md \
  /root/.openclaw/workspace/memory/ \
  agentes/{{AGENTE_SLUG}}/

# commit apenas o que está em agentes/{{AGENTE_SLUG}}/
git add agentes/{{AGENTE_SLUG}}/
git diff --cached --quiet || git commit -m "sync: {{AGENTE_SLUG}} config+memory $(date +%Y-%m-%d)"
git pull --rebase origin staging
git push origin staging
```

**Regra dura:** o comando **só adiciona `agentes/{{AGENTE_SLUG}}/`** — nunca `git add -A` ou `git add .`.

## Canal de notificação

**Privado da diretoria** — `TELEGRAM_CHAT_ID` deve ser do grupo restrito dos sócios, **nunca** o grupo geral do time. Erros desta rotina também são reportados só ali.

## Entrega

- Commit em `staging` com mensagem `sync: {{AGENTE_SLUG}} config+memory YYYY-MM-DD`
- Push pra `origin/staging`
- Log do cron em `/var/log/openclaw/sync-github.log`

## Dependências

- `GITHUB_TOKEN` configurado (git credential store ou PAT com escopo restrito ao repo da diretoria)
- Acesso HTTPS ou SSH ao repo
- `rsync` instalado no VPS

## Quando rever esta rotina

- Quando a lista de arquivos sensíveis (exclusões) mudar
- Quando o VPS do {{AGENTE_NOME}} migrar de caminho
- Quando o agente for renomeado ou clonado pra outro perfil

---

*Atualizado: 2026-04-22 — VPS separado, canal privado, branch `staging` (nunca `main`).*
