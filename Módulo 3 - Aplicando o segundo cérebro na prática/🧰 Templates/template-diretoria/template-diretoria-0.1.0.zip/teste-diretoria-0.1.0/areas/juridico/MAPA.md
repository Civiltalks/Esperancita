# MAPA — juridico/

Área sensível da diretoria. Escopo: contratos ativos, compliance, litígios, LGPD.

## Estrutura

```
juridico/
├── contexto/      → estado, conhecimento, políticas
├── rotinas/       → automações (crons do agente)
└── skills/        → habilidades invocáveis
```

## Regra de sensibilidade

Esta área dispara o gatilho 3 (peso contratual/jurídico) por definição.

Todo conteúdo aqui deve:
- Ter timestamp e autor
- Preservar nome só quando estritamente necessário (preferir anonimização)
- Manter linguagem descritiva, não valorativa

**Especificidade:** contratos assinados ficam em **storage encriptado separado** (drive com 2FA). Aqui só referência, status e resumo.

## Agente executor

{{AGENTE_NOME}}, com **revisão humana obrigatória** em todo PR. Sem exceção.

---

*Template: adicione arquivos em `contexto/` conforme formalizar processos. Veja `contexto/README.md` pra sugestões.*
