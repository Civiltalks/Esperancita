# contexto/ — juridico/

Estado, políticas e artefatos da área de **juridico**.

## Exemplos de arquivos que podem viver aqui

- `CONTRATOS-ATIVOS.md` — lista e status dos contratos vigentes
- `COMPLIANCE.md` — checklists, auditorias, responsabilidades
- `LITIGIOS.md` — processos em andamento (referência, não peças)
- `LGPD.md` — controles de LGPD

**Importante:** PDFs assinados ficam em storage encriptado separado, não aqui.

## Regras de escrita

- Datas absolutas, valores com moeda explícita
- Nome completo no primeiro uso, iniciais depois
- Linguagem descritiva (data + fato + consequência), não valorativa
- Na dúvida, anonimizar
