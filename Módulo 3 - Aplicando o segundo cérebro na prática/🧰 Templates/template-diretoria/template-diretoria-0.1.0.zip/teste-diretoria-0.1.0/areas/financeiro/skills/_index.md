# Skills — financeiro/

Skills específicas desta área. Skills transversais vivem em `empresa/skills/`.

## Skills sugeridas

- relatório mensal pro board
- fechamento trimestral

_(vazio — adicione conforme criar)_

## Regra

Skills desta área devem:
- Nunca enviar conteúdo pra canal compartilhado com time
- Anonimizar quando possível
- Exigir confirmação humana antes de qualquer ação que saia do repo
