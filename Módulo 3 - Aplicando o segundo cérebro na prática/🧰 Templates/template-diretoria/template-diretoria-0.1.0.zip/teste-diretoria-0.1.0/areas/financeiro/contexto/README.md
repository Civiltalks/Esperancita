# contexto/ — financeiro/

Estado, políticas e artefatos da área de **financeiro**.

## Exemplos de arquivos que podem viver aqui

- `POLITICAS.md` — regras de aprovação de despesa, limites, responsáveis
- `CONTAS.md` — estrutura de contas bancárias (referência, não valores ao vivo)
- `FLUXO-CAIXA.md` — visão agregada
- `METRICAS.md` — EBITDA, valuation, Business Plan ref

## Regras de escrita

- Datas absolutas, valores com moeda explícita
- Nome completo no primeiro uso, iniciais depois
- Linguagem descritiva (data + fato + consequência), não valorativa
- Na dúvida, anonimizar
