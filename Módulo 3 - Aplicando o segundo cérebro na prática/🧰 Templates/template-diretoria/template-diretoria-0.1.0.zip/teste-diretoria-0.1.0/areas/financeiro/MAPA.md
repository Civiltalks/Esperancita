# MAPA — financeiro/

Área sensível da diretoria. Escopo: fluxo de caixa, contas, obrigações fiscais, remuneração individual.

## Estrutura

```
financeiro/
├── contexto/      → estado, conhecimento, políticas
├── rotinas/       → automações (crons do agente)
└── skills/        → habilidades invocáveis
```

## Regra de sensibilidade

Esta área dispara o gatilho 1 (dinheiro com nome próprio) e agregados financeiros confidenciais.

Todo conteúdo aqui deve:
- Ter timestamp e autor
- Preservar nome só quando estritamente necessário (preferir anonimização)
- Manter linguagem descritiva, não valorativa

## Agente executor

{{AGENTE_NOME}} — agente da diretoria.

---

*Template: adicione arquivos em `contexto/` conforme formalizar processos. Veja `contexto/README.md` pra sugestões.*
