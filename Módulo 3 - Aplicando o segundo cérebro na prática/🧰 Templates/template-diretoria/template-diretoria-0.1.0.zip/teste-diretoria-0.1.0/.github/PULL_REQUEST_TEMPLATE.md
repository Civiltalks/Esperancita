<!--
PR template — cérebro da diretoria.
Toda promoção a `main` neste repo é sensível. Marque os itens abaixo
intencionalmente; não é caixa de checklist automático.
-->

## Resumo

<!-- Descreva o que está sendo mergeado e por quê. Se é uma consolidação noturna,
diga quantos arquivos foram promovidos e de quais sócios vieram. Se é uma edição
canônica direta (caso raro), diga quem decidiu e quando. -->

## Checklist de revisão sensível

- [ ] Conteúdo é apropriado para o cérebro **diretoria** (dispara pelo menos um
      dos 3 gatilhos: dinheiro nominal, pessoa específica, peso contratual/jurídico).
      Se não dispara nenhum, talvez deva ir pro cérebro do time.
- [ ] Capturas privadas de algum sócio **não** foram acidentalmente movidas pra
      fora de `inbox/{sócio}/privado/`.
- [ ] Nenhum dado pessoal de membro do time **não-sócio** foi exposto sem o
      consentimento da pessoa.
- [ ] Decisões societárias ou financeiras com nome próprio foram revisadas por
      mais de um sócio (não só o autor do PR).
- [ ] Documentos contratuais/jurídicos têm **referência** mas não conteúdo bruto
      neste repo (PDFs assinados ficam em storage encriptado separado, com 2FA;
      ver `empresa/contexto/SEGURANCA.md`).
- [ ] Sidecar `.meta.yaml` presente em todos os arquivos novos em `inbox/`
      (a consolidação não promove sem sidecar; este checkbox cobre edição manual).
- [ ] Nenhum `.cerebro-inicializado` ou metadado de inicialização foi alterado
      sem motivo explícito.

## Tipo de PR

- [ ] Consolidação noturna automática (gerada pelo agente da diretoria)
- [ ] Edição canônica direta (rara — descreva justificativa no resumo)
- [ ] Mudança de skill / rotina / contexto operacional
- [ ] Outro (especificar)
