# template-second-brain-empresa

Template de **cérebro operacional do time** para empresas que operam com agentes de IA (OpenClaw + Claude Code). Construído pela Pixel Educação como parte do Pixel AI Hub.

> Este repositório é um **template**. Clone usando o botão **"Use this template"** do GitHub. Não edite este repo original.

## O que você ganha clonando

- Estrutura de cérebro pronta (`areas/`, `empresa/`, `agentes/`, `inbox/`)
- Agente operacional do time pré-configurado (`geral-empresa`) — só preencher placeholders
- Duas skills essenciais: `setup-estacao-pessoal` e `consolidar-estacoes`
- Wizard de setup em [`onboarding/SETUP.md`](onboarding/SETUP.md) que leva do zero ao funcional em ~1h
- Documentação dos princípios (sidecar, privacidade, 3 gatilhos, 2 cérebros)

## Comece por aqui

Depois de clonar este template via "Use this template", o **primeiro comando** é rodar a skill **`inicializar-cerebro`** no Claude Code / Cowork. Ela é tutorial + configurador (preenche placeholders, renomeia pasta do agente, ensina o modelo). Roda 1 vez só.

Roteiro completo (5 passos): [`onboarding/SETUP.md`](onboarding/SETUP.md).

## Quem opera aqui

| ator | papel | onde escreve |
|---|---|---|
| **Humanos do time** | visitantes do canônico | sempre via `inbox/{nome}/` — nunca direto |
| **{{AGENTE_NOME}}** (agente do time) | **gestor deste cérebro** | direto em `empresa/`, `areas/`, `agentes/{{AGENTE_NOME}}/` — sem inbox próprio |
| **Cada diretor** (via cérebro pessoal dele, clonado do `template-second-brain-pessoal`) | visitante cross-repo | via `/sync-empresa` (modo diretor) → `inbox/{diretor-slug}/` em staging, com quiz item-a-item |
| **Claude Code / Cowork** em sessão humana | opera como visitante | `inbox/{seu-slug}/` |

**Princípio:** quem é gestor de um cérebro escreve direto nele; quem é visitante passa por inbox.

## Filosofia resumida

1. **Cérebro da empresa é um repo Git**, não uma Wiki.
2. **Inbox é triagem, main é verdade.** Consolidação noturna faz a ponte.
3. **Sidecar `.meta.yaml`** classifica cada captura para a consolidação decidir destino.
4. **Dois repos disjuntos** quando a empresa cresce:
   - este (cérebro do time, operacional)
   - `template-second-brain-diretoria` (cérebro da diretoria, sensível)

## Estrutura

```
template-second-brain-empresa/
├── README.md              # este arquivo
├── CLAUDE.md              # instruções pro Claude/agente quando abrir o repo
├── MAPA.md                # visão panorâmica
├── LICENSE                # licença restrita a assinantes do Hub
├── onboarding/            # wizard de setup + glossário
├── agentes/geral-empresa/ # seu agente operacional
├── areas/                 # 5 áreas: marketing, vendas, atendimento, operacoes, produto
├── empresa/               # contexto transversal + skills gerais
└── inbox/                 # triagem (staging do trabalho diário)
```

## Licença

Uso restrito aos assinantes do Pixel AI Hub. Ver [LICENSE](LICENSE).

## Suporte

Dúvidas e bugs: canal do Hub.
