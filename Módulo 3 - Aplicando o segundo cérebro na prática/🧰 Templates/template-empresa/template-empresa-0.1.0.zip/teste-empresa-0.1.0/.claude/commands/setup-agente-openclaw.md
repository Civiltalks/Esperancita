---
description: Configurar agente gestor do cérebro ({{AGENTE_NOME}}) em VPS/OpenClaw com o repo deste cérebro como fonte de verdade. 2 modos — NOVO (zero) e MERGE (workspace existente).
---

Run the skill at `empresa/skills/setup-agente-openclaw/SKILL.md`.
