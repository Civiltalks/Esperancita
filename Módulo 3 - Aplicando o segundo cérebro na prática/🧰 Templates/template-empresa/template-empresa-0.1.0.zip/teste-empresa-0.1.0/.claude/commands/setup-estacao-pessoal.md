---
description: Cria inbox/{slug}/ deste cérebro empresa pra você capturar via /sync-empresa. Atômica — sem parte pedagógica. Use direto se já entende o modelo (senão use onboarding-membro-time).
---

Run the skill at `empresa/skills/setup-estacao-pessoal/SKILL.md`.
