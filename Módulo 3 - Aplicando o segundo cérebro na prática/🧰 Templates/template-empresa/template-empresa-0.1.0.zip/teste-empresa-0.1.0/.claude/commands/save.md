---
description: Alias pra /sync-empresa — empacota capturas pro inbox/{seu-slug}/ em staging via quiz item-a-item. Mantido pra hábito muscular. Se você esperava flush filesystem-only (comportamento antigo), use /sync-pessoal no template-pessoal.
---

Run the skill at `empresa/skills/sync-empresa/SKILL.md`.
