---
description: Rotina de consolidação noturna das estações pessoais — promove/PR/arquiva conteúdo de inbox/, faz merge staging→main. Roda automaticamente pelo agente gestor às 02:00 BRT; manual quando precisa fora do ciclo.
---

Run the skill at `empresa/skills/consolidar-estacoes/SKILL.md`.
