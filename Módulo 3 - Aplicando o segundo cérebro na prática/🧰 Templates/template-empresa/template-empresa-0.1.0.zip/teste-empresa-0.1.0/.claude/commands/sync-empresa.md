---
description: Empacota e empurra capturas pra inbox/{seu-slug}/ deste cérebro empresa em staging via quiz item-a-item. Detecta automaticamente modo diretor (cross-brain do pessoal) ou funcionário (flush local). Substitui /save + /team-sync antigos.
---

Run the skill at `empresa/skills/sync-empresa/SKILL.md`.
