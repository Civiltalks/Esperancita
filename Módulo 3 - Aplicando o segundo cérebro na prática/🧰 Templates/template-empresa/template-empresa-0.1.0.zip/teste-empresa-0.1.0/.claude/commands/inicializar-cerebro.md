---
description: Configurar este cérebro empresa pela primeira vez após clonar o template. Preenche placeholders ({{EMPRESA}}, {{AGENTE_NOME}}, etc.), renomeia pasta do agente. Roda 1 vez só.
---

Run the skill at `empresa/skills/inicializar-cerebro/SKILL.md`.
