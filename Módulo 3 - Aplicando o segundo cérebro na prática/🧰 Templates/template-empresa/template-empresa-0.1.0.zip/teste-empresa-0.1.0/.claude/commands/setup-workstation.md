---
description: Configura layout LOCAL ~/{{EMPRESA_SLUG}}/ da pessoa — organiza repos lado a lado, cria symlinks de skills (/cerebro, /sync-empresa, /sync-pessoal, /sync-diretoria) em ~/{{EMPRESA_SLUG}}/.claude/skills/. Use 1x por máquina.
---

Run the skill at `empresa/skills/setup-workstation/SKILL.md`.
