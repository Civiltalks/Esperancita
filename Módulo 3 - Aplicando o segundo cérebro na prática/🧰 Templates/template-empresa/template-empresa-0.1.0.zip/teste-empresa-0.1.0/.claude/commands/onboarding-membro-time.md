---
description: Wizard guiado pra novo membro do time entrando no cérebro pela primeira vez. Ensina o modelo (cérebros, estação pessoal, staging, sidecar, 3 gatilhos), invoca setup-workstation, faz captura de prática e valida com 3 perguntas. ~20 min.
---

Run the skill at `empresa/skills/onboarding-membro-time/SKILL.md`.
