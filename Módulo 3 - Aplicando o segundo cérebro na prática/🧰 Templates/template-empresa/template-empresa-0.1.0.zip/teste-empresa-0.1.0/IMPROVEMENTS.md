# IMPROVEMENTS — pendências fora deste PR

> Backlog de melhorias identificadas mas que **não cabem** no escopo de um PR só do `template-second-brain-empresa`. Tipicamente porque envolvem mudança coordenada nos 3 templates (empresa, diretoria, pessoal), ou requerem decisão de produto fora do escopo de bugfix.

## Resolvido — branch `fix/inicializar-script-bugs` (2026-05-02)

Stress test E2E identificou 8 bugs no `inicializar.sh` dos 3 templates. Corrigidos cross-template em PRs irmãos (`fix/inicializar-script-bugs` em pessoal, empresa e diretoria):

- **Branch errada após init**: script comitava na branch upstream (`feat/rename-skills-sync-family`) em vez de `main`/`staging`. Fix: garantir branch correta com checkout/criação antes do trabalho.
- **API de flags divergente entre templates**: pessoal aceitava `--fundador`, empresa `--fundador-1`, diretoria `--fundador`. Padronizado em `--fundador-1` nos 3.
- **Echo final com placeholder literal** (`{{EMPRESA_SLUG}}`): script imprimia template não-substituído como instrução pro usuário. Fix: usar `$EMPRESA_SLUG` no `echo`.
- **Auto-modificação do próprio script**: `replace_in_tree` usava `find -name '*.sh'` que incluía o próprio `inicializar.sh`. Sed substituía `{{EMPRESA}}` em strings deliberadas dele, poluindo com hardcode da empresa atual. Fix: excluir `empresa/skills/inicializar-cerebro/scripts/` do find (path-aware via `-not -path`).
- **Detector de placeholders residuais não excluía scripts/**: `grep --exclude-dir=NAME` matcha por nome, não por path. Fix: filtrar via pipe `| grep -v 'empresa/skills/inicializar-cerebro/scripts/'`.
- **Empresa abortava silenciosamente em residual fora da allowlist** (só avisava). Fix: alinhar com diretoria — `exit 2` com mensagem explicativa de causas comuns.
- **Backup tag persistia após sucesso**: tag `pre-inicializacao-*` ficava permanente. Fix: `git tag -d` em sucesso (preservada só em falha pra rollback).
- **`git mv` da pasta do agente acontecia DEPOIS do sed** no pessoal, gerando create+delete em vez de rename no histórico. Fix: mover `git mv` antes do sed.

Doc atualizada também: `SKILL.md` e `SETUP.md` dos 3 templates com a nova sintaxe `--fundador-1`.

## Pendente — coordenar com diretoria e pessoal

### Estender enum `fonte` do sidecar pra incluir `sync-empresa-de-pessoal` e `sync-diretoria-de-pessoal`

**Issue de origem:** #20 (rodada de QA pós-init, 2026-04-25). Atualizado 2026-05-02 com novos nomes de skill.

**Sintoma:** o sidecar `.meta.yaml` documenta o enum `fonte` em duas fontes:
- `empresa/contexto/PRINCIPIOS.md` — schema do sidecar
- `inbox/CLAUDE.md` (e `inbox/_TEMPLATE/CLAUDE.md` por extensão) — schema repetido

Atualmente o enum lista: `conversa | captura-solo | pesquisa-web | screenshot | reuniao | brainstorm | sync-empresa`.

Falta as fontes específicas de origem cross-brain:
- `sync-empresa-de-pessoal` — capturas que originam no cérebro pessoal de um diretor e chegam aqui via `/sync-empresa` modo diretor
- `sync-diretoria-de-pessoal` — capturas que originam no cérebro pessoal e vão pra diretoria via `/sync-diretoria`

Sem esses valores específicos, capturas dessa origem ficam classificadas como `sync-empresa` genérico — perde a granularidade de audit trail (não distingue funcionário fazendo flush local vs diretor fazendo cross-brain).

**Por que não está neste PR:** mexer no enum aqui sem mexer simultaneamente em `template-second-brain-diretoria` (que **recebe** capturas via `/sync-diretoria`) e `template-second-brain-pessoal` (que **gera** as capturas) cria divergência cross-template. Os 3 enums precisam ser idênticos pra audit trail funcionar.

**Próximo passo:**
1. Abrir PRs irmãos nos 3 repos (`template-second-brain-empresa`, `template-second-brain-diretoria`, `template-second-brain-pessoal`) com a mesma extensão de enum
2. Atualizar o schema em todos os arquivos que documentam sidecar:
   - `empresa/contexto/PRINCIPIOS.md`
   - `inbox/CLAUDE.md` (raiz da inbox de cada cérebro)
   - `inbox/_TEMPLATE/CLAUDE.md`
   - skills relevantes (`/sync-empresa`, `/sync-diretoria`, `consolidar-estacoes`)
3. Garantir merge sincronizado pra que cliente que clona qualquer um dos 3 receba o enum atualizado.

**Tracking:** abrir issue/PR no repo `pixel-ia-hub` (meta-workspace) coordenando os 3.
