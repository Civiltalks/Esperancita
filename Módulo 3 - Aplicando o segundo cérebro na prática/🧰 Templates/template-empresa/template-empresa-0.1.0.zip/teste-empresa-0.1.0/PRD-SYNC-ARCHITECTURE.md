# PRD — Arquitetura de Sync (Pixel AI Hub)

**Status:** Draft pra revisão (Cayo + Vitor)
**Data:** 28/04/2026
**Autor:** Bruno + Claude (sessão de design)
**Repositório:** `template-second-brain-empresa`

---

## 1. Contexto

### 1.1. Incidente que motivou (27/04/2026)

Em teste com OpenClaw zerado simulando 2 cérebros (pessoal + diretoria), o agente **comitou material em 3 cérebros sem `/save` explícito do humano**. Erros observados:

- Material pessoal jogado na diretoria
- Foto classificada como "invoice" e roteada pra cérebro sensível
- Material rotineiro do time empurrado pra diretoria por confidence baixo
- Mistura entre pessoal e empresa via pipeline assíncrono Telegram → cérebro

Causa raiz: **agente teve autonomia desproporcional num pipeline sem gate humano + sem regra de tipo de arquivo**. Não foi falha de prompt — foi falha estrutural.

### 1.2. Decisões consolidadas na reunião (28/04/2026)

- **Template pessoal sai do Hub** — já é coberto pelo mini-curso, replicar gera confusão
- **2 skills modulares no Hub:** `sync_empresa` e `sync_diretoria`, cada uma vive no repo correspondente
- **Só uma pessoa instala cada repo** (responsável pelo agente). Demais membros se conectam, não instalam
- **Quem escreve no cérebro:** agentes + pessoas via inbox. Consolidação pelo agente responsável
- **Da Vinci como orquestrador global** (conecta nos 2 — empresa + diretoria)
- **Gatilho linguagem natural** ativa skills no OpenClaw automaticamente, controlado por allowlist
- **Ambiguidade gera pergunta, não decisão automática**
- **Aula prática (não teórica)** com meta de aluno operando em ~1h

### 1.3. Princípios fechados no brainstorm pós-reunião

- **Pergunta > suposição** — milhares de alunos = milhares de variações reais
- **Ambiguidade resolve no sync, não na consolidação** — Cayo, áudio 28/04
- **Pessoa leiga é a referência** — modelo mental tem que caber em "falar com o agente", sem decorar comandos
- **HTML/MD only no git** — anexo (PDF, foto, planilha) vira referência URL
- **Hook anti-commit-autônomo** — agente nunca commita sem skill humana

---

## 2. Visão consolidada do produto

### 2.1. As 3 skills (família `sync_*`)

| Skill | Vive onde | Função | Distribuição |
|---|---|---|---|
| `sync-pessoal` | Mini-curso (não Hub) | Pull/push do workspace pessoal + orienta Claude na estrutura | Aluno do mini-curso instala junto com aula de backup |
| `sync-empresa` | `template-second-brain-empresa` | Empacota material local → inbox do repo empresa | Hub: convite por email → clone do repo |
| `sync-diretoria` | `template-second-brain-diretoria` | Empacota material local → inbox do repo diretoria, com gates extras | Hub: convite após empresa madura |

### 2.2. Verbo unificador: **sync**

Mesmo padrão repetido em 3 destinos. Aluno aprende 1 modelo mental, aplica em 3 contextos. "*Salva, comita, guarda isso*" no meio do trabalho continua sendo linguagem natural — não é skill formal.

### 2.3. Dois modos por skill

| Modo | Como dispara | Onde resolve ambiguidade |
|---|---|---|
| **Manual** | Usuário digita `/sync-empresa` em sessão Claude/Cowork | Pergunta na própria sessão (síncrono) |
| **Automático** | OpenClaw detecta gatilho linguagem natural ("salva isso pra empresa") | Pergunta no Telegram do dono com inline keyboard |

Gatilho automático **só dispara em DM dono ↔ agente** ou em mensagens de pessoas na **allowlist do OpenClaw**. Mensagem de terceiros em grupos é ignorada — privacidade preservada.

---

## 3. Arquitetura técnica

### 3.1. Estrutura local convencionada

```
~/{nome-empresa}/                    ← raiz da empresa do user
├── pessoal/                         ← workspace pessoal (do mini-curso)
├── empresa/                         ← clone do template-second-brain-empresa
└── diretoria/                       ← clone do template-second-brain-diretoria (opcional)
```

Pessoa abre Claude Code em `~/{nome-empresa}/`. Subpastas convivem. Skills viajam com seus repos. Claude entende toda a árvore via `CLAUDE.md` raiz de cada subpasta.

### 3.2. Awareness do OpenClaw

Cada novo repo registrado num arquivo central que OpenClaw lê no boot:

```yaml
# ~/.openclaw/cerebros-vinculados.md (ou similar)
cerebros:
  - tipo: empresa
    path: ~/norte/empresa
    repo: pixel-norte/norte-empresa
    agente_responsavel: léo (vps-empresa.norte.digital)
    skill: sync-empresa
  - tipo: diretoria
    path: ~/norte/diretoria
    repo: pixel-norte/norte-diretoria
    agente_responsavel: aurora (vps-diretoria.norte.digital)
    skill: sync-diretoria
```

OpenClaw lê esse registry → sabe quais cérebros existem → quando usuário fala "salva isso pra empresa" via Telegram, aciona `sync-empresa` correta.

### 3.3. Auto-explicação de cada repo

Cada clone tem `CLAUDE.md` raiz que se apresenta:

> *"Eu sou o cérebro empresa da Norte Digital. Material aqui é operacional. Capturas vão pra `inbox/{slug}/`. Pra commitar, exporte `PIXEL_BRAIN_COMMIT_OK=1` e use `sync-empresa`."*

Agente lê quando usuário "manda o link do repo" → adiciona ao registry → entende contexto operacional de cada lugar.

### 3.4. Onde cada agente vive

| Agente | Onde roda | Quem instala |
|---|---|---|
| Pessoal (Vera, Amora, etc.) | Local (laptop) ou VPS própria opcional | Aluno via mini-curso |
| Empresa (Léo, Atlas, etc.) | **VPS própria dedicada** (recomendação oficial) | Responsável pelo agente |
| Diretoria (Aurora, Atena, etc.) | **VPS própria dedicada** (recomendação oficial) | Responsável pelo agente |

Cliente Hub completo (empresa + diretoria) precisa de **2 VPS coletivas** + pessoal opcional. Ordem: empresa primeiro, diretoria quando empresa estiver madura (60+ dias de uso).

---

## 4. Personas e jornada

### 4.1. 3 personas

- **Responsável pelo agente** (admin) — instala o repo, configura agente em VPS própria, gerencia
- **Visitante** (membro do time) — clona o mesmo repo só pra ter a skill, configura como visitor (cria só `inbox/{slug}/` próprio)
- **Diretor** (sócio com acesso pra diretoria) — extensão do papel acima, mas cruzando os 2 repos coletivos

### 4.2. Jornada do "Roberto" (CEO PME, persona referência)

1. Termina mini-curso (workspace `~/norte/pessoal/` organizado + git backup no GitHub) e ativa `sync-pessoal` no Claude Code
2. Recebe email do Hub: "convite pra repo `pixel-norte/norte-empresa`"
3. Aceita convite, manda link pro Claude/Vera: *"instala isso pra mim"*
4. Vera clona repo em `~/norte/empresa/`, lê CLAUDE.md, dispara wizard
5. Wizard pergunta questionário nível 1 (~10 perguntas: VPS, acesso, repos existentes, agentes, domínio)
6. Wizard valida ambiente, configura skill globalmente, faz health check piloto
7. Roberto trabalha no dia a dia em `~/norte/pessoal/`. Diz "salva essa pauta pra empresa". Vera aciona `sync-empresa` → empacota → push pra inbox no GitHub
8. Léo (agente da empresa, na VPS dedicada) puxa do GitHub, consolida, distribui em pastas certas. Pergunta no Telegram do Roberto se houver ambiguidade

### 4.3. Tempo realista pro setup completo

- `sync-pessoal` ativação: 2-5 min
- `sync-empresa` instalação: 10-15 min
- `sync-diretoria` instalação (futuro): 12-15 min
- Total primeira sessão (só empresa): ~20 min com pessoal já feito

Aula precisa caber em ~1h se cobrir empresa + base de conceito. Diretoria fica em aula separada quando aluno chegar lá.

---

## 5. Skill `sync-empresa` em detalhe

### 5.1. Modo manual (sessão Claude)

```
Roberto trabalha em ~/norte/ no Claude Code
↓
"manda essa pauta de cliente pra empresa"
↓
sync-empresa empacota arquivo .md + sidecar (autor, data, fonte, destino sugerido)
↓
Pergunta de ambiguidade se houver (síncrono na sessão)
↓
Cria em ~/norte/empresa/inbox/roberto/{YYYY-MM-DD-HHMM}-{slug}.md + .meta.yaml
↓
git push origin staging do repo empresa
↓
Confirmação: "Subiu N capturas pra inbox da empresa. Léo consolida na próxima rotina."
```

### 5.2. Modo automático (OpenClaw via Telegram/canal)

```
Roberto manda mensagem privada Vera (DM Telegram): "salva isso pra empresa: pauta cliente Y"
↓
Vera (OpenClaw VPS pessoal) detecta gatilho "pra empresa"
↓
Vera valida que sender é Roberto (allowlist do OpenClaw da empresa)
↓
Vera aciona sync-empresa
↓
Skill empacota mensagem + sidecar
↓
Se ambíguo: Vera manda pro Telegram do Roberto:
  "Recebi 'pauta cliente Y'. Pode ser comercial/ ou marketing/. 
   [Comercial] [Marketing] [Pular] [Descartar]"
↓
Roberto clica botão → skill resolve → push pra inbox
↓
Léo (na VPS empresa) puxa, consolida
```

### 5.3. Regras duras (anti-padrões fechados)

- ❌ **Commit autônomo** — hook `pre-commit` bloqueia sem `PIXEL_BRAIN_COMMIT_OK=1`
- ❌ **Binário no git** — só `.md` e `.html` (anexo vira link Drive em MD)
- ❌ **Decisão automática em ambíguo** — sempre pergunta
- ❌ **Gatilho de mensagem fora de allowlist** — privacidade
- ❌ **Categorização sem sidecar** — sidecar obrigatório

### 5.4. Quem consolida

Léo (ou nome do agente da empresa configurado pelo cliente) roda em **VPS própria dedicada da empresa**:
- Lê inbox do repo via git pull periódico (cron)
- Consolida material com confidence alto direto pra `areas/{contexto}/`
- Pergunta no Telegram do dono pra ambiguidade
- Em modo PR (opcional): abre PR em vez de commit direto

---

## 6. Wizard de instalação (questionário em 3 níveis)

### 6.1. Nível 1 — Perguntas factuais (sempre faz)

Variação alta entre alunos. Sem suposição.

1. Qual seu provedor de VPS? (Hostinger Managed / Hostinger VPS / DigitalOcean / AWS / Outro / Ainda não tenho)
2. Como você acessa? (Painel web / SSH com chave / Terraform / Não sei)
3. Que agentes você já tem rodando?
4. Repo do mini-curso — qual nome no GitHub?
5. Tem domínio próprio?
6. Você é o responsável pelo agente da empresa ou só vai conectar?

### 6.2. Nível 2 — Default + confirma rápido

Decisão segura mas única, agente propõe e confirma com 1 yes/no.

- Path do clone: `~/{empresa}/empresa/` ✓
- Privado por default: na diretoria, sim ✓
- Branch protection: ativo ✓
- Naming agente: sugestões com personalidade ("Léo, Iris, Atlas, Aurora — ou prefere escolher?")

### 6.3. Nível 3 — Não pergunta (regra dura)

- HTML/MD only
- Sidecar obrigatório
- PR obrigatório na diretoria
- Hook anti-commit-autônomo ativo
- Allowlist obrigatória pra modo automático

### 6.4. Health check final

Wizard fecha com:
1. Teste real piloto: "Vou pegar um arquivo do seu workspace e mandar pra inbox da empresa como teste. Me responde se quer descartar a captura ou deixar pra revisão."
2. Teste do modo automático via Telegram (se OpenClaw VPS configurado)
3. Summary visual:

```
✅ sync-empresa — ativo (Atlas)
✅ Path: ~/norte/empresa
✅ VPS: Hostinger Managed conectada
⏳ Aurora (diretoria) — aguardando setup
⚠️ Branch protection — falta admin no repo
```

Pessoa sabe o que tá funcionando e o que falta.

---

## 7. Anti-padrões fechados

| Anti-padrão | Como fechamos |
|---|---|
| Agente commitando sozinho | Hook `pre-commit` + env var obrigatória |
| Foto/PDF entrando como binário | Regra HTML/MD only codificada na skill |
| Gatilho de terceiros disparando comando | Allowlist OpenClaw |
| Inbox virando backlog (Notion 2.0) | Agente da empresa em VPS dedicada com cron de consolidação |
| Decisão automática em ambíguo | Pergunta síncrona (Claude session ou Telegram inline keyboard) |
| Confusão pessoal × empresa | Convenção `~/{empresa}/{tipo}/` + skills separadas |
| "Pessoal" duplicando mini-curso | Template `pessoal` descontinuado do Hub |

---

## 8. Open questions (pra implementação)

1. **Role no convite GitHub:** Pixel manda convite com `admin` (permite branch protection) ou `write` (mais conservador). **Recomendação: admin.**
2. **Sync `~/.openclaw/cerebros-vinculados.md` entre laptop e VPS:** laptop fonte de verdade, VPS faz pull. Ritual a definir.
3. **Health check linguagem:** fraseologia que distingue captura-de-teste de captura-real durante wizard
4. **Gatilho linguagem natural — confidence threshold:** lista hardcoded de frases ou modelo classifica? (Sugestão: regex hardcoded primeiro, modelo refina depois)
5. **Versionamento das skills:** quando Pixel atualizar `sync-empresa`, como aluno atualiza? (Sugestão: comando `/atualizar-skill empresa`)
6. **Visitante (não-admin) sem clone:** se for muito atrito clonar repo só pra ter skill, alternativa é distribuir skill via plugin público no `okjpg/claude-skills`

---

## 9. Não-objetivos (escopo cortado)

- Multi-empresa no config global (1 cliente = 1 empresa por vez)
- Template-second-brain-pessoal (descontinuado, vira skill do mini-curso)
- Sync entre 2 ambientes do cérebro pessoal (git puro, ensinado no mini-curso)
- Gate de ambiguidade na consolidação (resolvido no sync — decisão Cayo)
- Skill `/save` formal no pessoal (substituída por linguagem natural)

---

## 10. Próximos passos

1. **Bruno:** revisa este PRD, ajusta, manda pro Cayo + Vitor
2. **Cayo + Vitor:** revisam, comentam, aprovam ou pedem ajustes
3. **Bruno:** grava aulão (~1h) baseado no PRD aprovado
4. **Vitor:** implementa `sync-empresa` neste repo + onboarding script + skill no `template-second-brain-diretoria` (modo similar)
5. **Bruno:** descontinua `template-second-brain-pessoal`, migra `sync-pessoal` pro mini-curso
6. **Pixel:** prepara convite por email via CRM com role `admin`

---

*Revisar e comentar inline. Mudanças na arquitetura sugerem ajuste neste doc + alinhamento com PRDs irmãos em `template-second-brain-diretoria` e `template-second-brain-pessoal`.*

---

## 11. Adendo: Decisões pós-revisão (Cayo, 23/04/2026)

> **Documento de revisão completo:** `pixel-second-brain/empresa/contexto/arquitetura-second-brain/2026-04-23-revisao-prds-cayo.html`

Cayo revisou os 3 PRDs (10 pontos avaliados — 3 adotar, 4 não adotar, 3 adaptar) e escreveu análise 1-a-1. Resumo das decisões que afetam **este PRD** (`template-second-brain-empresa`):

| # | Item original | Decisão | Resumo |
|---|---|---|---|
| 1 | Convenção `~/{empresa}/{tipo}/` (Section 3.1) | ✅ Adotar | Mantém proposta original |
| 2 | Hook `pre-commit` anti-autônomo (Section 5.3) | ✅ Adotar | Mantém proposta original |
| 3 | Modo automático OpenClaw + Telegram + allowlist (Section 2.3) | ⚙ Adaptar | **Reconhece o impulso, rejeita a implementação.** `sync-*` é skill de sessão Claude Code; OpenClaw é agente de UM brain. Mecanismo correto pra capture mobile-first fica **TBD** (ver detalhe abaixo) |
| 4 | Política de `privado/` versionado (proposta na diretoria, afeta convenção universal) | ⚙ Adaptar | **Rejeita versionar.** `privado/` permanece **gitignored universal** nos 3 cérebros + roteamento por papel (ver detalhe abaixo) |
| 5 | Família `sync-pessoal` / `sync-empresa` / `sync-diretoria` (Section 2) | ✅ Adotar | Mantém proposta original. `setup-workstation` continua skill separada |
| 8 | CLAUDE.md "auto-explicativo" sem skill `/cerebro` (Section 3.3) | ❌ **Rejeitar** | Mantém skill `/cerebro` — Claude Code só auto-carrega CLAUDE.md do cwd e pais, não desce em subpastas. Sem skill explícita, multi-brain awareness não acontece |
| 9 | Wizard de instalação único (Section 6) | ⚙ Adaptar | Manter **2 wizards separados**: `setup-agente-openclaw` (VPS) + `setup-workstation` (laptop). Adotar do PRD: health check final visual + questionário em 3 níveis |

### Detalhamento dos itens não-adotados ou adaptados

**Item 3 — Capture mobile-first fica TBD (não cross-brain via OpenClaw)** ⚙

A proposta original era: pessoa manda DM Telegram pro agente OpenClaw → agente detecta gatilho ("pra empresa") → valida allowlist → dispara `sync-empresa`. Bonito como UX, mas conflata 2 escopos:

- **Claude Code** (sessão interativa no laptop) — onde rodam `sync-pessoal`, `sync-empresa`, `sync-diretoria`. Cross-brain distribution acontece **só aqui**.
- **OpenClaw** (VPS de cada brain — Léo da empresa, Aurora da diretoria, Vera pessoal opcional) — cada agente opera **dentro do próprio brain**: consolida inbox, gera reports, salva direto em canônico. **Não roda `sync-*`**, não distribui pra outros brains.

Bruno propôs Telegram → OpenClaw → `sync-empresa`, fazendo OpenClaw fazer trabalho de sessão Claude Code. Mistura responsabilidades.

**Mecanismos corretos pra capture mobile-first (TBD em rodada futura):**
- **Claude Code mobile** — abrir sessão direto no celular, rodar `sync-*` normalmente
- **Vera pessoal recebe Telegram** — se sócio tem OpenClaw pessoal opcional, Vera salva no cérebro pessoal dele. Cross-brain distribution depois fica pra próxima sessão Claude Code com `sync-empresa`/`sync-diretoria`
- **Allowlist + linguagem natural** — bom princípio pra qualquer mecanismo, herda do PRD

**Princípio que fica:** nunca cross-brain automático em OpenClaw.

**Item 4 — `privado/` gitignored universal + roteamento por papel** ⚙

Pattern uniforme nos 3 cérebros (pessoal, empresa, diretoria): `inbox/{slug}/privado/` é **sempre gitignored**. É scratch space onde Claude salva uploads, drafts e WIP.

Roteamento por papel (Claude detecta automaticamente pela estrutura de pastas):

| Papel | Detecção | Onde Claude salva scratch |
|---|---|---|
| Diretor | `pessoal/` existe na pasta-mãe `~/{empresa}/` | Cérebro pessoal (`~/{empresa}/pessoal/`) — sincroniza via conta GitHub pessoal |
| Funcionário | Só `empresa/` na pasta-mãe | `~/{empresa}/empresa/inbox/{slug}/privado/` — local, gitignored |

Saída do scratch via `/sync-empresa` (ou `/sync-diretoria`) — quiz inclui itens em `privado/` perguntando *"esse aqui sai? pra qual cérebro?"*. Default privado invertido na diretoria continua valendo.

**Item 8 — Manter skill `/cerebro`** ❌

Limitação real: Claude Code só auto-carrega CLAUDE.md do cwd e pais, não desce em subpastas. Pessoa abre Claude em `~/{empresa}/` e os CLAUDE.md das subpastas (`pessoal/`, `empresa/`, `diretoria/`) **não são lidos sem skill explícita**. `/cerebro` resolve isso lendo os 3 em paralelo no primeiro turno da sessão multi-brain.

**Item 9 — 2 wizards separados** ⚙

Setup do agente OpenClaw é **infra-as-code** (rodar na VPS, instalar symlinks, `.env`, registrar rotinas no scheduler). Setup da workstation é **local dev experience** (organizar `~/{empresa}/`, criar `~/{{EMPRESA_SLUG}}/.claude/skills/`, validar Claude Code). Misturar gera wizard confuso (perguntar "qual seu provedor de VPS" pra alguém que só quer instalar a skill no laptop).

Adotar dos 2 wizards do PRD original:
- Health check final visual (excelente UX)
- Questionário em 3 níveis (factual / default-confirma / não-pergunta)

### Cleanups menores também aprovados (Cayo)

A serem aplicados em commits separados pelo Vitor durante implementação:
- Marcadores `<!-- template-only-start -->` em CLAUDE.md/IDENTITY.md pros templates (permite `inicializar-cerebro` remover trechos pós-clone)
- Expansão do `inicializar-cerebro` com perguntas extras (`TIPO_EMPRESA`, `EMAIL_DIRETORIA`)
- Cleanup de placeholders em `consolidar-estacoes` (trocar "Leo" hardcoded por `{{AGENTE_NOME}}`)
- Estender enum `fonte` do sidecar com `team-sync-de-pessoal` e `team-sync-de-diretoria`

---

*Adendo gerado a partir do feedback consolidado do Cayo (23/04/2026, 6 áudios + análise HTML). Itens originais 1-3 e 5 mantidos sem mudança. Próximos passos da Section 10 ainda válidos com ajustes apontados acima.*
