---
name: setup-agente-openclaw
description: Configurar ou migrar o agente gestor do cérebro ({{AGENTE_NOME}}) em VPS/OpenClaw, com {{EMPRESA_SLUG}}-second-brain como fonte de verdade. Tem 2 modos — NOVO (OpenClaw do zero) e MERGE (workspace OpenClaw já existente, adapta preservando customizações). O agente descobre suas próprias rotinas lendo `areas/*/rotinas/*.md` e registra os crons nativos do OpenClaw — sem cron Linux, sem CLI externa.
---

# Setup Agente OpenClaw

## Objetivo

Padronizar a subida do **agente gestor deste cérebro** ({{AGENTE_NOME}}) em VPS/OpenClaw, com `{{EMPRESA_SLUG}}-second-brain` como fonte de verdade.

## Arquitetura

O agente do OpenClaw é **o LLM** que executa a rotina — não precisa de CLI externa nem de cron do Linux pra orquestrar nada. Setup é 4 blocos:

1. **Repo + identidade** — clone, symlinks dos arquivos canônicos do agente
2. **Segredos** — `.env.example` versionado, `.env` local ignorado
3. **Rotinas** — agente lê `areas/*/rotinas/*.md`, extrai frontmatter, registra crons no próprio OpenClaw
4. **Skills** — ficam disponíveis automaticamente porque estão no repo (agente descobre via caminho `empresa/skills/` e `areas/*/skills/`)

Não há `install_crons.sh` nem `run_*.sh`. Cron é nativo do OpenClaw, agendado pelo próprio agente baseado no frontmatter das rotinas.

## Dois modos de setup

### Modo NOVO — OpenClaw do zero no VPS

Use quando:
- VPS recém-provisionado, OpenClaw acabou de ser instalado
- Workspace `/root/.openclaw/workspace/` está vazio ou tem só a instalação padrão do OpenClaw (sem `AGENTS.md`, `SOUL.md`, etc. preenchidos)

Fluxo: clone do repo → symlinks → `.env.example` → registrar rotinas. É o caminho "feliz" — segue os passos sequenciais abaixo.

### Modo MERGE — já existe OpenClaw rodando no VPS

Use quando:
- `/root/.openclaw/workspace/` já tem arquivos `AGENTS.md`, `SOUL.md`, `IDENTITY.md` etc. preenchidos (outro agente já está rodando ali)
- Você quer que este cérebro passe a ser a fonte de verdade, mas **preserve** customizações que o agente atual já tem (tom, skills próprias, histórico)

Fluxo extra antes dos passos normais:

1. **Backup** do workspace atual → `/root/.openclaw/workspace-backup-YYYYMMDD/`
2. **Ler os arquivos do agente atual** (AGENTS, SOUL, USER, TOOLS etc.)
3. **Apresentar ao humano um relatório de diffs** entre o que está no workspace vs. o que o template diz
4. **Perguntar, arquivo a arquivo**: manter versão do workspace atual, substituir pela do cérebro, ou fazer merge manual?
5. **AGENTS.md é o arquivo mais crítico** — aplicar as regras novas do cérebro sempre. Se o antigo tinha regras próprias, preservar como apêndice.
6. **MEMORY.md** — simplificar pro novo formato (só dailies). Memórias temáticas antigas (channels/content/lessons/projects) migram pro canônico (`areas/*/contexto/`).

Só depois do merge concluído é que seguem os passos 1-4 normais.

---

## Passos do setup

### Passo 1 — Clonar repo e criar identidade do agente

```bash
cd /root/.openclaw/workspace
test -d {{EMPRESA_SLUG}}-second-brain || git clone https://github.com/{{ORG}}/{{EMPRESA_SLUG}}-second-brain.git
cd {{EMPRESA_SLUG}}-second-brain
git checkout staging
git pull --rebase origin staging
```

Garantir que os arquivos canônicos do agente vivem em `agentes/{{AGENTE_SLUG}}/`:

- `AGENTS.md`
- `HEARTBEAT.md`
- `IDENTITY.md`
- `MEMORY.md`
- `SOUL.md`
- `TOOLS.md`
- `USER.md`
- `memory/`
- `.env.example`

### Passo 2 — Symlinks no workspace raiz

Criar no `/root/.openclaw/workspace/`:

- `AGENTS.md -> {{EMPRESA_SLUG}}-second-brain/agentes/{{AGENTE_SLUG}}/AGENTS.md`
- `HEARTBEAT.md -> ...`
- `IDENTITY.md -> ...`
- `MEMORY.md -> ...`
- `SOUL.md -> ...`
- `TOOLS.md -> ...`
- `USER.md -> ...`
- `memory -> {{EMPRESA_SLUG}}-second-brain/agentes/{{AGENTE_SLUG}}/memory`

O script `scripts/setup_agent.sh` faz isso idempotente.

### Passo 3 — `.env` do agente

- Copiar `agentes/{{AGENTE_SLUG}}/.env.example` → `.env` local (fora do git)
- Preencher: `GITHUB_TOKEN`, `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID` e outros requeridos
- `.env` nunca vai pro git (`.gitignore` já tem)
- Nunca criar `env.txt` ou derivados com segredo em texto puro

### Passo 4 — Registrar rotinas no OpenClaw

**Esta é a parte que substitui o antigo `install_crons.sh`.** O agente lê as rotinas declaradas no repo e se auto-registra no scheduler do OpenClaw.

O agente faz:

1. **Varrer** todos os arquivos em `areas/**/rotinas/*.md` (ignorar `README.md`)
2. **Parsear o frontmatter YAML** de cada. Exemplo esperado:

   ```yaml
   ---
   nome: consolidacao-second-brain
   schedule: "0 5 * * *"
   timezone: UTC
   schedule_legivel: "Diária 02:00 BRT / 05:00 UTC"
   agente: {{AGENTE_SLUG}}
   skill: empresa/skills/consolidar-estacoes/SKILL.md
   canal_notificacao: telegram
   ---
   ```

3. **Filtrar** rotinas onde `agente == {{AGENTE_SLUG}}` (só as dele)
4. **Registrar cada uma no scheduler do OpenClaw** com:
   - Nome: o campo `nome`
   - Schedule: o campo `schedule` (cron expression)
   - Timezone: o campo `timezone` (default UTC)
   - Ação: invocar a skill apontada em `skill` (se `null`, executar os passos descritos na própria rotina)
5. **Confirmar** com o humano: lista as rotinas registradas + schedule + próxima execução prevista.

Exemplo do que o agente reporta ao terminar:

```
Registrei 2 rotinas no OpenClaw:
• sync-github — 0 0 * * * UTC — próxima execução: amanhã 00:00 UTC
• consolidacao-second-brain — 0 5 * * * UTC — próxima execução: amanhã 05:00 UTC
```

Quando o cron do OpenClaw dispara, o agente acorda, lê a skill apontada pela rotina, e executa usando o próprio LLM (OpenAI, Claude, o que o OpenClaw tiver configurado).

### Passo 5 — Skills ficam automáticas

Skills vivem em `empresa/skills/` e `areas/**/skills/`. O agente descobre elas sozinho porque estão no repo que ele já tem montado no workspace. Nenhum registro manual necessário.

Quando uma rotina aponta `skill: empresa/skills/consolidar-estacoes/SKILL.md`, no horário do cron o agente simplesmente lê esse arquivo e executa o passo a passo descrito lá.

## Fluxo completo — resumo

```
Setup (uma vez):
  ├─ clone repo + symlinks
  ├─ .env preenchido
  ├─ agente lê areas/*/rotinas/*.md
  └─ agente registra rotinas no scheduler do OpenClaw

Operação (contínua):
  └─ OpenClaw dispara cron no horário
     └─ agente lê rotina → lê skill apontada → executa com próprio LLM
```

Zero Linux cron. Zero bash runners. Zero CLI externa. Tudo nativo do OpenClaw.

## Recursos desta skill

- Script idempotente de bootstrap: `scripts/setup_agent.sh` (só symlinks + `.env`, não mexe em cron)
- Referência operacional: `references/checklist.md`

## Validação final

Depois do setup, conferir:

1. `ls -l /root/.openclaw/workspace/` — symlinks apontando pros arquivos canônicos em `agentes/{{AGENTE_SLUG}}/`
2. `.env` existe localmente com as chaves preenchidas
3. `.env` **não está** no `git status` (confirma que `.gitignore` tá filtrando)
4. O agente listou as rotinas registradas no scheduler do OpenClaw
5. Logs do OpenClaw mostram que as rotinas foram aceitas pelo scheduler
6. Próxima execução de cada rotina aparece na dashboard do OpenClaw
