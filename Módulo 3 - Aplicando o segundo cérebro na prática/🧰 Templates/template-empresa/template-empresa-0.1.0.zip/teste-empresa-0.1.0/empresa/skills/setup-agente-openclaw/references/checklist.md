# Checklist — Setup de agente OpenClaw

## Checklist rápido

- Repo `{{EMPRESA_SLUG}}-second-brain` clonado no workspace
- Arquivos canônicos em `agentes/<agente>/`
- Symlinks do workspace apontando para `{{EMPRESA_SLUG}}-second-brain/agentes/<agente>/`
- `.env.example` criado
- `.env` ignorado por `.gitignore`
- `env.txt` removido
- `sync-github.md` revisado
- `git remote` sem token embutido na URL

## Para o agente {{AGENTE_NOME}}

Caminho canônico:

```bash
/root/.openclaw/workspace/{{EMPRESA_SLUG}}-second-brain/agentes/{{AGENTE_SLUG}}/
```

Symlinks esperados no workspace:

```bash
AGENTS.md
HEARTBEAT.md
IDENTITY.md
MEMORY.md
SOUL.md
TOOLS.md
USER.md
memory/
```

Todos apontando para `{{EMPRESA_SLUG}}-second-brain/agentes/{{AGENTE_SLUG}}/...`
