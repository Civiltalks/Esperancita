---
name: cerebro
description: Carrega em paralelo os CLAUDE.md dos cérebros presentes em `~/{{EMPRESA_SLUG}}/` (time, diretoria, pessoal — o que estiver lá). Use no INÍCIO de cada sessão aberta na pasta-mãe `~/{{EMPRESA_SLUG}}/`, porque Claude Code só auto-carrega o CLAUDE.md do cwd e pastas pai, não desce em subpastas.
---

# /cerebro — Carregar contexto dos cérebros em `~/{{EMPRESA_SLUG}}/`

> **Limitação real do Claude Code** que a skill resolve: ele só lê automaticamente o `CLAUDE.md` do diretório atual e pastas pai. Quando a sessão abre em `~/{{EMPRESA_SLUG}}/` (pasta-mãe), os `CLAUDE.md` dos cérebros irmãos (subpastas) **não** são lidos. Esta skill corrige em 1 turno, N reads paralelos.

## Quem precisa

**Todo mundo** que opera em `~/{{EMPRESA_SLUG}}/`:
- **Membros do time** — têm só `{{EMPRESA_SLUG}}-second-brain/` na pasta-mãe. Se abrirem o Claude em `~/{{EMPRESA_SLUG}}/` (em vez de direto dentro do repo), `/cerebro` carrega o CLAUDE.md do time.
- **Sócios-diretores** — têm 3 cérebros irmãos (time, diretoria, pessoal). `/cerebro` carrega os 3 em paralelo.

Por isso a skill vive no cérebro do time (`{{EMPRESA_SLUG}}-second-brain/empresa/skills/cerebro/`) — é universal, todo mundo clona o repo do time. O `setup-workstation` cria um symlink de `~/{{EMPRESA_SLUG}}/.claude/skills/cerebro/` → esta skill, pra ela virar slash command `/cerebro` no Claude Code.

## O que faz

1. Detecta pastas filhas de `~/{{EMPRESA_SLUG}}/` que sejam repos git com `CLAUDE.md` na raiz:
   ```bash
   for d in "$HOME/{{EMPRESA_SLUG}}/"*/; do
     [ -f "$d/CLAUDE.md" ] && [ -d "$d/.git" ] && echo "$d"
   done
   ```
2. Lê o `CLAUDE.md` de cada um **em paralelo** (1 turno, N tool calls `Read` simultâneos).
3. Confirma em **1 linha curta** quais carregaram:

   > N cérebros carregados: {{AGENTE_PESSOAL_NOME}} (pessoal), {{AGENTE_TIME_NOME}} (time), {{AGENTE_DIRETORIA_NOME}} (diretoria).

   Exemplo pra membro de time com 1 só:

   > 1 cérebro carregado: {{AGENTE_TIME_NOME}} (time).

   Se algum falhou:

   > 2/3 cérebros carregados: {{AGENTE_TIME_NOME}} ✓, {{AGENTE_PESSOAL_NOME}} ✓, diretoria ✗ (acesso negado).

## Quando rodar

- **Primeiro turno** de toda sessão aberta em `~/{{EMPRESA_SLUG}}/` (pasta-mãe)
- **Depois de `/clear`** ou compactação — o contexto foi descartado, precisa recarregar
- Quando alguém pergunta algo que pode envolver outro cérebro e você não tem certeza do conteúdo atual dele

Se a sessão foi aberta **direto dentro de um cérebro específico** (ex: `cd ~/{{EMPRESA_SLUG}}/empresa && claude`), o Claude Code já auto-carrega o `CLAUDE.md` daquele repo — nesse caso `/cerebro` é opcional (só útil se quiser puxar também os irmãos).

## O que NÃO faz

- Não faz `git pull` — pra sincronizar com remoto, rodar manualmente.
- Não distribui capturas — pra isso, `/sync-empresa` (todos) ou `/sync-diretoria` (só diretor).
- Não persiste sessão pessoal — pra isso, `/sync-pessoal` (só diretor; alias `/save` ou linguagem natural: "salva", "guarda", "comita").
- Não executa nenhuma rotina de agente.

## Paths esperados

Default: `$HOME/{{EMPRESA_SLUG}}/{nome-do-cerebro}/CLAUDE.md`

Cérebros esperados:
- `$HOME/{{EMPRESA_SLUG}}/empresa/CLAUDE.md` — time (agente: {{AGENTE_TIME_NOME}})
- `$HOME/{{EMPRESA_SLUG}}/diretoria/CLAUDE.md` — diretoria (agente: {{AGENTE_DIRETORIA_NOME}})
- `$HOME/{{EMPRESA_SLUG}}/pessoal/CLAUDE.md` — pessoal de cada diretor

## Relação com outras skills

| Skill | Quando roda | Papel |
|-------|-------------|-------|
| `setup-workstation` | **1x por máquina** | Monta `~/{{EMPRESA_SLUG}}/` + symlinks das slash commands |
| `/cerebro` | **Início de toda sessão** | Carrega `CLAUDE.md` dos cérebros |
| `/sync-pessoal` | Fim de sessão / checkpoint (só diretor) | Flush buffer → cérebro pessoal. Triggers LN: "salva", "guarda" |
| `/sync-empresa` | Quando quer publicar pra empresa (todos) | Diretor: pessoal → empresa. Funcionário: inbox local → staging |
| `/sync-diretoria` | Quando quer publicar pra diretoria (só diretor) | Pessoal → diretoria, com gates extras |

Analogia: `setup-workstation` é "ligar a tomada"; `/cerebro` é "acender a luz" toda vez que entra na sala.

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| Sessão Claude Code aberta na pasta-mãe `~/{empresa}/` | `pwd` retorna o path da pasta-mãe | Avisa: skill é no-op se cwd é um repo só. Sugere abrir em `~/{empresa}/` |
| Pelo menos 1 cérebro existe como subpasta | `ls ~/{empresa}/` lista `pessoal/`, `empresa/` ou `diretoria/` | Sugere clonar template apropriado e rodar `inicializar-cerebro` |
| Cada subpasta detectada tem `CLAUDE.md` | `test -f ~/{empresa}/{tipo}/CLAUDE.md` | Avisa qual cérebro não foi inicializado; sugere rodar `inicializar-cerebro` lá |
| Permissão de leitura nos arquivos | `cat <arquivo>` funciona | Reporta path com erro; segue com os que conseguiu ler |

## Variações conhecidas

| Cenário | Como o agente adapta |
|---|---|
| Funcionário com só `empresa/` | Carrega 1 CLAUDE.md. Skill é quase no-op (Claude Code já carrega cwd) — útil só após `/clear` |
| Diretor com 3 cérebros lado a lado | Caso canônico — carrega 3 em paralelo, retorna confirmação 1 linha |
| Diretor com 2 cérebros (`pessoal/` + `empresa/`, sem `diretoria/`) | Carrega 2; reporta "2/3 cérebros carregados, diretoria ✗ (não clonado)" |
| Sessão aberta dentro de uma subpasta (ex: `~/{empresa}/empresa/`) em vez da pasta-mãe | Skill detecta cwd diferente e avisa: _"vc tá em empresa/, não em ~/{empresa}/. /cerebro é mais útil na pasta-mãe — quer que eu suba e leia?"_ |
| Layout não-canônico (clones em paths diferentes) | Tenta env vars `BRAIN_PESSOAL`/`BRAIN_EMPRESA`/`BRAIN_DIRETORIA`. Se ausentes, pergunta paths |
| Sessão recém-compactada | Carregamento perde contexto — rodar `/cerebro` de novo é prática recomendada |
| Pasta tem `.claude/`, `.git/`, ou outras coisas além dos cérebros | Skill ignora dotfolders e qualquer subpasta sem `CLAUDE.md` |

## Quando algo não funciona

| Sintoma | Causa provável | O agente deve |
|---|---|---|
| `Permission denied` ao ler `CLAUDE.md` | Permissão restrita ou clone parcial | Reportar path; tentar `chmod +r` ou orientar `git checkout` |
| `CLAUDE.md` existe mas é template upstream (com `{{...}}`) | `inicializar-cerebro` não rodou naquele cérebro | Avisa e oferece rodar agora |
| Subpasta é symlink quebrado | Setup workstation criou symlink mas alvo sumiu | Reportar path quebrado; sugerir reclone ou re-setup |
| Confirmação contradiz contexto que o usuário acha estar carregado | `/cerebro` rodou antes de compactar e o contexto foi perdido | Sugerir re-rodar `/cerebro` |
| 0 cérebros carregados | Pasta-mãe vazia ou cwd errado | Avisa cwd, lista subpastas, sugere clonar |
| Resultado inconsistente entre runs | Concorrência git (pull/push em outra máquina) | Sem ação automática — só rodar de novo após sincronizar |

## Adaptando pra realidade do usuário

- **Funcionário só com `empresa/`** — skill quase irrelevante. Mencionar 1x: "vc só tem 1 cérebro — `/cerebro` é redundante até você clonar pessoal ou diretoria."
- **Diretor adoptou recente (1ª semana)** — pode ter clonado pessoal mas ainda não inicializado os coletivos. Detectar template não-inicializado e oferecer rodar `inicializar-cerebro` na sessão.
- **Setup customizado** (paths não-canônicos) — agente deve aceitar env vars `BRAIN_PESSOAL`, `BRAIN_EMPRESA`, `BRAIN_DIRETORIA` e gravar em `~/.cerebro-paths` pra próxima sessão.
- **Cliente Pixel com múltiplas empresas** (consultor) — skill opera em 1 pasta-mãe por sessão. Se usuário tenta em outra empresa, sugerir fechar e abrir nova sessão.

---

*Skill canônica do cérebro do time. Instalada como slash command via symlink por `setup-workstation`.*
