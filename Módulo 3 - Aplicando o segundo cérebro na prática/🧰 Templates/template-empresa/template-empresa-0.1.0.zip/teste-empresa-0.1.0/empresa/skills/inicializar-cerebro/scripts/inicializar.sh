#!/usr/bin/env bash
# inicializar.sh — substitui placeholders e renomeia pasta do agente.
# Roda UMA vez após o clone do template-second-brain-empresa.
# Aborta se .cerebro-inicializado já existir.
#
# Uso (CLI ou invocado pela skill inicializar-cerebro):
#
#   bash inicializar.sh \
#     --empresa "Acme Corp" \
#     --empresa-slug "acme" \
#     --org "acme-org" \
#     --empresa-dominio "acme.com" \
#     --timezone "America/Sao_Paulo" \
#     --idioma "pt-BR" \
#     --agente-nome "Oliver" \
#     --agente-slug "oliver" \
#     --agente-time-nome "Atlas" \
#     --agente-diretoria-nome "Geral Diretoria" \
#     --fundador-1 "Ana Silva" \
#     --fundador-1-slug "ana" \
#     --fundador-1-cargo "CEO" \
#     [--fundador-2 "..." --fundador-2-slug "..." --fundador-2-cargo "..."] \
#     [--fundador-3 "..." --fundador-3-slug "..." --fundador-3-cargo "..."]
#
# Fundador 1 + cargo + slug são obrigatórios. Fundadores 2 e 3 são opcionais
# (all-or-nothing por triple — se passar `--fundador-2` precisa passar `-slug` e `-cargo`).
# Para fundadores não fornecidos, placeholders são substituídos por string vazia.

set -euo pipefail

# ======================
# Parse de argumentos
# ======================

EMPRESA=""
EMPRESA_SLUG=""
ORG=""
EMPRESA_DOMINIO=""
TIMEZONE=""
IDIOMA=""
AGENTE_NOME=""
AGENTE_SLUG=""
AGENTE_TIME_NOME=""
AGENTE_DIRETORIA_NOME=""
FUNDADOR_1=""
FUNDADOR_1_SLUG=""
FUNDADOR_1_CARGO=""
FUNDADOR_2=""
FUNDADOR_2_SLUG=""
FUNDADOR_2_CARGO=""
FUNDADOR_3=""
FUNDADOR_3_SLUG=""
FUNDADOR_3_CARGO=""

while [ "$#" -gt 0 ]; do
  case "$1" in
    --empresa)                EMPRESA="$2"; shift 2;;
    --empresa-slug)           EMPRESA_SLUG="$2"; shift 2;;
    --org)                    ORG="$2"; shift 2;;
    --empresa-dominio)        EMPRESA_DOMINIO="$2"; shift 2;;
    --timezone)               TIMEZONE="$2"; shift 2;;
    --idioma)                 IDIOMA="$2"; shift 2;;
    --agente-nome)            AGENTE_NOME="$2"; shift 2;;
    --agente-slug)            AGENTE_SLUG="$2"; shift 2;;
    --agente-time-nome)       AGENTE_TIME_NOME="$2"; shift 2;;
    --agente-diretoria-nome)  AGENTE_DIRETORIA_NOME="$2"; shift 2;;
    --fundador-1)             FUNDADOR_1="$2"; shift 2;;
    --fundador-1-slug)        FUNDADOR_1_SLUG="$2"; shift 2;;
    --fundador-1-cargo)       FUNDADOR_1_CARGO="$2"; shift 2;;
    --fundador-2)             FUNDADOR_2="$2"; shift 2;;
    --fundador-2-slug)        FUNDADOR_2_SLUG="$2"; shift 2;;
    --fundador-2-cargo)       FUNDADOR_2_CARGO="$2"; shift 2;;
    --fundador-3)             FUNDADOR_3="$2"; shift 2;;
    --fundador-3-slug)        FUNDADOR_3_SLUG="$2"; shift 2;;
    --fundador-3-cargo)       FUNDADOR_3_CARGO="$2"; shift 2;;
    *) echo "flag desconhecida: $1" >&2; exit 1;;
  esac
done

# Validar obrigatórios
for var in EMPRESA EMPRESA_SLUG ORG EMPRESA_DOMINIO TIMEZONE IDIOMA \
           AGENTE_NOME AGENTE_SLUG AGENTE_TIME_NOME AGENTE_DIRETORIA_NOME \
           FUNDADOR_1 FUNDADOR_1_SLUG FUNDADOR_1_CARGO; do
  if [ -z "${!var}" ]; then
    flag="--$(echo "$var" | tr '[:upper:]_' '[:lower:]-')"
    echo "erro: argumento $flag obrigatório" >&2
    exit 1
  fi
done

# Validar all-or-nothing dos triples de fundador 2 e 3
for n in 2 3; do
  name_var="FUNDADOR_${n}"
  slug_var="FUNDADOR_${n}_SLUG"
  cargo_var="FUNDADOR_${n}_CARGO"
  set_count=0
  for v in "$name_var" "$slug_var" "$cargo_var"; do
    [ -n "${!v}" ] && set_count=$((set_count + 1))
  done
  if [ "$set_count" -ne 0 ] && [ "$set_count" -ne 3 ]; then
    echo "erro: triple --fundador-${n}/--fundador-${n}-slug/--fundador-${n}-cargo é all-or-nothing." >&2
    echo "       passe os 3 ou nenhum." >&2
    exit 1
  fi
done

# Validar slugs
validate_slug() {
  local slug="$1"
  local label="$2"
  if ! [[ "$slug" =~ ^[a-z0-9][a-z0-9-]*[a-z0-9]$ ]]; then
    echo "erro: slug inválido '$slug' em $label. Use lowercase, números, hífen." >&2
    exit 1
  fi
}

validate_slug "$EMPRESA_SLUG"     "--empresa-slug"
validate_slug "$AGENTE_SLUG"      "--agente-slug"
validate_slug "$ORG"              "--org"
validate_slug "$FUNDADOR_1_SLUG"  "--fundador-1-slug"
[ -n "$FUNDADOR_2_SLUG" ] && validate_slug "$FUNDADOR_2_SLUG" "--fundador-2-slug"
[ -n "$FUNDADOR_3_SLUG" ] && validate_slug "$FUNDADOR_3_SLUG" "--fundador-3-slug"

# ======================
# Pré-checagens
# ======================

ROOT="$(git rev-parse --show-toplevel 2>/dev/null || pwd)"
cd "$ROOT"

if [ -f ".cerebro-inicializado" ]; then
  echo "erro: este cérebro já foi inicializado (.cerebro-inicializado existe)." >&2
  echo "       Se quer resetar, apague o arquivo e rode de novo (risco: sobrescreve substituições)." >&2
  exit 1
fi

# Deve haver placeholders pra substituir (senão alguém já rodou e apagou o arquivo de trava)
if ! grep -rq "{{EMPRESA}}" . --include='*.md' --exclude-dir=.git 2>/dev/null; then
  echo "aviso: não encontrei placeholders {{EMPRESA}} nos arquivos." >&2
  echo "       O repo pode já ter sido inicializado. Continue com -y pra forçar, ou aborte." >&2
  read -r -p "continuar mesmo assim? (s/N) " confirma
  [[ "$confirma" =~ ^[sS]$ ]] || exit 1
fi

# Garantir branch 'staging' (cérebro coletivo trabalha em staging; main só via consolidação noturna)
CURRENT_BRANCH=$(git rev-parse --abbrev-ref HEAD 2>/dev/null || echo "")
if [ "$CURRENT_BRANCH" != "staging" ]; then
  if git show-ref --verify --quiet refs/heads/staging; then
    echo "-> trocando da branch '$CURRENT_BRANCH' pra 'staging'"
    git checkout staging
  else
    echo "-> branch 'staging' não existe — criando a partir de '$CURRENT_BRANCH'"
    git checkout -b staging
  fi
fi

# Backup tag
BACKUP_TAG="pre-inicializacao-$(date +%Y%m%d-%H%M%S)"
git tag "$BACKUP_TAG" 2>/dev/null || true
echo "-> tag de backup criada: $BACKUP_TAG"

# ======================
# Substituição de placeholders
# ======================

echo "-> aplicando substituições em arquivos .md / .sh / .yaml / .yml / .html"

# sed portátil (BSD/macOS vs GNU)
if sed --version 2>/dev/null | grep -q GNU; then
  SED_INPLACE=(-i)
else
  SED_INPLACE=(-i '')
fi

# IMPORTANTE: o find exclui o diretório scripts/ do próprio inicializar — senão
# o sed substituiria placeholders dentro deste script (ex: {{EMPRESA}} em strings
# de erro/aviso), poluindo o script com hardcode da empresa atual e quebrando
# re-execução em outro contexto.
SCRIPTS_DIR_EXCLUDE='./empresa/skills/inicializar-cerebro/scripts'

# Função helper
replace_in_tree() {
  local key="$1"
  local value="$2"
  # escapa para sed (barras, & e |)
  local escaped
  escaped=$(printf '%s\n' "$value" | sed -e 's/[\/&|]/\\&/g')
  find . -type f \( -name '*.md' -o -name '*.sh' -o -name '*.yaml' -o -name '*.yml' -o -name '*.html' \) \
    -not -path './.git/*' \
    -not -path "${SCRIPTS_DIR_EXCLUDE}/*" \
    -print0 | xargs -0 sed "${SED_INPLACE[@]}" "s|{{${key}}}|${escaped}|g"
}

# IMPORTANTE: substituir variantes mais longas (FUNDADOR_N_SLUG, FUNDADOR_N_CARGO) ANTES
# da curta (FUNDADOR_N) — sed faz match exato com {{...}} então não há colisão real,
# mas a ordem deixa o output do log mais previsível.

# Pré-processamento: remover blocos delimitados por marker template-only.
# Tudo entre <!-- template-only-start --> e <!-- template-only-end --> some
# (inclusive os marcadores). Útil pra instruções meta-template tipo "substitua os
# placeholders {{...}}" que só fazem sentido enquanto o repo é template upstream.
find . -type f -name '*.md' -not -path './.git/*' \
  -not -path "${SCRIPTS_DIR_EXCLUDE}/*" \
  -print0 | xargs -0 sed "${SED_INPLACE[@]}" \
  '/<!-- template-only-start -->/,/<!-- template-only-end -->/d'

replace_in_tree "EMPRESA"                "$EMPRESA"
replace_in_tree "EMPRESA_SLUG"           "$EMPRESA_SLUG"
replace_in_tree "ORG"                    "$ORG"
replace_in_tree "EMPRESA_DOMINIO"        "$EMPRESA_DOMINIO"
replace_in_tree "TIMEZONE"               "$TIMEZONE"
replace_in_tree "IDIOMA"                 "$IDIOMA"
replace_in_tree "AGENTE_NOME"            "$AGENTE_NOME"
replace_in_tree "AGENTE_SLUG"            "$AGENTE_SLUG"
replace_in_tree "AGENTE_TIME_NOME"       "$AGENTE_TIME_NOME"
replace_in_tree "AGENTE_DIRETORIA_NOME"  "$AGENTE_DIRETORIA_NOME"

replace_in_tree "FUNDADOR_1_SLUG"        "$FUNDADOR_1_SLUG"
replace_in_tree "FUNDADOR_1_CARGO"       "$FUNDADOR_1_CARGO"
replace_in_tree "FUNDADOR_1"             "$FUNDADOR_1"
replace_in_tree "FUNDADOR_2_SLUG"        "$FUNDADOR_2_SLUG"
replace_in_tree "FUNDADOR_2_CARGO"       "$FUNDADOR_2_CARGO"
replace_in_tree "FUNDADOR_2"             "$FUNDADOR_2"
replace_in_tree "FUNDADOR_3_SLUG"        "$FUNDADOR_3_SLUG"
replace_in_tree "FUNDADOR_3_CARGO"       "$FUNDADOR_3_CARGO"
replace_in_tree "FUNDADOR_3"             "$FUNDADOR_3"

# ======================
# Limpeza de footers meta-template
# ======================
# Pós-substituição os rodapés "*Template: substitua...*" e "*Gerado a partir...*"
# viram autorreferenciais (ex: "*Template: substitua 'Átila' pelos dados...*").
# Removemos essas linhas — são instruções pra quem clona, não pra quem já clonou.

echo "-> removendo rodapés meta-template (auto-referenciais pós-init)"

find . -type f -name '*.md' -not -path './.git/*' -print0 \
  | xargs -0 sed "${SED_INPLACE[@]}" \
      -e '/^\*Template:.*\*$/d' \
      -e '/^\*Gerado a partir.*\*$/d'

# ======================
# Regenerar README.md raiz
# ======================
# README upstream descreve o template — não a empresa que acabou de inicializar.
# Substitui por um stub mínimo (links pros docs canônicos do cérebro inicializado).

echo "-> regenerando README.md raiz como stub da empresa"

cat > README.md <<README_EOF
# Cérebro operacional — $EMPRESA

Cérebro do time da $EMPRESA. Gerado a partir do [template-second-brain-empresa](https://github.com/pixel-educacao/template-second-brain-empresa) (Pixel AI Hub).

## Navegação

- [\`CLAUDE.md\`](CLAUDE.md) — instruções pro Claude Code / Cowork operar este cérebro
- [\`MAPA.md\`](MAPA.md) — índice das áreas e skills
- [\`empresa/contexto/FLUXO-CAPTURA.md\`](empresa/contexto/FLUXO-CAPTURA.md) — fluxo canônico de captura (visitante)
- [\`onboarding/SETUP.md\`](onboarding/SETUP.md) — onboarding completo (~1h)

## Áreas

- [\`areas/marketing/\`](areas/marketing/MAPA.md)
- [\`areas/vendas/\`](areas/vendas/MAPA.md)
- [\`areas/atendimento/\`](areas/atendimento/MAPA.md)
- [\`areas/operacoes/\`](areas/operacoes/MAPA.md)
- [\`areas/produto/\`](areas/produto/MAPA.md)

## Como começar

Se você é membro novo do time, comece em [\`onboarding/SETUP.md\`](onboarding/SETUP.md) ou peça ao Claude Code: _"rode a skill onboarding-membro-time"_.
README_EOF

# ======================
# Renomear pasta do agente
# ======================

if [ -d "agentes/geral-empresa" ] && [ ! -d "agentes/$AGENTE_SLUG" ]; then
  echo "-> renomeando agentes/geral-empresa/ → agentes/$AGENTE_SLUG/"
  git mv "agentes/geral-empresa" "agentes/$AGENTE_SLUG"
elif [ -d "agentes/$AGENTE_SLUG" ]; then
  echo "-> pasta agentes/$AGENTE_SLUG/ já existe, preservando"
fi

# ======================
# Criar arquivo de trava
# ======================

cat > ".cerebro-inicializado" <<EOF
inicializado_em: $(date --iso-8601=seconds 2>/dev/null || date +"%Y-%m-%dT%H:%M:%S%z")
empresa: $EMPRESA
empresa_slug: $EMPRESA_SLUG
org: $ORG
agente_nome: $AGENTE_NOME
agente_slug: $AGENTE_SLUG
agente_time_nome: $AGENTE_TIME_NOME
fundador_1: $FUNDADOR_1
fundador_1_slug: $FUNDADOR_1_SLUG
fundador_1_cargo: $FUNDADOR_1_CARGO
fundador_2: $FUNDADOR_2
fundador_2_slug: $FUNDADOR_2_SLUG
fundador_2_cargo: $FUNDADOR_2_CARGO
fundador_3: $FUNDADOR_3
fundador_3_slug: $FUNDADOR_3_SLUG
fundador_3_cargo: $FUNDADOR_3_CARGO
timezone: $TIMEZONE
idioma: $IDIOMA
versao_template: 1.0
tag_backup: $BACKUP_TAG
EOF

echo "-> .cerebro-inicializado criado"

# ======================
# Verificação de placeholders residuais
# ======================

echo
echo "-> verificando placeholders residuais (allowlist em SKILL.md)..."

# Allowlist de placeholders deferidos (preenchidos por outras skills ou edição manual)
ALLOWLIST_RE='\{\{(SEU_NOME|SEU_SLUG|SUA_ORG|MEMBRO_EQUIPE_SLUG|AGENTE_PESSOAL_NOME|EMAIL_OPERACIONAL|EMOJI|TIPO_EMPRESA|PRODUTOS_DESCRICAO|ESCOPO_(MARKETING|VENDAS|ATENDIMENTO|OPERACOES|PRODUTO)|LEAD_(MARKETING|VENDAS|ATENDIMENTO|OPERACOES|PRODUTO))\}\}'

RESIDUAL=$(grep -rnE '\{\{[A-Z_]+\}\}' . \
  --include='*.md' --include='*.sh' --include='*.yaml' --include='*.yml' --include='*.html' \
  --exclude-dir=.git 2>/dev/null \
  | grep -v 'empresa/skills/inicializar-cerebro/scripts/' \
  | grep -vE "$ALLOWLIST_RE" || true)

if [ -n "$RESIDUAL" ]; then
  echo "erro: placeholders FORA da allowlist ainda no repo:" >&2
  echo "$RESIDUAL" | head -20 >&2
  echo "(...lista truncada em 20 linhas)" >&2
  echo "" >&2
  echo "Causas comuns:" >&2
  echo "  1) Faltou flag --xxx na invocação." >&2
  echo "  2) Placeholder novo no template que precisa entrar na allowlist (intencional pós-init)." >&2
  echo "  3) Placeholder real esquecido no template — corrigir upstream." >&2
  echo "" >&2
  echo "Pra desfazer: git reset --hard $BACKUP_TAG && rm .cerebro-inicializado" >&2
  exit 2
fi

echo "✅ todos os placeholders esperados substituídos (allowlist preservada)"

# ======================
# Commit
# ======================

echo
echo "-> preparando commit em staging"

git add -A
git -c user.name="$FUNDADOR_1" -c user.email="${AGENTE_SLUG}@${EMPRESA_DOMINIO}" commit -m "init: $EMPRESA second brain inicializado

Placeholders substituídos, agente '$AGENTE_NOME' configurado, pasta agentes/$AGENTE_SLUG/ criada.
Arquivo .cerebro-inicializado grava metadados. Backup: tag $BACKUP_TAG."

# Cleanup do backup tag em sucesso (se algo abortou antes, tag fica preservada pra rollback)
git tag -d "$BACKUP_TAG" >/dev/null 2>&1 || true

echo
echo "== inicialização concluída =="
echo "próximos passos:"
echo "  1) git push -u origin staging"
echo "  2) rodar skill 'setup-estacao-pessoal' no Claude Code (cria sua inbox)"
echo "  3) em VPS, rodar skill 'setup-agente-openclaw' (sobe $AGENTE_NOME 24/7)"
echo
echo "ver roadmap completo em empresa/skills/inicializar-cerebro/SKILL.md (Passo 7)"
