---
name: inicializar-cerebro
description: Configurar o cérebro do time pela primeira vez após clonar o template-second-brain-empresa. Preenche placeholders ({{EMPRESA}}, {{AGENTE_NOME}}, etc.) em todos os arquivos, renomeia a pasta do agente pro nome escolhido, e apresenta o roadmap de próximos passos (estação pessoal, agente OpenClaw em VPS). Roda **UMA VEZ** após o clone — aborta se já foi executada. Use logo após o "Use this template" do GitHub.
---

# Inicializar Cérebro — Template Empresa/Time

> Esta skill é um **tutorial + configurador**. Ela ensina como o cérebro funciona enquanto configura ele pra sua empresa. Rode **uma única vez**, no primeiro uso do repo clonado.

## Quando usar

Você acabou de clicar em "Use this template" no GitHub e clonou a cópia localmente. Este é o primeiro comando que você roda no Claude Code / Cowork no workspace do repo.

## Quando **não** usar

- Se o arquivo `.cerebro-inicializado` já existe na raiz, a skill aborta — o cérebro já foi configurado. Não rode de novo.
- Se você quer apenas criar sua estação pessoal (depois da inicialização), use `setup-estacao-pessoal`.
- Se você quer subir o agente em VPS, use `setup-agente-openclaw`.

## Fluxo da skill (7 passos + roadmap final)

### Passo 1 — Contexto: o modelo de 2 cérebros

Antes de configurar, o agente (Claude Code) deve **explicar ao humano** o modelo:

- Este template é o **cérebro do time** — operacional (marketing, vendas, atendimento, operações, produto).
- Existe outro template complementar (`template-second-brain-diretoria`) — sensível (financeiro, RH, jurídico, governança).
- Os dois são **disjuntos**: conteúdo que dispara a **regra dos 3 gatilhos** (dinheiro com nome próprio, pessoa específica, peso contratual/jurídico) vive no repo da diretoria, nunca aqui.
- O agente geral deste cérebro é **gestor** — escreve direto em canônico. Humanos e agentes pessoais de diretor são **visitantes** — passam por `inbox/{nome}/`. Branch de trabalho: `staging`. Consolidação noturna promove pra `main`.

Pergunte: _"Entendeu o modelo? Alguma dúvida antes de configurar?"_

### Passo 2 — Coleta de dados

Perguntar em sequência (validar cada resposta antes de avançar):

1. **Nome da empresa** (ex: "Pixel Educação", "Acme Corp") → `{{EMPRESA}}`
2. **Slug da empresa** (ex: "pixel-educacao", "acme") → `{{EMPRESA_SLUG}}`. Sem espaços, lowercase, usar hífen. Será usado em paths e nomes de repo.
3. **Organização GitHub** (ex: "pixel-educacao") → `{{ORG}}`. Geralmente igual ao slug.
4. **Domínio de email operacional** (ex: "pixel.edu.br", "acme.com") → `{{EMPRESA_DOMINIO}}`
5. **Timezone** (default: `America/Sao_Paulo`) → `{{TIMEZONE}}`
6. **Idioma principal** (default: `pt-BR`) → `{{IDIOMA}}`
7. **Nome do agente geral do time** (ex: "Íris", "Oliver", "Atlas") → `{{AGENTE_NOME}}`. Nome é livre — escolha algo com personalidade.
8. **Slug do agente** (derivado do nome, lowercase, sem acento — ex: "iris", "oliver", "atila") → `{{AGENTE_SLUG}}`. Vai ser o nome da pasta em `agentes/{slug}/`.
9. **Nome coletivo do time de agentes** (ex: "Atlas", "Pleiades") → `{{AGENTE_TIME_NOME}}`. Como o conjunto de agentes da empresa se chama em conjunto. Pode ser igual ao agente único se vocês começam com 1 só — ajusta depois.
10. **Nome pretendido do agente da diretoria** (quando vocês abrirem o 2º cérebro) → `{{AGENTE_DIRETORIA_NOME}}`. Pode ser um placeholder se ainda não sabem, ex: "Geral Diretoria".
11. **Fundadores da empresa** — pelo menos 1 obrigatório, até 3 suportados nativamente (mais que isso, edite manual pós-init):
    - **Fundador 1** (obrigatório):
      - Nome (ex: "Ana Silva") → `{{FUNDADOR_1}}`
      - Slug (ex: "ana") → `{{FUNDADOR_1_SLUG}}`
      - Cargo (ex: "CEO") → `{{FUNDADOR_1_CARGO}}`
    - **Fundador 2** (opcional — se passar 1, passe os 3):
      - Nome → `{{FUNDADOR_2}}`, slug → `{{FUNDADOR_2_SLUG}}`, cargo → `{{FUNDADOR_2_CARGO}}`
    - **Fundador 3** (opcional — mesmo all-or-nothing):
      - Nome → `{{FUNDADOR_3}}`, slug → `{{FUNDADOR_3_SLUG}}`, cargo → `{{FUNDADOR_3_CARGO}}`

    Fundadores não fornecidos têm seus placeholders substituídos por string vazia. Se a empresa tem >3 fundadores, peça pra acrescentar manualmente em `empresa/contexto/` pós-init.

### Passo 3 — Confirmação

Mostrar um resumo dos valores coletados e pedir confirmação explícita antes de aplicar. Ex:

```
Vou aplicar estas substituições em ~35 arquivos:
  {{EMPRESA}}              = Acme Corp
  {{EMPRESA_SLUG}}         = acme
  {{ORG}}                  = acme-org
  {{AGENTE_NOME}}          = Oliver
  {{AGENTE_SLUG}}          = oliver
  {{AGENTE_TIME_NOME}}     = Atlas
  {{FUNDADOR_1}}           = Ana Silva
  {{FUNDADOR_1_SLUG}}      = ana
  {{FUNDADOR_1_CARGO}}     = CEO
  {{FUNDADOR_2}}           = (não fornecido)
  {{FUNDADOR_3}}           = (não fornecido)
  ...
E renomear: agentes/geral-empresa/ → agentes/oliver/

Placeholders deferidos (NÃO substituídos por esta skill — ver Allowlist):
  {{SEU_SLUG}}, {{MEMBRO_EQUIPE_SLUG}}, {{ESCOPO_*}}, {{LEAD_*}}, ...

Confirma? (sim/não)
```

### Passo 4 — Aplicar substituições

Rodar o script `scripts/inicializar.sh` com os valores:

```bash
bash empresa/skills/inicializar-cerebro/scripts/inicializar.sh \
  --empresa "Acme Corp" \
  --empresa-slug "acme" \
  --org "acme-org" \
  --empresa-dominio "acme.com" \
  --timezone "America/Sao_Paulo" \
  --idioma "pt-BR" \
  --agente-nome "Oliver" \
  --agente-slug "oliver" \
  --agente-time-nome "Atlas" \
  --agente-diretoria-nome "Geral Diretoria" \
  --fundador-1 "Ana Silva" \
  --fundador-1-slug "ana" \
  --fundador-1-cargo "CEO"
  # Opcional, se houver fundador 2 (passar os 3 ou nenhum):
  # --fundador-2 "Bruno Costa" --fundador-2-slug "bruno" --fundador-2-cargo "CTO" \
  # Opcional, se houver fundador 3 (mesma regra):
  # --fundador-3 "Carla Dias" --fundador-3-slug "carla" --fundador-3-cargo "CMO"
```

O script:
1. Faz `find + sed` em todo `*.md`, `*.sh`, `*.yaml`, `*.yml`, `*.html` fora de `.git/` substituindo os placeholders
2. Renomeia `agentes/geral-empresa/` → `agentes/{agente-slug}/`
3. Cria `.cerebro-inicializado` na raiz com timestamp + metadados (trava reexecução)
4. Faz commit em `staging`: `"init: {{EMPRESA}} second brain inicializado"`

Se algum passo falhar, o script aborta sem pushar — permite retry.

### Passo 5 — Verificação

Após o script:
- Verificar se ainda restam placeholders: `grep -rE '\{\{[A-Z_]+\}\}' . --exclude-dir=.git`
- Se restou, listar os arquivos e oferecer correção manual
- Mostrar `git diff --stat HEAD~1` pra dar visibilidade do que mudou

### Passo 6 — Push

Perguntar: _"Posso pushar pra `staging`?"_. Se sim:

```bash
git push -u origin staging
```

### Passo 7 — Roadmap de próximos passos

**Este é o passo mais importante pedagogicamente.** Explicar pro humano o que vem depois:

```
✅ Cérebro inicializado com sucesso!

Agora você tem 3 próximos passos (cada um é uma skill separada):

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
PRÓXIMO (agora) — Criar sua estação pessoal
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Você é a primeira pessoa deste cérebro. Precisa de uma estação em
inbox/{seu-nome}/ pra começar a capturar ideias/drafts/pesquisas.

→ Rode a skill: setup-estacao-pessoal

Ela vai perguntar seu nome curto, papel, e criar inbox/{slug}/ com
CLAUDE.md próprio. Salva identidade local pra não perguntar de novo.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
DEPOIS — Subir o agente Oliver em VPS (24/7)
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Seu agente geral (Oliver) precisa rodar num VPS dedicado 24/7 pra:
- sincronizar config automaticamente com este repo (cron 15 min em staging)
- rodar consolidação noturna (02:00 BRT) — promove maduro pra main, abre PR do resto

→ Rode a skill em VPS: setup-agente-openclaw

ATENÇÃO: se você já tem um OpenClaw configurado no VPS (ex: um agente
pessoal ou outro agente da empresa), a skill vai te perguntar se quer
SUBSTITUIR os arquivos atuais ou FAZER MERGE dos configs existentes
com os novos (preservando o tom/skills do seu OpenClaw atual). Leia
empresa/skills/setup-agente-openclaw/SKILL.md pros detalhes.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
CONFORME TIME CRESCER — Convidar pessoas
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Cada pessoa nova do time que for operar este cérebro:
1. Ganha acesso ao repo no GitHub (permissão Write)
2. Clona localmente
3. Roda setup-estacao-pessoal no Claude Code (mesma skill que VOCÊ vai
   rodar agora — ela pergunta nome, papel, cria inbox/{nome}/ dela)

Membros de time NÃO precisam subir OpenClaw pessoal em VPS — operam
sessões on-demand via Claude Code/Cowork no laptop.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
QUANDO A EMPRESA AMADURECER — Abrir cérebro da diretoria
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Ver empresa/contexto/ARQUITETURA.md. Sinalize quando:
- Primeira contratação CLT/PJ
- Primeiro contrato com distribuição/equity/NDA
- Primeira situação de RH que requer registro

→ Nessa hora, clone o template-second-brain-diretoria como REPO
SEPARADO e rode inicializar-cerebro nele também. Cada diretor depois
roda setup-agente-openclaw pra conectar o agente pessoal
dele aos 2 cérebros.

━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

Dúvidas? Leia:
- README.md — visão geral
- CLAUDE.md — instruções operacionais
- MAPA.md — mapa estrutural
- onboarding/GLOSSARIO.md — termos-chave
- empresa/contexto/PRINCIPIOS.md — regras duras
- empresa/contexto/ARQUITETURA.md — modelo dos 2 cérebros
```

## Glossário de placeholders de agente

Pra não confundir agente individual com nome coletivo do time de agentes:

| Placeholder | Significado | Exemplo |
|---|---|---|
| `{{AGENTE_NOME}}` | **Agente individual** — gestor deste cérebro do time, escreve direto em canônico, roda no VPS. | `Átila`, `Oliver`, `Íris` |
| `{{AGENTE_SLUG}}` | Slug do agente (lowercase, sem acento). Usado em paths (`agentes/{slug}/`) e identificadores técnicos. | `atila`, `oliver`, `iris` |
| `{{AGENTE_TIME_NOME}}` | **Nome coletivo** do time/coletivo de agentes da empresa. Aparece quando faz sentido falar do conjunto. | `Atlas`, `Pleiades`, `Constelação` |
| `{{AGENTE_DIRETORIA_NOME}}` | Nome do agente que vai gerir o cérebro **da diretoria** quando ele for aberto (repo separado). | `Erina`, `Solene` |
| `{{AGENTE_PESSOAL_NOME}}` (deferido) | Nome do agente pessoal de **um diretor** (cérebro pessoal, repo próprio). Cada diretor define o dele. | `Mira`, `Joana` |

Se a empresa começa com 1 agente só, é razoável `{{AGENTE_NOME}}` e `{{AGENTE_TIME_NOME}}` serem iguais — o time é o agente. Quando a empresa cresce e cria mais agentes especializados (atendimento, vendas, etc.), `{{AGENTE_TIME_NOME}}` passa a representar o conjunto.

## Allowlist — placeholders deferidos pós-init

Esta skill substitui apenas placeholders relativos a **identidade da empresa, agente gestor e fundadores**. Os placeholders abaixo permanecem propositalmente após o init — são preenchidos por skills downstream ou por edição manual quando o conteúdo da área amadurece.

| Placeholder | Preenchido por |
|---|---|
| `{{SEU_NOME}}`, `{{SEU_SLUG}}` | `setup-estacao-pessoal` (no momento em que cada pessoa cria sua inbox) |
| `{{MEMBRO_EQUIPE_SLUG}}` | `setup-estacao-pessoal` / `onboarding-membro-time` |
| `{{SUA_ORG}}` | edição manual em `onboarding/SETUP.md` (ou substituído por `{{ORG}}` se idêntico) |
| `{{AGENTE_PESSOAL_NOME}}` | `inicializar-cerebro` do `template-second-brain-pessoal` (cada diretor) |
| `{{EMAIL_OPERACIONAL}}` | edição manual em `agentes/{{AGENTE_SLUG}}/IDENTITY.md` |
| `{{EMOJI}}` | edição manual em `agentes/{{AGENTE_SLUG}}/IDENTITY.md` ou `SOUL.md` |
| `{{TIPO_EMPRESA}}` | edição manual em `empresa/contexto/CONTEXTO.md` (quando criado) |
| `{{PRODUTOS_DESCRICAO}}` | edição manual em `empresa/contexto/PRODUTOS.md` (quando criado) |
| `{{ESCOPO_MARKETING}}`, `{{ESCOPO_VENDAS}}`, `{{ESCOPO_ATENDIMENTO}}`, `{{ESCOPO_OPERACOES}}`, `{{ESCOPO_PRODUTO}}` | edição manual no `MAPA.md` de cada área quando o time delimitar escopo |
| `{{LEAD_MARKETING}}`, `{{LEAD_VENDAS}}`, `{{LEAD_ATENDIMENTO}}`, `{{LEAD_OPERACOES}}`, `{{LEAD_PRODUTO}}` | edição manual quando alguém assume liderança da área |

**Por que deferido:** estes valores ou (a) são por-pessoa e a empresa ainda não conhece todos os membros no momento do init, ou (b) dependem de decisões editoriais por área que não fazem sentido travar antes do conteúdo amadurecer.

O script `inicializar.sh` valida esta allowlist no fim da execução: placeholders não-allowlist remanescentes geram aviso explícito.

## Regras de segurança

- **Não sobrescrever `.cerebro-inicializado`** — se existe, skill aborta
- **Commit só em `staging`** — nunca em `main`
- **Backup opcional**: antes do `sed`, criar `git tag pre-inicializacao` pra permitir revert
- **Validar todos os inputs** antes de aplicar — especialmente slugs (regex `^[a-z0-9-]+$`)

## Recursos desta skill

- `scripts/inicializar.sh` — script bash que executa passos 4 (sed + rename)
- Este SKILL.md — tutorial + contrato da skill

## Depois dessa skill

Arquivo `.cerebro-inicializado` criado na raiz contendo:

```yaml
inicializado_em: 2026-04-20T15:32:00-03:00
empresa: Acme Corp
empresa_slug: acme
org: acme-org
agente_nome: Oliver
agente_slug: oliver
agente_time_nome: Atlas
fundador_1: Ana Silva
fundador_1_slug: ana
fundador_1_cargo: CEO
fundador_2: ""
fundador_2_slug: ""
fundador_2_cargo: ""
fundador_3: ""
fundador_3_slug: ""
fundador_3_cargo: ""
timezone: America/Sao_Paulo
idioma: pt-BR
versao_template: 1.0
tag_backup: pre-inicializacao-...
```

Esse arquivo é referência histórica + trava de reexecução.

---

*Skill de primeira execução. Roda 1 vez. Opcional deletar a skill após uso (preservar em histórico git).*
