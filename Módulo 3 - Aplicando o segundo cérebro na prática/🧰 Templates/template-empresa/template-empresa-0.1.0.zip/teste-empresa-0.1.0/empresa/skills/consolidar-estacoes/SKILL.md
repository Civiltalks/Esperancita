---
name: consolidar-estacoes
description: >
  Rotina de consolidação noturna das estações pessoais do time.
  Lê tudo que foi capturado em inbox/{nome}/ ao longo do dia, promove para main
  o que está maduro, abre PR pro que precisa revisão humana, arquiva o processado
  e reseta staging. É a rotina de "sono" do Pixel Second Brain.
  Quem executa: {{AGENTE_NOME}}. Quando: ~02:00 BRT todo dia.
  Palavras-chave: consolidação, consolidar, estações, inbox, rotina noturna, sono, PR.
---

# consolidar-estacoes

## O que faz

Roda a rotina de consolidação noturna do Pixel Second Brain. É a contraparte da captura que acontece durante o dia nas estações pessoais (`inbox/{nome}/`). No final do ciclo, `staging` volta a estar idêntica a `main`, com os inboxes zerados e o conteúdo capturado promovido, arquivado ou proposto como PR conforme a maturidade.

## Quando usar

- **Automático:** `heartbeat` do {{AGENTE_NOME}} dispara às ~02:00 BRT todos os dias.
- **Manual:** quando precisar consolidar fora do ciclo (ex: antes de uma reunião importante de manhã).

## Ferramentas necessárias

- `Bash` — git, movimentação de arquivos
- `Read` / `Write` — ler sidecar `.meta.yaml` e escrever digest
- `gh` (GitHub CLI) — abrir pull requests

## Regras de segurança (invioláveis)

1. **Nunca resolver conflito sozinho.** Se `git merge staging → main` gerar conflito, parar a rotina, alertar o time (Telegram/grupo) e não mexer em nada.
2. **Nunca perder captura.** Antes de qualquer remoção de arquivo em staging, o conteúdo já deve estar arquivado em `inbox/{nome}/_historico/{data}/` ou promovido pra canônico. Se houver dúvida, manter o arquivo onde está.
3. **Staging reflete o dia inteiro do {{AGENTE_NOME}} — inclusive writes dele em canônico.** {{AGENTE_NOME}} é o agente deste cérebro e é o **único** que escreve direto em `areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/` durante o dia (humanos e agentes pessoais só mexem em `inbox/`). A skill **não audita** autoria nem trata isso como violação. O merge final (step 7) leva tudo pra main.
4. **Limite de auto-promoção.** Se um único arquivo tiver `>500 linhas`, ou se a rotina classificar `>20 arquivos como pronto-para-canonico` num só dia, pausa auto-promoção e abre tudo como PR. Volume anômalo = sinal de problema.

## Passo a passo

### 1. Preparação — commit do próprio trabalho PRIMEIRO

{{AGENTE_NOME}} é o agente que **roda esta skill** e também é o **único** que escreve direto em canônico (`areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/`) durante o dia. Como ele faz os dois papéis, o repo local dele tende a ter mudanças pendentes no working tree quando chega a hora da consolidação. **Essas mudanças são pré-condição da rotina, não ruído** — o próprio {{AGENTE_NOME}} precisa garantir que commitou e pushou o próprio trabalho antes de começar a classificar os inboxes dos visitantes. Humanos e agentes pessoais só mexem em `inbox/` (e já pushem via `/sync-empresa`), então canônico só aparece em staging se o {{AGENTE_NOME}} subir.

```bash
cd /root/.openclaw/workspace/{{EMPRESA_SLUG}}-second-brain
git fetch origin

# 1.a. Sobe o trabalho local do {{AGENTE_NOME}} pro staging (writes canônicos do dia)
git checkout staging
git pull --rebase origin staging

# IMPORTANTE: pathspec exclusivo. NUNCA `git add .` aqui.
# `git add .` engole untracked de visitantes (ex: nota sem sidecar criada
# em inbox/{slug}/) com autoria do gestor — destrói audit trail. Inbox de
# visitantes é responsabilidade do /sync-empresa deles, não desta rotina.
git add . ":!inbox/"
git diff --cached --quiet || git commit -m "{{AGENTE_SLUG}}: writes canônicos do dia $(date -u +%Y-%m-%d)"
git push origin staging

# 1.b. Atualiza main pra comparação no step 2
git checkout main
git pull --rebase origin main
```

**Não pular 1.a.** Se o working tree local tem mudanças e você só faz `git pull` sem commitar antes, a consolidação vai processar apenas as capturas dos visitantes — e o canônico do {{AGENTE_NOME}} do dia fica órfão no VPS, invisível pro resto.

**⚠️ Nunca trocar `git add . ":!inbox/"` por `git add .`** — isso engole arquivos untracked de visitantes em `inbox/{slug}/` no commit do gestor, atribuindo autoria errada e poluindo `git log`/`git blame`. Untracked em inbox de visitantes deve ser commitado pelo próprio visitante via `/sync-empresa`. Esta skill **não suplementa** o fluxo de captura do visitante.

### 2. Inventariar staging (sem gate)

```bash
git diff --name-status main..staging
```

Staging acumula 2 tipos de mudança durante o dia:

- **`inbox/*/`** — capturas de visitantes (humanos, agentes pessoais de diretores). Vão pra classificação no step 3.
- **Fora de `inbox/*/`** (`areas/`, `empresa/`, `agentes/{{AGENTE_SLUG}}/`, etc.) — writes canônicos diretos do {{AGENTE_NOME}} durante o dia (subidos no step 1.a). {{AGENTE_NOME}} é o único que mexe em canônico; a skill **não valida autoria nem bloqueia**. Esses writes fluem pra main naturalmente via merge no step 7.

Esta skill **não** audita violação de regra (CLAUDE.md, pre-commit, revisão de PR são as camadas que fazem isso). Só processa inbox e fecha o ciclo.

### 3. Classificar cada arquivo

Para cada arquivo em `inbox/{nome}/` — **qualquer formato** (`.md`, `.html`, `.pdf`, `.png`, `.pptx`, etc.) —
ignorar:
- `inbox/_TEMPLATE/` (esqueleto da skill `setup-estacao-pessoal`, não é estação de pessoa)
- `privado/` (gitignored — nem aparece aqui)
- `_historico/`
- `README.md` e `CLAUDE.md` (infra da estação, não captura)
- próprios sidecars `*.meta.yaml` (não se classificam; apenas alimentam a classificação dos arquivos-par)

Ao iterar com glob, sempre filtrar `_TEMPLATE/`:

```bash
for dir in inbox/*/; do
  [ "$(basename "$dir")" = "_TEMPLATE" ] && continue
  # ... processar dir
done
```

a. Para cada captura `foo.ext`, procurar sidecar `foo.ext.meta.yaml` no mesmo diretório.
b. Ler o sidecar YAML.
c. Aplicar a matriz de classificação:

| maturidade | tipo | ação |
|---|---|---|
| `pronto-para-canonico` | (qualquer) com `destino_sugerido` válido | **promover** para `destino_sugerido`, commit direto em main |
| `pronto-para-canonico` | sem `destino_sugerido` | **PR de revisão** — {{AGENTE_NOME}} sugere destino com base em tags/relacionado |
| `draft` | `proposta-canonica` | **PR direcionado** ao `destino_sugerido` pedindo merge no arquivo canônico |
| `draft` | `nota` / `referencia` | manter em `inbox/{nome}/` — ainda verde |
| `cru` | (qualquer) | manter; se já passou de 7 dias sem evoluir, arquivar em `_historico/` |
| `diario` | (qualquer) | arquivar em `_historico/{data}/diario.md` no fim do dia |

d. **Sidecar ausente ou malformado:** marcar pra revisão manual, **não promover**, avisar no digest. Mensagem: *"captura {arquivo} sem sidecar — pedir frontmatter ao autor"*. Exceção: arquivos do sistema (`README.md`, `CLAUDE.md`) não exigem sidecar.

e. Ao promover ou mover captura, **mover o sidecar junto**. Ao promover pra canônico: **descartar o sidecar** (canônico não carrega metadata de consolidação).

### 4. Aplicar promoções seguras

Para cada arquivo classificado como **promover**:

```bash
# copiar só o conteúdo — o sidecar NÃO vai pro canônico
cp inbox/{nome}/{arquivo}.{ext} {destino-canonico}
git add {destino-canonico}

# o sidecar será descartado junto com o arquivo-fonte no passo de arquivamento (6)
```

Para arquivos que substituem canônico existente, fazer **merge editorial inteligente**: não sobrescrever cego, entender o que o canônico já tem e integrar. Se a complexidade do merge for alta, classificar como PR em vez de promoção direta.

**Importante:** canônico é sempre **livre de metadata de consolidação**. Nada de YAML de classificação embutido. Se a informação do sidecar precisa persistir (ex: autoria original), registrar no commit message ou no digest, não no arquivo canônico.

### 5. Abrir PRs de revisão

Para cada arquivo classificado como **PR**:

```bash
# criar branch temporária a partir de main
git checkout -b consolidacao/{data}/{nome}-{slug}
# aplicar a mudança proposta no destino canônico
git add {destino-canonico}
git commit -m "proposta: {descricao}"
git push -u origin consolidacao/{data}/{nome}-{slug}

# abrir PR via gh
gh pr create \
  --base main \
  --title "Consolidação {data}: {titulo}" \
  --body "{corpo com: autor, arquivo-fonte em staging, destino sugerido, trecho relevante}" \
  --reviewer {{FUNDADOR_1_SLUG}}
```

### 6. Arquivar processados

Para cada arquivo que foi promovido ou virou PR, mover o arquivo **e seu sidecar** pro histórico:

```bash
DATA=$(date -u +%Y-%m-%d)
mkdir -p inbox/{nome}/_historico/${DATA}
git mv inbox/{nome}/{arquivo}.{ext} inbox/{nome}/_historico/${DATA}/
# mover sidecar junto — historico preserva o par completo pra auditoria
git mv inbox/{nome}/{arquivo}.{ext}.meta.yaml inbox/{nome}/_historico/${DATA}/ 2>/dev/null || true
```

Arquivos classificados como **manter** não são arquivados — seguem disponíveis no inbox no dia seguinte (com sidecar).

Arquivos classificados como `diario` são movidos pro histórico automaticamente no fim do dia, junto com seus sidecars.

### 7. Merge staging → main (traz tudo do dia)

A regra aqui inverteu: merge é **staging → main**, porque staging pode ter:
- Writes canônicos do {{AGENTE_NOME}} do dia (fora de inbox)
- Promoções recém-aplicadas em main pela skill (já estão em main)
- Arquivamentos de inbox que a skill fez (em staging)

```bash
# 1. Finaliza staging com os arquivamentos que a skill fez
git checkout staging
git add .
git diff --cached --quiet || git commit -m "consolidacao {data}: arquivamento de estações processadas"
git push origin staging

# 2. Commita promoções que a skill aplicou em main (step 4)
git checkout main
git pull --rebase origin main
git add .
git diff --cached --quiet || git commit -m "consolidacao {data}: promoções de estações para canônico"

# 3. Traz os writes do {{AGENTE_NOME}} + arquivamentos de staging pra main via merge
git merge staging --no-ff -m "consolidacao {data}: merge de staging (writes do dia + arquivamentos)"
git push origin main

# 4. Sincroniza staging com main (fast-forward trivial)
git checkout staging
git merge main --ff-only 2>/dev/null || git merge main --no-ff -m "consolidacao {data}: sync staging com main"
git push origin staging
```

Resultado: `staging` ≡ `main` exceto por inboxes que ficaram verdes (classificados como "manter" no step 3). Tudo que o {{AGENTE_NOME}} escreveu durante o dia tá em main.

### 8. Escrever o digest — "jornal da manhã"

Criar `empresa/consolidacao/{YYYY-MM-DD}.md` com:

- **Promovido direto** — lista de arquivos que foram pra canônico automaticamente, com origem e destino
- **PRs abertos** — links dos PRs criados, com resumo de cada um
- **Arquivado sem promoção** — capturas que estavam há mais de 7 dias cru
- **Mantido no inbox** — capturas ainda verdes, com idade
- **Problemas encontrados** — frontmatters ausentes, arquivos malformados, violações de regra
- **Heartbeat de cada estação** — quantas capturas cada pessoa fez no dia (sinal de uso do sistema)

```bash
git add empresa/consolidacao/${DATA}.md
git commit -m "consolidacao {data}: digest"
git push origin main
```

### 9. Sync final staging ← main

O digest acabou de entrar em `main` (step 8) e não está em `staging`. Sem este passo, `staging` fica 1 commit atrás todo dia, e o `pull --rebase` da próxima sessão de visitante faz rebase desnecessário.

```bash
git checkout staging
git merge main --ff-only
git push origin staging
```

`--ff-only` é o esperado aqui (staging deveria ser ancestral de main após step 7). Se falhar, alguém pushou em staging entre o step 7 e este — investigar antes de fazer merge não-ff.

### 10. Notificação

Postar no canal do Telegram da Pixel um resumo curto:

> 🌙 Consolidação {data} feita.
> • X promovidos, Y PRs abertos, Z arquivados.
> • Jornal completo: empresa/consolidacao/{data}.md
> • PRs esperando revisão: [lista]

Se houve alerta (regra violada, conflito, volume anômalo), usar emoji 🚨 e alertar nominalmente o {{FUNDADOR_1}}.

## Output esperado

- `main` atualizada com promoções
- `staging` sincronizada com `main` (inboxes processados arquivados, imaturos mantidos)
- PRs abertos no GitHub com reviewers atribuídos
- Digest salvo em `empresa/consolidacao/{data}.md`
- Mensagem no Telegram

## Notas

- **Frequência:** 1x por dia às ~02:00 BRT. Nunca rodar mais de uma vez no mesmo dia (cria duplicata no histórico).
- **Quem aprova PRs:** default é {{FUNDADOR_1}}. Pode expandir pra lista de reviewers quando o time crescer.
- **Privacidade:** `inbox/{nome}/privado/` está no `.gitignore`, nunca aparece no staging, não é tocado por esta rotina.
- **Edge case — conflito no merge main → staging:** parar, criar issue, alertar. Não tentar adivinhar.
- **Edge case — mesmo tema capturado por 2+ pessoas:** detectar por overlap de tags/relacionado, destacar no digest como "atenção: duplicação detectada", abrir PR unificado quando possível.
- **Edge case — sidecar sem arquivo-par:** captura foi deletada mas o sidecar ficou. Marcar pra limpeza no próximo ciclo (mover ambos pro histórico se idade > 1 dia).
- **Edge case — arquivo sem sidecar (não-sistema):** não promover. Avisar no digest. Deixar no inbox até o autor criar o sidecar.
- **Modelo de inferência:** Sonnet (não Opus, por custo — seguir `agentes/{{AGENTE_SLUG}}/AGENTS.md`, seção "Split de Modelos").
