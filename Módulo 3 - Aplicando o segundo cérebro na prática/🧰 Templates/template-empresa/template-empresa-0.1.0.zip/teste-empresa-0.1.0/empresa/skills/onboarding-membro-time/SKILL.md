---
name: onboarding-membro-time
description: Wizard guiado pra um novo membro do time operacional que está entrando no cérebro da empresa pela primeira vez. Ensina o modelo (cérebros, estação pessoal, staging, sidecar, 3 gatilhos), cria a estação da pessoa (invoca setup-estacao-pessoal), faz uma captura de prática e valida que entendeu as regras. Use quando: nova contratação, pessoa do time voltando de afastamento, ou qualquer primeira sessão de humano operando o cérebro.
---

# Onboarding Membro de Time

> Skill orquestradora pedagógica. **Não substitui** `setup-estacao-pessoal` — ela **usa** essa skill como parte do fluxo, e adiciona contexto, prática e validação ao redor.

## Quando usar

- Nova contratação do time entrando no cérebro pela primeira vez
- Membro antigo que nunca operou o cérebro (migrando de Notion / outro sistema)
- Quando o humano pede: _"como funciona isso aqui?"_ / _"quero aprender o fluxo"_ / _"nunca usei o Claude Code"_

## Quando **não** usar

- Pessoa é **diretor** → use `onboarding-diretor` no repo da diretoria (ela vai além, configura os 2 cérebros + OpenClaw pessoal)
- Pessoa já tem estação em `inbox/{slug}/` neste repo e só quer capturar → não precisa skill, é só abrir Claude e capturar
- Você só quer criar a pasta da estação sem a parte educacional → use `setup-estacao-pessoal` direto

## Fluxo — 8 passos

### Passo 1 — Boas-vindas + quem é você

Pergunte quem está operando agora (nome + papel). Salve pra usar nos próximos passos personalizando.

Diga:

> _"Bem-vindo ao cérebro do time da {{EMPRESA}}. Antes de configurar sua estação, vou explicar o modelo em ~5 min — porque entender o fluxo é mais importante do que rodar o comando. Depois disso, você captura uma ideia de exemplo pra praticar, e saí operando."_

### Passo 2 — O que é um "cérebro" aqui

Explique:

- **Cérebro** = este repositório Git. É a fonte canônica de verdade da empresa. Substitui Notion/Wiki/Docs pra conhecimento operacional durável.
- Humanos **e** agentes de IA (como {{AGENTE_NOME}}) operam no mesmo espaço.
- **Dois cérebros** existem: este (time, operacional) e outro (diretoria, sensível). Você tem acesso só a este se for membro de time. Se for diretor, tem acesso aos dois — nesse caso pare aqui e rode `onboarding-diretor` no repo da diretoria.

### Passo 3 — Seu papel: visitante

Explique:

- Você é **visitante** do canônico. Nunca edita direto `empresa/`, `areas/`, `agentes/`.
- Você captura em **`inbox/{seu-slug}/`** — sua estação pessoal, só sua.
- O agente {{AGENTE_NOME}} é o **gestor** — ele consolida todas as estações à noite e decide o que virou canônico.
- Branch de trabalho = **`staging`**. `main` só muda pela consolidação noturna.

**Importante (mudança de 2026-05):** capturas **não vão em tempo real** pro inbox. Você usa **uma skill** que cobre tudo:

- **`/sync-empresa`** — empacota e empurra capturas pra `inbox/{seu-slug}/` em staging via quiz item-a-item. Detecta seu modo automaticamente:
  - **Funcionário** (você): lê `inbox/{seu-slug}/` local não-commitado e commita em staging
  - **Diretor** (cross-brain): lê commits novos do `~/{{EMPRESA_SLUG}}/pessoal/` e copia pra empresa

Sempre manual. Default: não distribuir (você confirma item-a-item). Substitui `/save` + `/team-sync` antigos.

Isso te dá chance de revisar antes de publicar. Nada vaza pro staging sem você confirmar.

Pergunte: _"Faz sentido até aqui?"_

### Passo 4 — Regras duras

Explique as 3 regras invioláveis:

1. **Sidecar `.meta.yaml` obrigatório.** Toda captura (arquivo `.md`, `.pdf`, `.png`, qualquer coisa) tem um arquivo-par `{nome}.ext.meta.yaml` que classifica a captura. Sem sidecar, a consolidação noturna não processa.

2. **`git add inbox/{seu-slug}/` — nunca `-A` ou `.`.** Se você acidentalmente editar algo fora da sua estação (ex: lendo um arquivo e o editor salva), esses diffs ficam **locais**, nunca sobem.

3. **3 gatilhos — conteúdo que vai pra DIRETORIA, não aqui:**
   - **Dinheiro com nome próprio** — salário, comissão, bônus individual
   - **Pessoa específica** — avaliação, feedback sobre pessoa X, conflito
   - **Peso contratual sensível ou jurídico** — acordos de sócios, NDAs, M&A, litígio, escritório de advocacia/advisory
     - **Não é gatilho:** contratos operacionais (gateway de pagamento, hosting, SaaS recorrente, fornecedor padrão) — esses ficam aqui em `areas/operacoes/` (ou área correspondente).

   Se a captura dispara qualquer um desses, sinalize ao diretor. Não commita aqui.

Pergunte: _"Testa rápido — se você quisesse registrar 'a campanha de Dia das Mães bombou, ROAS 3x', vai em qual lugar?"_

(Resposta esperada: **este cérebro**, `inbox/{seu-slug}/` — não dispara gatilho.)

Depois:

_"E se fosse 'a Ana fechou o contrato com o cliente X por R$ 50k'?"_

(Resposta esperada: **cérebro da diretoria** — dispara gatilho 1 dinheiro+nome E gatilho 3 contratual.)

Se errar, explicar e pedir de novo. Insistir até entender.

### Passo 5 — Sidecar na prática

Mostrar um exemplo de sidecar:

```yaml
autor: {seu-slug}
data: 2026-04-20T14:32
fonte: conversa | captura-solo | pesquisa-web | screenshot | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
destino_sugerido: areas/marketing/contexto/...   # opcional
relacionado: []
tags: []
```

Explicar cada campo rapidamente:

- **tipo**: é captura solta (`nota`), draft em progresso (`draft`), ou proposta de edição em arquivo canônico existente (`proposta-canonica`)?
- **maturidade**: `cru` (ideia solta), `draft` (já está formado), `pronto-para-canonico` (pode ir pra `main` com destino claro)
- **destino_sugerido**: quando `maturidade: pronto-para-canonico` + destino → consolidação promove direto; quando `proposta-canonica` + destino → consolidação abre PR

Pergunte: _"Entendeu os níveis de maturidade?"_

### Passo 6 — Configurar a estação de trabalho (invoca `setup-workstation`)

Agora a parte operacional. Diga:

> _"Vou rodar a skill `setup-workstation` pra montar sua máquina local: layout `~/{{EMPRESA_SLUG}}/`, slash commands (`/cerebro`, `/sync-empresa`) e sua `inbox/{slug}/` no repo. Ela vai te perguntar alguns dados rápidos."_

Invoque `setup-workstation` e deixe ela conduzir. `setup-workstation` é a orquestradora — ela mesma chama `setup-estacao-pessoal` internamente no Passo 6 dela, então você **não precisa** invocar `setup-estacao-pessoal` direto aqui.

Ao fim, volte:

> _"Pronto — sua estação existe e suas slash commands estão prontas. Agora vamos praticar com uma captura de exemplo."_

> ⚠️ **Não chamar `setup-estacao-pessoal` direto.** Pular `setup-workstation` deixa o membro sem layout `~/{{EMPRESA_SLUG}}/` e sem slash commands (`/cerebro`, `/sync-empresa`) — UX quebrada.

### Passo 7 — Captura de prática

Peça ao humano uma ideia pequena que surgiu no dia (qualquer tema operacional do escopo dele, sem gatilhos).

Crie a captura COM ELE — arquivo + sidecar — explicando cada campo conforme preenche. Use `tipo: nota` e `maturidade: cru` pra essa primeira.

Commit + push em staging.

Depois, confirmar no remoto:

```bash
git log --oneline origin/staging | head -3
```

Ele vê o commit dele lá. Euforia.

### Passo 8 — Validação final

Faça 3 perguntas rápidas pra confirmar que entendeu:

1. _"Se você capturar uma ideia e marcar `maturidade: cru`, o que a consolidação noturna vai fazer?"_ (Esperado: manter no inbox)
2. _"Se você quiser **alterar** o `empresa/contexto/empresa.md`, o que faz?"_ (Esperado: criar proposta em `inbox/{slug}/` com `tipo: proposta-canonica` e `destino_sugerido: empresa/contexto/empresa.md`)
3. _"Seu amigo comentou no Slack que o Pedro não tá performando bem. Você capturar isso aqui?"_ (Esperado: **não** — gatilho 2 pessoa específica, pedir pro diretor registrar na diretoria)

Se errar: volte pro passo relevante e re-explique. Se acertar todas: _"Você tá operacional. Bom trabalho."_

Final:

> _"A partir de agora, sua sessão com o Claude/Cowork captura direto em `inbox/{seu-slug}/` — é só pedir: 'captura essa ideia'. O agente {{AGENTE_NOME}} processa tudo à noite."_

## Links úteis pra deixar com o humano

- [`README.md`](../../../README.md) — visão geral
- [`CLAUDE.md`](../../../CLAUDE.md) — instruções operacionais
- [`onboarding/GLOSSARIO.md`](../../../onboarding/GLOSSARIO.md) — termos
- [`empresa/contexto/PRINCIPIOS.md`](../../contexto/PRINCIPIOS.md) — regras duras
- [`empresa/skills/setup-estacao-pessoal/SKILL.md`](../setup-estacao-pessoal/SKILL.md) — detalhe da criação da estação

## Regras de segurança

- **Não sobrescrever estação existente.** Se o humano já tem `inbox/{slug}/`, pular o Passo 6 (ou rodar `setup-estacao-pessoal` em modo "recuperar").
- **Não assumir conteúdo operacional do humano.** As capturas de prática vêm **do humano**, não inventar.
- **Tempo estimado:** 15-25 min. Se o humano quer apressar, não pular os Passos 4 (regras duras) e 8 (validação).

## Recursos desta skill

Nenhum script. É conversa guiada.

---

*Tutorial + orquestração. Invoca `setup-estacao-pessoal` como sub-passo. Não duplica lógica.*
