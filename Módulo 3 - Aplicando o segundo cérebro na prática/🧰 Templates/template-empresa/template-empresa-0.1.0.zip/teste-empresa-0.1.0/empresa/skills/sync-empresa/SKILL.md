---
name: sync-empresa
description: >
  Empacota capturas pro cérebro da empresa em quiz item-a-item.
  Cobre 2 modos: (1) DIRETOR cross-brain — lê do cérebro pessoal `~/{empresa}/pessoal/`
  e empurra pra inbox/{slug}/ deste cérebro empresa em staging; (2) FUNCIONÁRIO
  local — lê inbox/{slug}/ local não-commitado e commita em staging. Detecta o modo
  pela presença de `~/{empresa}/pessoal/`. Sidecar `.meta.yaml` obrigatório.
  Default do quiz é "não distribuir". 3 gatilhos bloqueiam envio (vão pra diretoria).
---

# /sync-empresa — Cérebro da Empresa

> Empurra capturas pro cérebro empresa via quiz item-a-item. Substitui `/save` + `/team-sync` antigos. Cross-brain (diretor) e flush local (funcionário) numa skill só.

## 2 modos detectados automaticamente

| Modo | Quando | O que faz |
|---|---|---|
| **DIRETOR** (cross-brain) | `~/{{EMPRESA_SLUG}}/pessoal/` existe | Lê commits novos do pessoal → quiz → copia pra `inbox/{slug}/` deste empresa em staging |
| **FUNCIONÁRIO** (local) | Só `~/{{EMPRESA_SLUG}}/empresa/` existe | Lê `inbox/{slug}/` local não-commitado → quiz → commita em staging |

**Sempre manual e item-a-item.** Default: não distribuir.

## Quando usar

- Fim de expediente — diretor distribui o que produziu no pessoal que tem escopo-empresa
- Fim de expediente — funcionário publica capturas que acumulou em inbox local
- Quando você decidiu compartilhar algo específico imediatamente
- **Não usar** pra material puramente pessoal (fica só no pessoal)
- **Não usar** pra material que dispara os 3 gatilhos (dinheiro nominal, pessoa específica, peso jurídico) — esse vai pra `template-second-brain-diretoria` via `/sync-diretoria`

## Quando NÃO usar

Se você é **{{AGENTE_NOME}}** (gestor deste cérebro), **não use `/sync-empresa`**. Você commita direto em `staging` (writes canônicos do dia) e a rotina `consolidar-estacoes` cuida do merge pra `main`. `/sync-empresa` é fluxo de visitante (humanos do time + diretores cross-brain).

## Princípios

1. **Interativa, não proativa.** Skill faz quiz item-a-item das capturas que o aluno **apresenta** (modo diretor: lê commits novos do pessoal; modo funcionário: lê inbox local não-commitado). Skill NÃO escaneia menções da sessão pra perguntar "quer guardar URL X?" — esse comportamento proativo não existe aqui (alinhado com `/sync-pessoal`).
2. **Default conservador.** Quando dúvida, **não distribui**. Aluno confirma item-a-item. Default do quiz é "não distribuir" (`[2] Só pessoal` no modo diretor, `[N]` no modo funcionário).
3. **Detecta antes de escrever (P11).** Pré-checagem no Passo 0 confirma `inbox/{slug}/` existe, branch `staging` ativa, sidecar válido. Aborta com orientação clara se falhar.
4. **3 gatilhos bloqueiam.** Material sensível (dinheiro nominal, pessoa específica, peso jurídico) **não vai pra empresa**. Skill bloqueia e sugere `/sync-diretoria`.
5. **Read-only no pessoal** (modo diretor). Skill nunca edita ou deleta no cérebro pessoal — só lê.
6. **Sem triggers LN.** `/sync-empresa` exige invocação explícita pra evitar mandar pra repo errado. Linguagem natural só pra `/sync-pessoal`.

## Pré-requisitos & invariantes do ambiente

| Invariante | Como verificar | Se falhar |
|---|---|---|
| `~/.cowork/{{EMPRESA_SLUG}}-identity` existe com seu slug | `cat ~/.cowork/{{EMPRESA_SLUG}}-identity` | Rodar `setup-estacao-pessoal` antes |
| `inbox/{slug}/` existe em `origin/staging` | `git ls-tree origin/staging:inbox/$SLUG` | Rodar `setup-estacao-pessoal` antes |
| Branch ativa é `staging` | `git branch --show-current` = `staging` | `git checkout staging` (ou criar com `-b` se não existir) |
| **Modo diretor:** `~/{{EMPRESA_SLUG}}/pessoal/` é repo git válido | `test -d $PESSOAL/.git` | Tratar como modo funcionário (sem cross-brain) |
| Sidecar `.meta.yaml` segue schema | Validar 7 campos esperados | Skill gera sidecar default se ausente, mas pergunta se os campos críticos foram inferidos |
| Repo configurado como remote `origin` | `git remote -v` retorna `origin` | Orientar criar; não tenta push até resolver |
| Hook `.githooks/pre-commit` (se existir) aceita `PIXEL_BRAIN_COMMIT_OK=1` | Rodar tentativa | Aborta com mensagem; orientar configurar a env var |

## Ferramentas necessárias

- `Bash` — git log, copy, commit, push
- `Read` / `Write` — gerar sidecar
- (Modo diretor) Acesso de leitura ao cérebro pessoal

## Detecção de modo (passo 0)

```bash
SLUG=$(cat ~/.cowork/{{EMPRESA_SLUG}}-identity)
PIXEL="${PIXEL:-$(git rev-parse --show-toplevel)}"
PESSOAL="${PESSOAL:-$HOME/{{EMPRESA_SLUG}}/pessoal}"

test -d "$PIXEL/inbox/$SLUG" || { echo "inbox/$SLUG não existe — rode setup-estacao-pessoal"; exit 1; }

if [ -d "$PESSOAL/.git" ]; then
  MODO="diretor"
else
  MODO="funcionario"
fi
```

---

## MODO DIRETOR — fluxo 7 passos

### 1. Validar contexto

Já feito no passo 0. Confirmar `$PESSOAL` e `$PIXEL` apontam pra repos válidos.

### 2. Identificar capturas novas no pessoal (git log diff)

Lê `.team-sync-log` na raiz do cérebro pessoal pra pegar último commit sincronizado. Se não existe, considera "últimas 24h".

**Filtro crítico — só commits de trabalho deliberado.** Se o pessoal tem agente autônomo (ex: Amora) que commita a cada 30min (auto-sync, cases, wiki ingest), filtrar:

```bash
cd "$PESSOAL"
LAST_SYNCED=$(tail -1 .team-sync-log 2>/dev/null | awk '{print $2}')

if [ -n "$LAST_SYNCED" ]; then
  RANGE="$LAST_SYNCED..HEAD"
else
  RANGE="--since=1.day.ago"
fi

git log $RANGE \
  --invert-grep \
  --grep='^sync: amora auto-commit' \
  --grep='^cases:' \
  --grep='^wiki: ingest' \
  --grep='^docs: index' \
  --name-only --diff-filter=AM --format= -- '*.md' '*.html' \
  | sort -u | grep -v '^$'
```

Lista arquivos `.md`/`.html` criados/modificados em commits **deliberados** desde último sync. Filtra autônomos. Outros formatos ignorados (HTML/MD only).

### 3. Quiz item-a-item

Pra cada arquivo, mostrar resumo (3 primeiras linhas + path) e perguntar:

```
Arquivo: areas/conteudo/contexto/voz/linkedin.md
Resumo: "Diretrizes atualizadas para LinkedIn — gancho hyperspecífico..."

Onde esse conteúdo vai?
[1] Empresa (inbox/{slug}/)
[2] Só pessoal (não distribui)
[3] Diretoria (use /sync-diretoria depois)
[4] Ver conteúdo completo antes de decidir
```

Default: **[2] Só pessoal**. Sai do default só com confirmação explícita.

### 4. Aplicar regra dos 3 gatilhos

Se o conteúdo dispara qualquer:
- **Dinheiro com nome próprio** (salário, comissão, bônus individual)
- **Pessoa específica** (avaliação, feedback direto, conflito)
- **Peso contratual ou jurídico** (contratos, NDAs, litígios)

→ Bloquear envio pra empresa:

> *"Esse item dispara gatilho 2 (pessoa específica: 'Cayo'). Não posso mandar pra empresa. Pergunto de novo: [3] usa /sync-diretoria depois ou [2] só pessoal?"*

### 5. Copiar pro inbox + gerar sidecar

Pra cada item com destino "Empresa":

```bash
DEST="$PIXEL/inbox/$SLUG/$(date +%Y-%m-%d-%H%M)-$(basename $arquivo)"
cp "$PESSOAL/$arquivo" "$DEST"
```

Gerar `$DEST.meta.yaml` no schema do CLAUDE.md raiz:

```yaml
autor: {{slug-do-diretor}}
data: 2026-04-28T18:32
fonte: sync-empresa
tipo: nota                      # default — diretor pode marcar via quiz opcional
maturidade: draft               # default — consolidação decide promoção
destino_sugerido: null          # opcional, diretor sugere via quiz
relacionado:
  - pessoal:areas/conteudo/contexto/voz/linkedin.md
tags: [sync-empresa, conteudo]
```

### 6. Quiz opcional de destino canônico

Por item, pergunta rápida (Enter pra pular):

> *"Sugerir destino canônico? (ex: `areas/marketing/contexto/voz/linkedin.md`) ou deixa a consolidação decidir? [Enter]"*

Se sugerir, preenche `destino_sugerido` no sidecar.

### 7. Commit + push em staging

```bash
cd "$PIXEL"
git fetch origin
git checkout staging
git pull --rebase origin staging
PIXEL_BRAIN_COMMIT_OK=1 git add "inbox/$SLUG/"
PIXEL_BRAIN_COMMIT_OK=1 git commit -m "sync-empresa: $SLUG ({N} capturas)"
git push origin staging
```

**`git add` só de `inbox/$SLUG/`** — nunca `git add -A` ou `git add .`.

A env var `PIXEL_BRAIN_COMMIT_OK=1` é exigida pelo `.githooks/pre-commit` (se configurado) — só skills humanas com gate explícito conseguem commitar.

### 8. Atualizar `.team-sync-log` no pessoal

```bash
cd "$PESSOAL"
echo "$(date -Iseconds) $(git rev-parse HEAD)" >> .team-sync-log
git add .team-sync-log
git commit -m "sync-empresa: marca ultimo sync ($(date +%Y-%m-%d))"
git push origin main
```

Próximo `/sync-empresa` lê esse log pra pegar só capturas novas.

---

## MODO FUNCIONÁRIO — fluxo 6 passos

### 1. Listar capturas locais não commitadas

Funcionário cria capturas em `inbox/{slug}/` durante o dia (via Claude Code editando direto em filesystem) e commita via `/sync-empresa` no fim.

```bash
cd "$PIXEL"
git status --short "inbox/$SLUG/"
```

Lista arquivos `A` (novos), `M` (modificados), `??` (untracked) em `inbox/$SLUG/`.

### 2. Quiz item-a-item

Pra cada arquivo:

```
Arquivo: inbox/{slug}/2026-04-21-1432-ideia-campanha-maes.md
Resumo: ideia de campanha pro Dia das Mães — tom emocional, ROI esperado 2.5x.

Sidecar indica:
- tipo: draft
- maturidade: draft
- destino_sugerido: areas/marketing/contexto/campanhas.md

Subir pro staging? [s/N/editar/deletar]
```

Default: **N**. Se não confirmar, fica só local.

### 3. Aplicar regra dos 3 gatilhos

Se o conteúdo parece disparar qualquer dos 3 gatilhos:

> *"⚠️ Essa captura parece disparar gatilho [X]. Ela deveria ir pro cérebro da diretoria, não da empresa. [Deletar daqui / Manter local / Mover manualmente pro repo da diretoria via /sync-diretoria]"*

### 4. Sidecar obrigatório

Pra cada arquivo que vai subir, garantir `.meta.yaml` irmão. Se não tem:

> *"Arquivo `X.md` não tem sidecar. Quero criar um pra você?"*

Preenche com defaults (`tipo: nota`, `maturidade: cru`, etc.) ou pergunta.

### 5. Commit + push em staging

```bash
cd "$PIXEL"
git fetch origin
git checkout staging
git pull --rebase origin staging

# adiciona só os confirmados, paths explícitos — NUNCA `git add .` ou `-A`
for arquivo in $confirmados; do
  PIXEL_BRAIN_COMMIT_OK=1 git add "$arquivo" "${arquivo}.meta.yaml" 2>/dev/null
done

PIXEL_BRAIN_COMMIT_OK=1 git commit -m "sync-empresa: $SLUG ({N} capturas)"
git pull --rebase origin staging
git push origin staging
```

Commit vai em staging. A consolidação noturna decide o destino final (promover a main ou abrir PR).

### 6. Confirmação

> *"✅ sync-empresa completo._
> _- {N} capturas publicadas em staging_
> _- {M} capturas mantidas local (não confirmadas)_
> _- Consolidação noturna processa hoje a partir das 02:00 BRT"*

---

## Confirmação final (qualquer modo)

```
✅ sync-empresa completo

  Modo: {diretor | funcionário}
  → {N} capturas enviadas pra empresa (inbox/{slug}/ em staging)
  → {M} capturas mantidas só pessoal/local (não distribuídas)
  → {K} capturas bloqueadas por gatilho (use /sync-diretoria)

  Próxima consolidação: ~02:00 BRT pelo {{AGENTE_NOME}}.
```

## Regras duras

- **Só `.md` e `.html` são copiados.** Outros formatos viram URL em MD.
- **3 gatilhos bloqueiam empresa.** Material sensível só vai pra diretoria via `/sync-diretoria`.
- **Default do quiz é "não distribuir".** Sem confirmação explícita, nada é distribuído.
- **Sidecar obrigatório.** Toda captura tem `.meta.yaml`.
- **Commit exige `PIXEL_BRAIN_COMMIT_OK=1`** (se hook configurado). Bloqueia commit autônomo.
- **`git add` com paths explícitos** — nunca `.` ou `-A`.
- **`.team-sync-log` é append-only** (modo diretor). Nunca reescrever histórico.
- **Read-only no cérebro pessoal** (modo diretor). Skill nunca edita ou deleta lá — só lê.
- **Sem triggers em linguagem natural** — `/sync-empresa` exige invocação explícita pra evitar mandar pra repo errado.

## Variações conhecidas

| Cenário | Como o agente adapta |
|---|---|
| Funcionário sem cérebro pessoal | Modo local. Skill lê `inbox/{slug}/` não-commitado, faz quiz, commita em staging. |
| Diretor com cérebro pessoal lado a lado | Modo cross-brain. Lê `git log` do pessoal desde último sync, copia capturas pra `inbox/{slug}/`. |
| `.team-sync-log` não existe (1ª vez) | Default: capturas das últimas 24h. Cria o arquivo após primeiro sync. |
| Pessoal tem agente autônomo (Amora-style) gerando muitos commits | Filtrar por padrões hardcoded (`amora auto-commit`, `cases:`, `wiki: ingest`); só commits deliberados entram no quiz |
| Captura tem screenshot/imagem | Skill **não copia binário**. Pergunta: "salvar URL externa? texto descritivo? ignorar?" |
| Captura grande (>500 linhas) | Mostra primeiras 30 linhas no quiz; oferece [4] "ver completo" antes de decidir |
| `template-second-brain-diretoria` não clonado lado a lado | Opção [3] "Diretoria" no quiz mostra aviso: _"diretoria não disponível — escolha [2] ou mova manual depois"_ |
| Sem internet | Commit local funciona; `git push` falha. Capturas ficam pendentes; próximo `/sync-empresa` empurra |
| Conflito em `staging` (outra máquina pushou) | `git pull --rebase`, resolver, retry. Nunca `--force`. |
| Captura `.md` que é PDF disfarçado (raro) | Sidecar marca `tipo: referencia`; consolidação decide |
| Modo ambíguo (pessoal existe mas vazio) | Tratar como funcionário; cross-brain exige `git log` válido |
| Aluno tenta `/sync-empresa` sem ter rodado `setup-estacao-pessoal` | Aborta com mensagem clara; sugere rodar setup primeiro |

## Quando algo não funciona

| Sintoma | Causa provável | O agente deve |
|---|---|---|
| `inbox/$SLUG não existe` | `setup-estacao-pessoal` não rodou ainda | Oferecer rodar agora |
| `acesso negado — slug não na allowlist` | Identity diferente do permitido (não aplica aqui — esse erro é de `/sync-diretoria`) | Verificar `.cowork/{empresa}-identity` |
| `error: src refspec staging does not match any` | Branch local não é staging ou remote sem branch | `git checkout -b staging && git push -u origin staging` |
| `Permission denied (publickey)` | SSH key não configurada | Orientar `gh auth login` ou setup SSH |
| `non-fast-forward` no push | Outra máquina pushou | `git pull --rebase`, retry |
| Hook pre-commit bloqueia commit | Falta `PIXEL_BRAIN_COMMIT_OK=1` no env | Set env var na invocação ou orientar configurar |
| Sidecar `.meta.yaml` faltando | Aluno não criou ao salvar inbox | Skill oferece criar com defaults; pergunta `tipo` e `maturidade` |
| Quiz aceita default e nada distribui | Comportamento esperado (default é "não distribuir") | Confirmar com aluno: _"3 capturas mantidas só local. OK assim ou quer subir alguma específica?"_ |
| Captura dispara 3 gatilhos detectado pela skill | Material sensível tentando ir pra empresa | Bloquear; sugerir `/sync-diretoria` |
| `git log` no pessoal vazio (modo diretor) | Cérebro pessoal não tem commits novos desde último sync | Mensagem: _"Nada novo no pessoal pra distribuir. Você fez `/sync-pessoal` recentemente?"_ |
| Múltiplos sócios usam mesmo slug por engano | Configuração quebrada em `setup-estacao-pessoal` | Detectar via `.cowork/identity` vs commits anteriores; abortar e orientar correção |

## Adaptando pra realidade do usuário

Se a skill não couber direito, leia esta seção e converse antes de forçar:

- **Funcionário em empresa pequena (3-5 pessoas)** — talvez não exista distinção time/diretoria. Skill ainda funciona, mas oferecer 1x: "vc pode pular `inbox/` e escrever direto em canônico via PR — fala com Cayo se quiser esse workflow."
- **Diretor que prefere fluxo manual sem quiz** — respeitar. Skill aceita `--no-quiz` (TODO se não existir): copia tudo direto, ele revisa via `git diff` antes do commit. Trade-off: perde gate dos 3 gatilhos.
- **Aluno do mini-curso (sem time)** — `/sync-empresa` não se aplica. Mensagem: "vc não tem cérebro empresa clonado. Quando criar a empresa, clona o template-second-brain-empresa."
- **Cliente Pixel com OpenClaw VPS** — agente OpenClaw (Léo, Atlas, etc.) **não roda `/sync-empresa`**. Cross-brain é só Claude Code laptop. Se aluno perguntar como fazer pelo Telegram, explicar e redirecionar pra Claude Code.
- **Aluno com captura grande** (>1000 linhas) — agente sugere fragmentar antes de subir; ou subir como referência (1 arquivo síntese + URL pro pessoal onde tem o conteúdo completo).
- **Conflito político** ("não quero subir isso") — sempre default conservador. Manter local. Não pressionar nem perguntar 2x.

## Interação com outras skills

| Skill | Relação |
|---|---|
| `setup-estacao-pessoal` | Pré-requisito. Estação tem que existir antes. |
| `consolidar-estacoes` | Consumidora. Toda captura gerada vira input da consolidação noturna. |
| `/sync-pessoal` (template-pessoal) | Skill irmã no cérebro pessoal — flush local lá. Esta empurra do pessoal pro empresa. |
| `/sync-diretoria` (template-diretoria) | Skill irmã pra material sensível. Vive no repo da diretoria. |
| `/cerebro` | Pré-requisito multi-brain. Carrega CLAUDE.md dos 3 cérebros. |

## Notas

- **Substitui:** `/save` (filesystem-only) + `/team-sync` (publish git) antigos. A separação save→team-sync deixou de existir; a única skill `/sync-empresa` faz o quiz e o commit no mesmo passo.
- **Triggers em linguagem natural:** **NÃO**. Decisão Bruno 02/05 — só `/sync-pessoal` aceita LN. Cross-brain (`/sync-empresa`, `/sync-diretoria`) exige invocação explícita pra evitar mandar pra repo errado.
- **Modo automático futuro** (OpenClaw + Telegram inline keyboard): rejeitado por Cayo no review 23/04 (item #3). OpenClaw não roda `sync-*` — fica só em sessão Claude Code.
- **Override de paths:** `PESSOAL=/path/customizado` ou `PIXEL=/path/customizado` via env var.
