---
name: setup-estacao-pessoal
description: >
  Configura a estação pessoal de trabalho de uma pessoa no Pixel Second Brain.
  Ativar no primeiro uso do Claude Code / Cowork na raiz do repositório, quando
  ainda não existe inbox/{nome}/ para a pessoa.
  Palavras-chave: primeira vez, setup, estação pessoal, onboarding, inbox pessoal.
---

# setup-estacao-pessoal

## O que faz

Cria a estação pessoal de uma pessoa dentro do Pixel Second Brain. Gera a pasta `inbox/{nome}/` com `CLAUDE.md` e `README.md` personalizados, deixa `privado/` pronta, e faz o primeiro commit na branch `staging`.

## Quando usar

Três situações:

1. **Primeira vez no repositório (sem identidade local).** `~/.cowork/{{EMPRESA_SLUG}}-identity` não existe. Perguntar, criar, salvar, pushar.
2. **Identidade local existe mas pasta remota não.** Ex: pessoa clonou o repo numa máquina nova, ou a pasta foi removida por acidente. Modo "recuperar": recria `inbox/{slug}/` a partir de `_TEMPLATE/` usando a identidade já salva, sem perguntar de novo.
3. **Adicionar nova pessoa ao time.** Rodar manualmente pra configurar a estação de um novo membro.

## Como saber se é a primeira vez (fonte de verdade)

A "fonte de verdade" de que a pessoa já fez o setup é **a combinação** de dois sinais:

| Sinal | Onde mora | O que significa |
|---|---|---|
| `~/.cowork/{{EMPRESA_SLUG}}-identity` | Arquivo local na máquina do usuário, fora do repo | "Esta máquina já foi configurada — o slug é X" |
| `inbox/{slug}/` | Pasta no repo, em `origin/staging` | "Esta pessoa tem estação no repo da Pixel" |

Matriz de decisão:

- **ambos existem** → já está configurado, seguir sessão normal
- **só arquivo local existe** → pasta foi perdida no remoto (raro); rodar modo "recuperar"
- **só pasta remota existe** → máquina nova; pular pergunta de identidade (descobrir slug perguntando ao usuário curtinho: "você é o X?"), salvar arquivo local, continuar
- **nenhum existe** → primeira vez de verdade; fluxo completo

Nunca confiar só na pasta remota: em Cowork, mesmo usuário pode ter várias máquinas, e cada máquina precisa do arquivo local pra saber qual estação é dela sem perguntar todo dia.

## Ferramentas necessárias

- `Bash` — criar pastas, rodar git
- `Read` / `Write` — ler templates e escrever arquivos personalizados

## Passo a passo

### 1. Detectar se já existe estação para a pessoa

```bash
ls inbox/ | grep -v _TEMPLATE
```

Se já existe `inbox/{nome}/` para essa pessoa, parar aqui e seguir pra sessão normal.

### 2. Coletar identidade (pergunta ao usuário)

Perguntar diretamente, em sequência. Os campos cobrem os 5 placeholders do `inbox/_TEMPLATE/CLAUDE.md` (`{nome}`, `{email}`, `{area}`, `{papel}`, `{projetos}`) + `{preferencias livres}`:

1. **Nome curto / slug** (obrigatório):
   > "Primeira vez aqui — como você quer ser identificado? (nome curto, lowercase, sem acento — ex: `joao`, `ana`, `marina`)"
   → vai pra `{nome}`

2. **Email** (opcional):
   > "Qual seu email operacional? (ENTER pra deixar em branco — fica `nao-informado`)"
   → vai pra `{email}`

3. **Papel** (obrigatório):
   > "Qual seu papel na {{EMPRESA}}? (ex: 'Performance Marketing', 'Atendimento Sênior', 'Engenheiro de Plataforma')"
   → vai pra `{papel}`

4. **Área primária** (inferida do papel, mas confirmar):
   > "Sua área primária é {area-inferida-do-papel}? (marketing/vendas/atendimento/operacoes/produto — corrija se eu errei)"
   → vai pra `{area}`

5. **Projetos ativos** (obrigatório, livre):
   > "Em quais projetos você está ativo hoje? (1-3 nomes — separa por vírgula)"
   → vai pra `{projetos}`

6. **Preferências de captura** (3 sub-perguntas guiadas):
   > "Pra a sua estação capturar do seu jeito, 3 perguntas rápidas:"
   > "  a) Formato de notas preferido? (bullet points / texto corrido / mistura)"
   > "  b) Idioma default? (pt-BR / en / outros)"
   > "  c) Nível de detalhe? (curto / médio / longo)"
   → concatena num bloco e vai pra `{preferencias livres}`

Guardar todas as respostas.

### 3. Criar a estrutura

```bash
NOME="<slug da pessoa>"
mkdir -p "inbox/${NOME}/privado"
```

### 4. Gerar `inbox/{nome}/CLAUDE.md` a partir do template

Ler `inbox/_TEMPLATE/CLAUDE.md` e substituir cada placeholder com a resposta da etapa 2:

- `{nome}` → slug escolhido (campo 1)
- `{email}` → email do usuário (campo 2 — usar `nao-informado` se vazio)
- `{papel}` → papel (campo 3)
- `{area}` → área primária confirmada (campo 4)
- `{projetos}` → projetos ativos (campo 5)
- `{preferencias livres: ...}` → bloco concatenado das 3 sub-respostas (campo 6)

Escrever em `inbox/${NOME}/CLAUDE.md`. Sem placeholder remanescente — verificar com `grep -nE '\{[a-z]' inbox/${NOME}/CLAUDE.md` antes de seguir.

### 5. Gerar `inbox/{nome}/README.md` a partir do template

Ler `inbox/_TEMPLATE/README.md` e substituir `{nome}` pelo slug. Escrever em `inbox/${NOME}/README.md`.

### 6. Garantir branch `staging`

```bash
git fetch origin
git checkout staging 2>/dev/null || git checkout -b staging origin/staging
git pull --rebase origin staging
```

Se `staging` não existe no remoto, criar a partir de `main`:

```bash
git checkout -b staging main
git push -u origin staging
```

### 7. Primeiro commit da estação

```bash
git add "inbox/${NOME}/"
git commit -m "setup: estação pessoal de ${NOME}"
git pull --rebase origin staging
git push origin staging
```

Note: `inbox/${NOME}/privado/` está no `.gitignore` da raiz, então não vai pro servidor — correto.

### 8. Registrar identidade local

Salvar em `~/.cowork/{{EMPRESA_SLUG}}-identity` (arquivo local, fora do repo) o slug da pessoa. Nas próximas sessões, o Claude lê esse arquivo e já sabe qual estação é a da pessoa, sem perguntar de novo.

```bash
mkdir -p ~/.cowork
echo "${NOME}" > ~/.cowork/{{EMPRESA_SLUG}}-identity
```

### 9. Confirmação

Responder ao usuário com resumo curto:

- Estação criada em `inbox/{nome}/`
- Push feito em `staging`
- Identidade salva localmente
- "Tudo que você capturar nesta e nas próximas sessões vai pra sua estação (conteúdo `.{ext}` + sidecar `.meta.yaml` ao lado) e sobe pra staging em tempo real. O {{AGENTE_NOME}} consolida de madrugada."

## Output esperado

```
✓ Estação pessoal criada: inbox/{{SEU_SLUG}}/
✓ CLAUDE.md e README.md personalizados
✓ Branch staging sincronizada
✓ Primeiro commit enviado: "setup: estação pessoal de {{SEU_SLUG}}"
✓ Identidade salva em ~/.cowork/{{EMPRESA_SLUG}}-identity
```

## Notas

- Slug da pessoa é case-sensitive no path mas sempre lowercase por convenção.
- Se o usuário já tem slug configurado em `~/.cowork/{{EMPRESA_SLUG}}-identity` mas a pasta `inbox/{slug}/` não existe no repo, é possível que ele esteja trabalhando num clone novo — nesse caso, só fazer `git pull` resolve. Só rodar setup completo se realmente não existe a pasta nem no remoto.
- Esta skill **não** é idempotente para a etapa de perguntas — se já existe estação, sair cedo em vez de sobrescrever identidade.
