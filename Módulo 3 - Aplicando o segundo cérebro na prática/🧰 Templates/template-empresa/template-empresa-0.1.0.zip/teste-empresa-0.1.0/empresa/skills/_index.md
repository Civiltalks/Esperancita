# Skills da Empresa — Índice

> Skills globais: qualquer área pode usar. Vivem em `empresa/skills/`.

## Ordem de uso após clonar o template

1. **`inicializar-cerebro`** — primeiro uso (preenche placeholders, renomeia pasta do agente, trava reexecução). Tutorial + configurador.
2. **`setup-estacao-pessoal`** — você (primeira pessoa) cria sua `inbox/{slug}/`.
3. **`setup-agente-openclaw`** — sobe o agente gestor em VPS 24/7 (modo NOVO ou MERGE se VPS já tem OpenClaw rodando).
4. [Time cresce] cada novo membro roda **`onboarding-membro-time`** (wizard completo: modelo + estação + prática + validação).
5. [Empresa amadurece] clona `template-second-brain-diretoria` como repo separado e inicializa.

## Skills essenciais (vêm com o template)

| Skill | Quando usar |
|-------|-------------|
| `inicializar-cerebro` | **Primeiro uso** após clone do template. Tutorial + preenche placeholders em todo o repo + renomeia `agentes/geral-empresa/` pro slug do seu agente + cria `.cerebro-inicializado`. Roda **UMA VEZ**. |
| `onboarding-membro-time` | Wizard guiado pra **novo membro do time chegando pela primeira vez**. Ensina modelo (2 cérebros, estação, staging, sidecar, 3 gatilhos), invoca `setup-estacao-pessoal`, faz captura de prática e valida com 3 perguntas. ~20 min. Use em: nova contratação, pessoa voltando de afastamento, migração de Notion. |
| `setup-estacao-pessoal` | Skill **atômica** que cria `inbox/{nome}/` com CLAUDE.md próprio, salva identidade local, commita em staging. Sem parte pedagógica — use direto se a pessoa já sabe o modelo. |
| `setup-workstation` | Configura o layout LOCAL `~/{{EMPRESA_SLUG}}/` da pessoa — organiza repos (time/diretoria/pessoal) lado a lado + symlinks pra `/cerebro`, `/sync-empresa` etc. em `~/{{EMPRESA_SLUG}}/.claude/skills/`. Interativa. Camada de **máquina local**, acima do escopo-repo das demais. |
| `cerebro` | Carrega em paralelo os `CLAUDE.md` dos cérebros presentes em `~/{{EMPRESA_SLUG}}/`. Instalada como slash command `/cerebro` por `setup-workstation`. **Universal** (todo membro do time e diretor clona este repo, então todo mundo recebe). Resolve a limitação do Claude Code que só auto-lê `CLAUDE.md` do cwd e pastas pai. |
| `setup-agente-openclaw` | Em VPS dedicado. Modo NOVO (do zero) ou MERGE (adapta um OpenClaw existente). Instala crons de sync (staging) e consolidação noturna (main). |
| `sync-empresa` | Empacota e empurra capturas pra `inbox/{seu-slug}/` em staging via quiz item-a-item. Cobre 2 modos: (1) **diretor** cross-brain (lê `~/{{EMPRESA_SLUG}}/pessoal/` e copia pra empresa); (2) **funcionário** local (lê inbox local não-commitado). Detecta o modo automaticamente. Substitui `/save` + `/team-sync` antigos. Sem triggers em linguagem natural — invocação explícita pra evitar mandar pra repo errado. |
| `consolidar-estacoes` | Rotina noturna 02:00 BRT. Processa `inbox/*/` (humanos + canal diplomático do agente da diretoria + agentes pessoais de diretor), promove `pronto-para-canonico` direto pra main, abre PR pra `proposta-canonica`, arquiva processado. |

## Skills por área

| Área | Índice |
|------|--------|
| Marketing | [areas/marketing/skills/_index.md](../../areas/marketing/skills/_index.md) |
| Vendas | [areas/vendas/skills/_index.md](../../areas/vendas/skills/_index.md) |
| Atendimento | [areas/atendimento/skills/_index.md](../../areas/atendimento/skills/_index.md) |
| Operações | [areas/operacoes/skills/_index.md](../../areas/operacoes/skills/_index.md) |
| Produto | [areas/produto/skills/_index.md](../../areas/produto/skills/_index.md) |

## Templates

`_templates/SKILL-TEMPLATE.md` — base pra criar novas skills.

---

*Adicione suas próprias skills em `empresa/skills/{nome}/SKILL.md`.*
