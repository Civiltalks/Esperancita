# MAPA — empresa/

Pasta transversal. Contém contexto institucional, princípios, skills gerais.

## Conteúdo

- `contexto/PRINCIPIOS.md` — regra dos 3 gatilhos, privacidade, sidecar
- `contexto/ARQUITETURA.md` — modelo dos 2 cérebros disjuntos
- `contexto/SEGURANCA.md` — o que nunca commitar, segurança básica
- `contexto/FLUXO-CAPTURA.md` — fluxo canônico do visitante (`/sync-empresa`, modo diretor ou funcionário)
- `contexto/CROSS-AREA.md` — política quando conteúdo toca 2+ áreas
- `skills/` — skills transversais (ver `skills/_index.md`)

## Arquivos sugeridos que você pode adicionar

- `contexto/empresa.md` — o que sua empresa faz (público)
- `contexto/brand.md` — identidade visual resumida
- `contexto/products.md` — produtos e escada de valor
- `contexto/posicionamento.md` — posicionamento

## O que **não** fica aqui

Conteúdo que dispara a regra dos 3 gatilhos (dinheiro nominal, pessoa específica, peso contratual/jurídico) vive no cérebro da diretoria (repo separado clonado do `template-second-brain-diretoria`).
