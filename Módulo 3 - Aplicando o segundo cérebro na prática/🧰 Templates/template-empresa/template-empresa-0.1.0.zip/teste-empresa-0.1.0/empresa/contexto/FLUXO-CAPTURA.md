# Fluxo canônico de captura — visitante

> Fonte única de verdade. Onboarding, `inbox/CLAUDE.md` e `inbox/_TEMPLATE/CLAUDE.md` apontam pra cá.

## Quem é "visitante"

Membros do time, agentes pessoais de diretores, e o Claude Code/Cowork em sessão de humano. Todo mundo que **não** é o agente gestor (`{{AGENTE_NOME}}`) deste cérebro.

Visitante captura **sempre** em `inbox/{seu-slug}/` — nunca direto em `empresa/`, `areas/`, ou `agentes/`.

## Fluxo canônico — `/sync-empresa`

Skill única que cobre 2 modos detectados automaticamente:

| Modo | Quando | O que faz |
|---|---|---|
| **DIRETOR** (cross-brain) | `~/{{EMPRESA_SLUG}}/pessoal/` existe | Lê commits novos do cérebro pessoal → quiz → copia pra `inbox/{slug}/` deste empresa em staging |
| **FUNCIONÁRIO** (local) | Só `~/{{EMPRESA_SLUG}}/empresa/` existe | Lê `inbox/{slug}/` local não-commitado → quiz → commita em staging |

**Sempre manual e item-a-item.** Default: não distribuir.

### Modo DIRETOR

Diretor trabalha no cérebro pessoal (`~/{{EMPRESA_SLUG}}/pessoal/`) durante o dia, salva via `/sync-pessoal` (skill que vive no template pessoal). No fim do expediente, roda `/sync-empresa` pra empurrar o que tem escopo-empresa pra inbox da empresa em staging.

### Modo FUNCIONÁRIO

Funcionário trabalha direto no cérebro empresa, criando capturas em `inbox/{slug}/` local. No fim do expediente, roda `/sync-empresa` pra revisar item-a-item e commitar em staging. Sem cérebro pessoal separado.

A consolidação noturna do `{{AGENTE_NOME}}` processa a partir do `staging`.

## Anti-padrão — push direto

> ⚠️ **Push direto (`git add inbox/{slug}/ && git commit && git push origin staging`) é anti-padrão.**

Razões:
1. Sem revisão item-a-item — sobe ruído junto com sinal
2. Sem check automático dos 3 gatilhos — risco de vazar conteúdo de diretoria
3. Sem garantia de sidecar — consolidação noturna não promove
4. Audit trail mais pobre (commits granulares por arquivo vs. um commit consolidado por sessão)

Use `/sync-empresa`. Sempre.

## Regras duras (válidas em qualquer fluxo)

1. **Só commitar em `inbox/{seu-slug}/`** — nunca fora.
2. **Nunca `git add .` ou `git add -A`** — sempre pathspec específico do seu inbox.
3. **Branch: `staging`.** `main` só muda via consolidação noturna.
4. **Sidecar `.meta.yaml` obrigatório** pra toda captura.
5. **Privacidade default: público ao time.** Opt-in pra `privado/` só quando pedido ou inequivocamente sensível.
6. **Conteúdo que dispara os 3 gatilhos** não fica aqui — usar `/sync-diretoria` (skill que vive em `template-second-brain-diretoria`).

## Skills relacionadas

- [`empresa/skills/sync-empresa/SKILL.md`](../skills/sync-empresa/SKILL.md) — empacota e empurra (substitui `/save` + `/team-sync` antigos)
- [`empresa/skills/consolidar-estacoes/SKILL.md`](../skills/consolidar-estacoes/SKILL.md) — rotina noturna do `{{AGENTE_NOME}}`
- [`empresa/skills/setup-estacao-pessoal/SKILL.md`](../skills/setup-estacao-pessoal/SKILL.md) — cria sua `inbox/{slug}/`
- `/sync-pessoal` (vive em `template-second-brain-pessoal`) — flush local no cérebro pessoal
- `/sync-diretoria` (vive em `template-second-brain-diretoria`) — material sensível → diretoria
