# Princípios do cérebro

## 1. Fonte única de verdade

O repositório é o cérebro canônico. Tudo que está fora dele (Slack, Notion, email) é tráfego. O que importa precisa chegar aqui.

## 2. Inbox é triagem, não memória

`inbox/{nome}/` é staging pessoal. Qualquer coisa aqui é provisória até a rotina noturna decidir se promove, revisa ou arquiva.

## 3. Sidecar `.meta.yaml` é obrigatório

Toda captura vem com um sidecar `foo.ext.meta.yaml` irmão, mesmo nome base.
Sem sidecar → não é promovida.

Schema:

```yaml
autor: {nome}
data: 2026-04-20T02:00
fonte: conversa | pesquisa | captura-solo | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
destino_sugerido: areas/marketing/contexto/...
relacionado: []
tags: []
```

## 4. Privacidade é opt-in

Default: tudo é **público ao time**. Só vai pra `inbox/{nome}/privado/` (gitignored) quando o humano explicita ou o conteúdo é inequivocamente sensível.

## 5. A regra dos 3 gatilhos

Um conteúdo pertence ao **cérebro da diretoria** (repo separado, clonado do `template-second-brain-diretoria`) se dispara qualquer um destes 3:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual.
2. **Pessoa específica** — avaliação, feedback direto, conflito.
3. **Peso contratual sensível ou jurídico** — acordos de sócios, NDAs, M&A, litígio, escritório de advocacia/advisory.
   - **Não é gatilho:** contratos operacionais (gateway de pagamento, hosting, SaaS recorrente, fornecedor padrão) — esses ficam aqui em `areas/operacoes/` (ou área correspondente do cérebro do time, se aplicável).

Se não dispara nenhum → fica neste repo (cérebro do time).

## 6. Agente escreve em inbox; humano aprova canônico

Durante sessão, o agente só commita em `inbox/{nome}/`. Qualquer mudança em canônico vai como **proposta** (`tipo: proposta-canonica` no sidecar), e a consolidação noturna abre PR.

---

_Nota para este template (cérebro do time):_
Este é o cérebro operacional do time. Use-o sem receio pro dia a dia.
Quando sua empresa precisar lidar com dados que disparam a regra dos 3 gatilhos, clone o `template-second-brain-diretoria` como repo separado.
