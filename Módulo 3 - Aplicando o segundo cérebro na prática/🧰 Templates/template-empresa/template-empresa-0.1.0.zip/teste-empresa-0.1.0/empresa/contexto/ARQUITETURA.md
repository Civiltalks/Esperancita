# Arquitetura dos cérebros

## Dois repos disjuntos

Sua empresa pode operar com dois repositórios complementares:

1. **Este** (cérebro do time) — operacional: marketing, vendas, atendimento, operações, produto.
2. **Cérebro da diretoria** (repo separado, clonado do `template-second-brain-diretoria`) — sensível: financeiro, RH, jurídico, governança.

Formalmente:

```
C(time) ∩ C(diretoria) = ∅
C(time) ∪ C(diretoria) = conhecimento total da empresa
```

Nenhum conhecimento aparece nos dois. O que um não tem, o outro tem.

## Visão por papel

- Time (operacional) → vê C(time)
- Diretores → vê C(time) ∪ C(diretoria) = tudo

## Eixos ortogonais

- **Domínio** (marketing, vendas, RH, jurídico, ...) = pasta em um dos dois repos
- **Sensibilidade** = qual repo o dado mora em

O mesmo domínio pode atravessar os dois. Exemplo: "vendas agregadas do mês" → cérebro do time; "comissão da Ana em abril" → cérebro da diretoria. A atribuição vem da **sensibilidade do dado**, não do rótulo da pasta.

## Agentes

- **Agente do time** (este repo) — tom pragmático, proativo. Todo mundo do time conversa com ele.
- **Agente da diretoria** (outro repo) — tom prudente, revisão humana obrigatória. Só sócios.

Agentes **não compartilham contexto**. Diretor (humano) é a ponte entre os dois.

## Fluxo de decisão ao capturar

1. Tem dinheiro com nome próprio? → diretoria
2. Tem pessoa específica? → diretoria
3. Tem peso contratual/jurídico? → diretoria
4. Nada disso? → time (este repo)

## Quando nasce o segundo cérebro

O cérebro do time (este) vem primeiro. O cérebro da diretoria nasce quando aparecer:

- Primeira contratação formal com CLT/PJ
- Primeiro contrato com distribuição de receita / equity / NDAs
- Primeira decisão que envolve remuneração variável individual
- Primeira situação de RH que requer registro (avaliação, conflito)

Antes disso, este repo basta.

## Por que dois repos, não um só com filtro

Um cérebro só com filtros de permissão é frágil:
- LLM erra na classificação e expõe sensível.
- GitHub só tem permissão por repo, não por pasta ou arquivo.
- Rotinas automatizadas podem vazar conteúdo filtrado em logs, backups ou MCPs mal configurados.

Dois repos disjuntos dão **garantia estrutural** em vez de depender de lógica de runtime.
