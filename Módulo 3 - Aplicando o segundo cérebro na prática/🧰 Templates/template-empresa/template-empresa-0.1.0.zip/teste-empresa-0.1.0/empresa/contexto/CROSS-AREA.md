# Política cross-área — quando o conteúdo toca 2+ áreas

> Quando uma captura, projeto ou contexto envolve duas ou mais áreas (ex: redesign da home toca marketing+produto), precisa de regra clara pra não duplicar nem perder pelas frestas.

## Princípio

**Toda informação tem uma fonte canônica.** O resto referencia. Duplicação é sintoma de área mal escolhida.

## Como decidir a fonte canônica

Pergunte, em ordem:

1. **Quem é o owner operacional?** A área que executa/decide é a fonte. Outras só referenciam.
   - *Ex:* "redesign da home" — quem implementa é produto. Marketing usa, mas produto é dono.

2. **Onde a informação muda primeiro?** Se a área X aprende algo antes da área Y, a fonte é X.
   - *Ex:* "case do cliente Acme" — começa em atendimento (suporte abriu o ticket). Marketing usa pro material, mas atendimento é fonte canônica.

3. **Empate?** Suba pra `empresa/contexto/`. Cross-área genuíno (afeta a empresa, não uma área específica) vive lá.
   - *Ex:* "valores da empresa", "tom de marca" — não pertencem a uma área só.

## Como referenciar de outra área

Crie um arquivo curto na área secundária com link relativo pro canônico:

```markdown
# Redesign da home (referência cross-área)

Owner: areas/produto/.

Veja [`areas/produto/contexto/redesign-home.md`](../../produto/contexto/redesign-home.md).

## O que afeta {esta área}

- Bullets curtos com o impacto específico aqui
- Sem duplicar o conteúdo do canônico
```

Mantenha o stub **curto** — se está crescendo, é sinal de que a informação tem componente próprio desta área (e aí ele fica aqui).

## Quando virar sub-área dedicada

Se o tema toca 2+ áreas **continuamente** e cada uma tem trabalho substancial sobre ele:

- Considere criar **sub-área** em uma das áreas (`areas/{principal}/sub-areas/{tema}/`).
- Ou — se nenhuma área é dona clara — criar área nova só pra ele.

**Exemplos reais:**
- *Conteúdo de marketing* → começou em marketing, virou `areas/marketing/sub-areas/conteudo/` quando ganhou volume.
- *Customer Success* → se atendimento + vendas operam isso juntos, pode virar área nova `areas/cs/`.

## Anti-padrões

- ❌ Duplicar conteúdo em duas áreas. Inevitavelmente divergem.
- ❌ Cross-link sem owner declarado. Ninguém atualiza.
- ❌ Mover canônico cada vez que muda o time que fala dele. Owner é estabilidade — só muda em decisão estrutural.

## Casos de exemplo

### Case do cliente — cross atendimento + marketing

- **Captura:** atendimento (suporte registrou no ticket).
- **Canônico:** `areas/atendimento/contexto/cases/{cliente}.md`.
- **Edição editorial pro site:** marketing edita `areas/marketing/contexto/cases-site/{cliente}.md` referenciando o canônico.
- **Quando o case muda** (cliente atualizou): atendimento atualiza canônico, marketing atualiza o site.

### Calendário editorial — marketing + produto + vendas

- **Owner:** marketing (ele orquestra).
- **Canônico:** `areas/marketing/sub-areas/conteudo/contexto/calendario.md`.
- **Vendas e produto** lêem de lá; se quiserem inserir conteúdo, capturam em `inbox/{slug}/` com `destino_sugerido` apontando pro canônico.

### Métrica financeira (NÃO é cross-área operacional)

- **Triggers** a regra dos 3 gatilhos.
- **Vai pro repo da diretoria** (`{{EMPRESA_SLUG}}-second-brain-diretoria`).
- Não é "cross-área" no sentido deste doc — é mudança de cérebro.

## Skills relacionadas

- [`empresa/skills/consolidar-estacoes/SKILL.md`](../skills/consolidar-estacoes/SKILL.md) — quando a consolidação noturna detecta tema repetido em 2+ inboxes, sinaliza no digest.
