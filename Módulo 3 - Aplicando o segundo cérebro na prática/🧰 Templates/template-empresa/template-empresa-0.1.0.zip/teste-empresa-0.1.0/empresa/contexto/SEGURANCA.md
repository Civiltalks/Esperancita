# Segurança do cérebro

## O que nunca commitar

- Credenciais (tokens, passwords, chaves privadas)
- Dado pessoal de cliente (CPF, endereço, telefone não-profissional)
- Print de WhatsApp sem autorização das partes
- Mensagens privadas de funcionários (exceto pedaços autorizados)
- Conteúdo que dispara os 3 gatilhos (vai pro cérebro da diretoria)

## Como fazer certo

- Dado pessoal/sensível → `inbox/{nome}/privado/` (gitignored) ou cérebro da diretoria
- Se surgir no meio de captura, o agente deve perguntar antes de commitar
- Se pular o filtro e você perceber depois: apagar commit + `git push --force-with-lease` (com cuidado) + avisar {{FUNDADOR_1}}

## Convite de novos membros

- Adicione ao GitHub Org com permissão "Read" ou "Write" conforme papel
- Peça pra rodar `setup-estacao-pessoal` na primeira sessão
- Revise a estação da pessoa na primeira semana

## Vazamento suspeito

- Reporte imediatamente a {{FUNDADOR_1}}
- Não apague nada sem combinar (perde evidência)
- Se é erro próprio, seja honesto: consertar é rápido; esconder cria dívida

## `.gitignore` mínimo

Este template já vem com `.gitignore` cobrindo:
- `agentes/*/memory/.dreams/` (memória runtime)
- `inbox/*/privado/` (privado de cada estação)
- `inbox/*/_historico/` (histórico pós-consolidação)
- `agentes/*/google_*.json`, `.env`, `*.key`, `*.pem` (credenciais)
- `.DS_Store`, `node_modules/`, `__pycache__/`, `.venv/`

Ajuste conforme necessário, mas **nunca remova** as linhas de credenciais.
