# MAPA — marketing/

Área: **marketing**.

## Estrutura

```
marketing/
├── contexto/      → estado, conhecimento, artefatos
├── rotinas/       → automações (crons do agente)
└── skills/        → habilidades invocáveis
```

## Navegação

- Visão geral e estado da área → `contexto/`
- Processos recorrentes automatizados → `rotinas/`
- Skills centrais → `skills/_index.md`

## Responsáveis

- **Lead da área:** {{LEAD_MARKETING}}
- **Agente executor:** {{AGENTE_NOME}}

## Escopo

{{ESCOPO_MARKETING}}

---

*Template: substitua `{{...}}` pelos dados da sua empresa. Adicione sub-áreas em `sub-areas/` se necessário.*
