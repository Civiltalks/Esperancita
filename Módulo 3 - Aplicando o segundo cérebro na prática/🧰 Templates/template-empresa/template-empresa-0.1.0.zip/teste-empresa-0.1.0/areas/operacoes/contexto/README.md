# contexto/ — operacoes/

Estado, conhecimento e artefatos da área de **operacoes**: visões gerais, descrições de processos, relatórios consolidados, decisões específicas da área.

## Exemplos de arquivos que vivem aqui

- `geral.md` — visão panorâmica da área
- `projetos.md` — projetos operacionais ativos
- `licoes.md` — lições aprendidas específicas da área
- subpastas por tema (ex: `reports/`, `campanhas/`)

## Não fica aqui

- Conteúdo sensível (3 gatilhos) → cérebro da diretoria
- Capturas provisórias do dia → `inbox/{nome}/`

Quando um arquivo amadurece, a consolidação noturna promove pra cá.
