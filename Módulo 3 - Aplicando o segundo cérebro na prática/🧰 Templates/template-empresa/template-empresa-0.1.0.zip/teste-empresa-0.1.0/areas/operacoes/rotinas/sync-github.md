---
nome: sync-github
schedule: "0 0 * * *"
timezone: UTC
schedule_legivel: "Diária 21:00 BRT / 00:00 UTC"
agente: {{AGENTE_SLUG}}
skill: null
branch_alvo: staging
---

# Rotina — Sync para GitHub ({{AGENTE_NOME}} → staging)

> Sincroniza configuração e memória operacional local do {{AGENTE_NOME}} pro repositório, na branch `staging`. Esta rotina é **mecânica pura** (rsync + git) — não invoca skill nem LLM. O agente executa diretamente os passos descritos aqui.

## Agente executor

**{{AGENTE_NOME}}** — rodando no VPS dedicado (`/root/.openclaw/workspace/`).

## Frequência

1x/dia — 00:00 UTC (21:00 BRT), via crontab do sistema do VPS.

## Branch alvo

**`staging`** (**não** `main`).

`main` só é atualizada pela rotina de consolidação noturna (`consolidacao-second-brain.md`) que promove ou abre PR. Este cron só empurra o trabalho do dia pra camada de staging.

## O que sincroniza

Copia do workspace do {{AGENTE_NOME}} (`/root/.openclaw/workspace/`) pro repo local (`{{EMPRESA_SLUG}}-second-brain/agentes/{{AGENTE_SLUG}}/`):

**Config do agente** (sempre):
- `IDENTITY.md`, `SOUL.md`, `USER.md`, `AGENTS.md`, `TOOLS.md`, `HEARTBEAT.md`, `MEMORY.md`

**Memória operacional** (só notas diárias):
- `memory/YYYY-MM-DD.md`

## O que **não** sincroniza (exclusões duras)

A memória local do {{AGENTE_NOME}} só carrega notas diárias. Qualquer outro arquivo em `memory/` é ignorado pelo sync. Em particular, os seguintes **nunca** entram neste repo — ou são sensíveis (vivem no `{{EMPRESA_SLUG}}-second-brain-diretoria` operado pelo {{AGENTE_DIRETORIA_NOME}} em VPS separado), ou foram consolidados no canônico:

```
memory/people.md                   (sensível — diretoria)
memory/decisions.md                (sensível — diretoria)
memory/metrics.md                  (sensível — diretoria)
memory/pending.md                  (sensível — diretoria)
memory/overnight-report-*.md       (sensível — diretoria)
memory/channels.md                 (obsoleto — virou contexto de área)
memory/content.md                  (obsoleto — virou contexto de área)
memory/lessons.md                  (obsoleto — virou contexto de área)
memory/projects.md                 (obsoleto — virou contexto de área)
memory/pixel-context.md            (obsoleto — já está em empresa/contexto/)
memory/openclaw-docs.md            (obsoleto — referência online em docs.openclaw.ai)
memory/shortlinks.md               (obsoleto — vive na skill shortlink-openclaw)
memory/.dreams/                    (runtime)
```

Se o VPS do {{AGENTE_NOME}} ainda tem esses arquivos localmente (herança de antes da padronização da memória), eles:
1. Precisam ser **removidos do workspace local do {{AGENTE_NOME}}** no VPS, ou
2. Ser movidos pro VPS do {{AGENTE_DIRETORIA_NOME}}, que roda em ambiente isolado.

O comando de sync usa `rsync --exclude` pra garantir que não vazem pra este repo mesmo se ainda existirem no workspace.

## Comando

```bash
cd /root/.openclaw/workspace
test -d {{EMPRESA_SLUG}}-second-brain || git clone https://github.com/{{ORG}}/{{EMPRESA_SLUG}}-second-brain.git

cd {{EMPRESA_SLUG}}-second-brain
git fetch origin
git checkout staging
git pull --rebase origin staging

# sincronizar configs + memória filtrada
mkdir -p agentes/{{AGENTE_SLUG}}
rsync -a --delete \
  --include='memory/' \
  --include='memory/[0-9][0-9][0-9][0-9]-[0-9][0-9]-[0-9][0-9].md' \
  --exclude='memory/*' \
  --exclude='memory/.dreams/' \
  /root/.openclaw/workspace/IDENTITY.md \
  /root/.openclaw/workspace/SOUL.md \
  /root/.openclaw/workspace/USER.md \
  /root/.openclaw/workspace/AGENTS.md \
  /root/.openclaw/workspace/TOOLS.md \
  /root/.openclaw/workspace/HEARTBEAT.md \
  /root/.openclaw/workspace/MEMORY.md \
  /root/.openclaw/workspace/memory/ \
  agentes/{{AGENTE_SLUG}}/

# commit apenas o que está em agentes/{{AGENTE_SLUG}}/
git add agentes/{{AGENTE_SLUG}}/
git diff --cached --quiet || git commit -m "sync: {{AGENTE_SLUG}} config+memory $(date +%Y-%m-%d)"
git pull --rebase origin staging
git push origin staging
```

**Regra dura:** o comando **só adiciona `agentes/{{AGENTE_SLUG}}/`** — nunca `git add -A` ou `git add .`.

## Entrega

- Commit em `staging` com mensagem `sync: {{AGENTE_SLUG}} config+memory YYYY-MM-DD`
- Push pra `origin/staging`
- Log do cron em `/var/log/openclaw/sync-github.log`

## Dependências

- `GITHUB_TOKEN` configurado (git credential store ou PAT)
- Acesso HTTPS ou SSH ao repo
- `rsync` instalado no VPS

## Quando rever esta rotina

- Quando a lista de arquivos sensíveis (exclusões) mudar
- Quando o VPS do {{AGENTE_NOME}} migrar de caminho
- Quando o {{AGENTE_NOME}} for renomeado ou clonado pra outro perfil

---

*Atualizado: 2026-04-20 — empurra pra staging (não main); exclusões alinhadas à reestrutura 2-cérebros.*
