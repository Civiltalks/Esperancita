---
nome: consolidacao-second-brain
schedule: "0 5 * * *"
timezone: UTC
schedule_legivel: "Diária 02:00 BRT / 05:00 UTC"
agente: {{AGENTE_SLUG}}
skill: empresa/skills/consolidar-estacoes/SKILL.md
canal_notificacao: telegram
---

# Rotina — Consolidação noturna do {{EMPRESA}} Second Brain

> Consolidação das estações pessoais (`inbox/*/`) e da memória operacional do {{AGENTE_NOME}} em canônico.

## Fonte única de verdade

Este arquivo é **apenas declarativo** — descreve quando/como a rotina roda. A lógica operacional vive na skill canônica:

**→ [`empresa/skills/consolidar-estacoes/SKILL.md`](../../../empresa/skills/consolidar-estacoes/SKILL.md)**

Qualquer atualização de comportamento (o que promove, como classifica, quando abre PR) vai lá, não aqui.

## Agente executor

**{{AGENTE_NOME}}** — agente do time.

## Frequência

Diária, **02:00 BRT** (`0 5 * * *` em UTC).

## O que faz (resumo)

1. Lê `staging` — diffa `main..staging` (espera só mudanças em `inbox/*/`).
2. Classifica cada captura via sidecar `.meta.yaml`.
3. Promove direto pra `main` o que está `maturidade: pronto-para-canonico` **com `destino_sugerido` claro**.
4. Abre PR contra `main` pro que é `proposta-canonica` ou pronto sem destino.
5. Mantém no inbox o que ainda está `cru` ou `draft`.
6. Arquiva processado em `inbox/{nome}/_historico/{data}/` (gitignored).
7. Sincroniza `staging` com `main` após promoção.
8. Escreve digest em `empresa/consolidacao/{data}.md`.
9. Notifica no Telegram (tópico ⚙️ Operações).

## Destinos canônicos

**Operacional do time (este repo):**

| Tipo | Destino |
|------|---------|
| Lição operacional / técnica | `areas/{area}/contexto/licoes.md` (canônico) ou `agentes/{{AGENTE_SLUG}}/memory/` (rascunho local do agente) |
| Pendência operacional | `areas/{area}/contexto/pendencias.md` |
| Projeto operacional | `areas/{area}/contexto/projetos.md` |
| Métrica operacional (ROAS, CTR) | `areas/marketing/contexto/` ou área específica |
| Conteúdo / Marketing | `areas/marketing/` na pasta apropriada |
| Skill nova | `skills/` da área correspondente |
| Rotina nova | `rotinas/` da área correspondente |
| Atualização estrutural | `MAPA.md` da área |

**Sensível (diretoria — NÃO vai aqui):**

Se a captura dispara a regra dos 3 gatilhos (dinheiro com nome próprio, pessoa específica, peso contratual/jurídico), o {{AGENTE_NOME}} **não escreve aqui**. Sinaliza ao humano que deve ir pro `{{EMPRESA_SLUG}}-second-brain-diretoria` ({{AGENTE_DIRETORIA_NOME}}).

Exemplos que **saem** deste repo:
- Decisão estratégica de sócio → governança (diretoria)
- Métrica financeira (EBITDA, valuation) → financeiro (diretoria)
- Contratação, desligamento, avaliação → RH (diretoria)
- Contrato, compliance, litígio → jurídico (diretoria)

## Regras invioláveis

- Nunca resolver conflito de merge sozinho — escalar pro humano.
- Nunca deletar captura sem arquivar primeiro.
- Nunca commitar conteúdo que dispara os 3 gatilhos — sinalizar.
- Nunca transformar hipótese em decisão.

## Mensagem esperada ao time

Ao final da rotina, postar no tópico ⚙️ Operações do Telegram:

```
Consolidação 2026-04-20 ✅
- X capturas promovidas pra main
- Y PRs abertos pra revisão
- Z capturas mantidas no inbox (ainda verdes)
- digest: empresa/consolidacao/2026-04-20.md
```

---

*Atualizado: 2026-04-20 — reestrutura 2-cérebros. Fonte de verdade operacional migrou pra skill `consolidar-estacoes`.*
