# Skills — operacoes/

Skills específicas desta área. Skills transversais (usadas em várias áreas) vivem em `empresa/skills/`.

Cada skill fica em subpasta própria com `SKILL.md`. Template em `empresa/skills/_templates/`.

## Skills ativas

_(vazio — adicione conforme criar)_
