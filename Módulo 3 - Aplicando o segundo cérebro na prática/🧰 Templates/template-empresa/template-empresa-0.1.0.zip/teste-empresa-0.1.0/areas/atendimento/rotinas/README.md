# rotinas/ — atendimento/

Automações (crons do agente) desta área. Um arquivo `.md` por rotina, flat.

## Schema sugerido de cada rotina

```yaml
---
nome: ...
schedule: "0 9 * * *"  # cron, em UTC
skill: ...             # skill invocada
topico: ...            # canal de notificação
---

# Rotina: Nome

## O que faz
## Quando roda
## O que entrega
```

A rotina principal (consolidação noturna do agente geral) é declarada em `agentes/{{AGENTE_NOME}}/HEARTBEAT.md`.
