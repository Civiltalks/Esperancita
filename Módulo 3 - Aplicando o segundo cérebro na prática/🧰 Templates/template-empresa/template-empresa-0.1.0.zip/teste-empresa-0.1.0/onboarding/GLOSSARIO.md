# GLOSSÁRIO

## Cérebro

Repositório Git que guarda o conhecimento canônico da empresa. Este template monta um cérebro do tipo "empresa/time" (operacional). Ver `empresa/contexto/ARQUITETURA.md` para o modelo de 2 cérebros.

## Estação pessoal

Pasta `inbox/{nome}/` dentro do cérebro. É o workspace de cada pessoa do time dentro do repositório — onde ela captura ideias, rascunhos, pesquisas e propostas durante o dia. É **triagem**, não memória oficial.

## Agente

Programa de IA que opera o cérebro (via Claude Code / OpenClaw). Tem arquivos de configuração (`IDENTITY.md`, `SOUL.md`, `USER.md`, `AGENTS.md`, `TOOLS.md`, `HEARTBEAT.md`, `MEMORY.md`) e memória runtime em `memory/`.

Neste template o agente padrão é o `geral-empresa`. Cada empresa pode renomear e especializar conforme cresce.

## Inbox

Pasta `inbox/` do repositório. É a área de triagem compartilhada — contém uma estação pessoal por pessoa (`inbox/{nome}/`) e o template base (`inbox/_TEMPLATE/`).

Conteúdo de inbox é **provisório** até a rotina noturna de consolidação decidir promover, abrir PR ou arquivar.

## Canônico

Conteúdo que está nas pastas `areas/` ou `empresa/` (fora de `inbox/`). É a memória oficial da empresa, revisada e versionada.

Regra: ninguém edita canônico diretamente em sessão de trabalho. Edições viram **propostas** no inbox (sidecar `tipo: proposta-canonica`) e a consolidação noturna abre PR.

## Consolidação

Rotina noturna (~02:00 BRT) do agente que processa `inbox/` do dia:

- Promove direto pra `main` o que está pronto (`maturidade: pronto-para-canonico` com destino claro)
- Abre PR pro que precisa revisão humana
- Arquiva em `inbox/{nome}/_historico/` o que foi processado
- Mantém no inbox o que ainda está verde (`maturidade: cru`)

Skill: `consolidar-estacoes`.

## Sidecar `.meta.yaml`

Arquivo irmão obrigatório de toda captura no inbox. Nome: `{arquivo.ext}.meta.yaml` (extensão dobrada intencional).

Classifica a captura (autor, tipo, maturidade, destino) pra consolidação decidir o que fazer. Sem sidecar, a consolidação não promove — captura fica no inbox até alguém adicionar sidecar ou arquivar.

## Regra dos 3 gatilhos

Classificação que decide se um conteúdo vive neste repo (time) ou no repo da diretoria:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual → diretoria
2. **Pessoa específica** — avaliação, conflito, contratação → diretoria
3. **Peso contratual sensível ou jurídico** — acordos de sócios, NDAs, M&A, litígio, escritório de advocacia/advisory → diretoria
   - **Não é gatilho:** contratos operacionais (gateway de pagamento, hosting, SaaS recorrente, fornecedor padrão) — esses ficam aqui em `areas/operacoes/`.

Se não dispara nenhum → fica neste repo.

## `staging` vs `main`

- `staging` — branch de trabalho. Todo mundo commita aqui, só em `inbox/{nome}/`.
- `main` — memória canônica. Só muda pela consolidação noturna (PR ou promoção direta).

## Skill

Habilidade nomeada invocável pelo agente ou por um humano. Cada skill vive em uma subpasta com `SKILL.md` descrevendo o contrato. Neste template vêm 2 essenciais: `consolidar-estacoes` e `setup-estacao-pessoal`.
