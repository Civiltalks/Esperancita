# SETUP — Cérebro da empresa em ~1 hora

> Wizard oficial do `template-second-brain-empresa`. Leva você do "repo recém-clonado" ao "time capturando, agente consolidando, fluxo rodando".

## Você é qual aluno?

Este template suporta **3 cenários**. Identifique o seu antes de começar:

| Persona | O que tem hoje | Onde o agente vai rodar |
|---|---|---|
| **1. Só Claude Code** | Laptop com Claude Code instalado. Sem VPS, sem OpenClaw. | Consolidação via **Claude Code Scheduled Task** no laptop |
| **2. Só OpenClaw** | VPS com OpenClaw rodando. Sem Claude Code instalado localmente (ou usa pouco). | Consolidação no **OpenClaw VPS dedicado** |
| **3. Claude Code + OpenClaw** | Laptop + VPS. Usa Claude Code pra trabalhar no dia, OpenClaw 24/7 pra rotinas. | Cérebro é **um repo único, clonado nos 2 lugares** — git sincroniza. Edição via Claude Code; rotinas via OpenClaw. |

**Princípio comum aos 3:** o cérebro é um repositório Git. O que muda entre os cenários é **onde o agente roda** as rotinas (consolidação noturna, sync). A captura humana e o fluxo `/sync-empresa` funcionam igual nos 3.

## O que você vai conseguir

- Cérebro operacional do time versionado no GitHub
- Sua estação pessoal pra capturar o dia a dia (`inbox/{seu-slug}/`)
- Agente geral configurado pra consolidar inboxes às ~02:00 BRT
- `/sync-empresa` funcionando como slash command no Claude Code

## Pré-requisitos

| Item | Persona 1 | Persona 2 | Persona 3 |
|---|---|---|---|
| Conta GitHub em Organização (não pessoal) | ✓ | ✓ | ✓ |
| Git configurado (SSH ou PAT) | ✓ | ✓ | ✓ |
| Claude Code (CLI ou Cowork Desktop) | ✓ | — | ✓ |
| VPS com OpenClaw | — | ✓ | ✓ |
| `gh` CLI instalado | ✓ | ✓ | ✓ |

Tempo estimado: **~1h** pra fluxo solo. Convidar o time leva ~1 semana extra.

---

## Skills que você vai usar (na ordem)

| # | Skill | Quando | Onde rodar |
|---|---|---|---|
| 1 | `inicializar-cerebro` | Uma vez só (após clone) | Claude Code (Persona 1, 3) ou OpenClaw VPS (Persona 2) |
| 2 | `setup-workstation` | Uma vez por máquina | Claude Code (Persona 1, 3) — orquestra layout local + slash commands |
| 3 | `setup-agente-openclaw` | Uma vez por VPS | VPS dedicado (Persona 2, 3). Modo NOVO ou MERGE. **Persona 1 pula** |
| 4 | `/sync-empresa` | Diário | Claude Code (Persona 1, 3) ou OpenClaw via gatilho (Persona 2, 3) |
| 5 | `consolidar-estacoes` | Noturno automático | Scheduled Task no Claude Code (Persona 1) ou cron OpenClaw (Persona 2, 3) |

`setup-workstation` chama `setup-estacao-pessoal` internamente — você não precisa invocar essa skill direto.

---

## Fase 1 — Criar seu fork do template

1. Acesse `github.com/pixel-educacao/template-second-brain-empresa`.
2. Clique em **"Use this template" → "Create a new repository"**.
3. Owner: **sua Organização** (não conta pessoal — este cérebro é coletivo).
4. Nome sugerido: `{{EMPRESA_SLUG}}-second-brain` (ex: `acme-second-brain`).
5. Visibilidade: **Private**.

Esse é o ponto "drag-and-drop" — 1 clique no GitHub e seu repo nasce.

## Fase 2 — Clonar local

```bash
mkdir -p ~/{{EMPRESA_SLUG}}
cd ~/{{EMPRESA_SLUG}}
git clone git@github.com:{{SUA_ORG}}/{{EMPRESA_SLUG}}-second-brain.git empresa
cd empresa
git checkout -b staging
git push -u origin staging
```

Convenção: clones ficam em `~/{{EMPRESA_SLUG}}/{tipo}/` (decisão Cayo, review 23/04). Clone deste repo vai pra `~/{{EMPRESA_SLUG}}/empresa/`.

`staging` é a branch padrão de trabalho. `main` só muda pela consolidação noturna.

## Fase 3 — Inicializar o cérebro

Esta é a **primeira** skill. Tutorial + configurador em um.

**Persona 1 e 3 (Claude Code):**
> No Claude Code aberto em `~/{{EMPRESA_SLUG}}/empresa/`:
>
> "Rode a skill inicializar-cerebro"

**Persona 2 (só OpenClaw):**
> No VPS, dentro do clone:
>
> ```bash
> bash empresa/skills/inicializar-cerebro/scripts/inicializar.sh \
>   --empresa "Acme Corp" --empresa-slug "acme" \
>   --org "acme-org" --empresa-dominio "acme.com" \
>   --agente-nome "Oliver" --agente-slug "oliver" \
>   ...  # ver SKILL.md pra lista completa de args
> ```

O que ela faz (qualquer persona):
1. Substitui placeholders em ~35 arquivos (`{{EMPRESA}}` → nome real, etc.)
2. Renomeia `agentes/geral-empresa/` → `agentes/{slug-do-seu-agente}/`
3. Remove blocos `<!-- template-only-* -->` (instruções meta-template)
4. Cria `.cerebro-inicializado` (trava reexecução)
5. Commit inicial em staging

**Roda 1 vez só.** Aborta se já rodou.

## Fase 4 — Configurar workstation local (Persona 1 e 3)

> Persona 2 (só OpenClaw): pula esta fase. VPS não precisa de symlinks de slash commands.

No Claude Code:

> "Rode a skill setup-workstation"

O que ela faz:
1. Detecta seu papel (membro do time / sócio-diretor)
2. Garante layout `~/{{EMPRESA_SLUG}}/{empresa,diretoria,pessoal}/` lado a lado (clona o que faltar, com sua confirmação)
3. Cria `~/{{EMPRESA_SLUG}}/.claude/skills/` com symlinks pras skills:
   - **Time:** `/cerebro`, `/sync-empresa`
   - **Diretor:** + `/sync-pessoal` (alias `/save`) + `/sync-diretoria` + skills extras do pessoal
4. Invoca `setup-estacao-pessoal` neste repo (cria sua `inbox/{seu-slug}/`)
5. Confirma resultado e instrui a reiniciar o Claude Code

Após reiniciar, abra a sessão na **pasta-mãe** `~/{{EMPRESA_SLUG}}/` e rode `/cerebro` no primeiro turno — carrega CLAUDE.md de todos os cérebros presentes.

## Fase 5 — Configurar o agente em VPS (Persona 2 e 3)

> Persona 1 (só Claude Code): pula esta fase. Sua consolidação roda via Scheduled Task local na Fase 7.

**Persona 2 (zero):** modo NOVO da `setup-agente-openclaw` sobe um OpenClaw 24/7 com este repo como workspace.

**Persona 3 (já tem OpenClaw):** modo MERGE da `setup-agente-openclaw` adapta o workspace existente, preservando customizações.

No VPS:

```bash
cd ~/openclaw/workspace/{{EMPRESA_SLUG}}-second-brain  # ou path do seu OpenClaw
bash empresa/skills/setup-agente-openclaw/scripts/setup_agent.sh
```

A skill registra rotinas no scheduler nativo do OpenClaw (sem cron Linux):
- `sync-github` (a cada 30min) — pull/push do repo
- `consolidar-estacoes` (02:00 BRT) — rotina noturna

Ver [`../empresa/skills/setup-agente-openclaw/SKILL.md`](../empresa/skills/setup-agente-openclaw/SKILL.md) pra detalhes.

## Fase 6 — Primeira captura via `/sync-empresa`

**Toda persona.** Funciona igual nos 3 cenários — é o fluxo canônico de captura visitante.

No Claude Code (Persona 1, 3) ou via DM ao agente OpenClaw (Persona 2, 3):

1. Trabalhe normalmente, escreva ideias em `inbox/{seu-slug}/{YYYY-MM-DD-HHMM}-{slug}.md` + sidecar `.meta.yaml`
2. No fim do expediente, rode `/sync-empresa`:

> "Rode /sync-empresa"

A skill detecta seu modo automaticamente:
- **Diretor com cérebro pessoal** → modo cross-brain (lê commits novos do `~/{{EMPRESA_SLUG}}/pessoal/` e copia pra `inbox/{seu-slug}/` daqui)
- **Funcionário (sem pessoal)** → modo local (lê `inbox/{seu-slug}/` não-commitado e commita em staging)

Quiz item-a-item:
- Subir pro staging? [s/N/editar/deletar]
- Aplica check dos 3 gatilhos (dinheiro nominal, pessoa específica, peso contratual) → bloqueia se disparar (vai pra `/sync-diretoria`)
- Sidecar obrigatório

Default: **N** (não distribuir). Nada vaza pro staging sem confirmação explícita.

> ⚠️ **Anti-padrão:** `git add inbox/{slug}/ && commit && push` direto. Sem revisão item-a-item, sem check de gatilhos, sem garantia de sidecar. **Sempre use `/sync-empresa`.**

## Fase 7 — Agendar consolidação noturna

A consolidação roda 02:00 BRT todo dia. Configuração depende da persona:

### Persona 1 (só Claude Code) — Scheduled Task

No Claude Code, crie uma Scheduled Task:
- **Nome:** `consolidacao-{{EMPRESA_SLUG}}`
- **Schedule:** `0 5 * * *` (02:00 BRT = 05:00 UTC)
- **Prompt:** `"Rodar skill consolidar-estacoes no repo ~/{{EMPRESA_SLUG}}/empresa"`

### Persona 2 e 3 (com OpenClaw) — scheduler nativo

A `setup-agente-openclaw` (Fase 5) já registrou as rotinas. Verifique:

```bash
openclaw schedule list | grep consolidar-estacoes
```

Deve aparecer com schedule `0 5 * * *`.

## Fase 8 — Validação

Faça:

1. Capture 3 ideias em `inbox/{seu-slug}/`:
   - Uma "crua" (sidecar `maturidade: cru`)
   - Uma "draft" (sidecar `maturidade: draft`)
   - Uma "proposta-canonica" (sidecar `tipo: proposta-canonica` + `destino_sugerido: areas/marketing/contexto/algo.md`)
2. Rode `/sync-empresa` — confirma os 3 itens, push em staging.
3. Force consolidação manual: `"Rode skill consolidar-estacoes agora"`
4. Verifique:
   - [ ] `main` tem a "pronto-para-canonico" promovida
   - [ ] PR aberto pra "proposta-canonica"
   - [ ] A "crua" continua no seu inbox
   - [ ] Digest em `empresa/consolidacao/{hoje}.md` existe

Se tudo passou, seu cérebro está operacional.

## Fase 9 — Convidar o time

Para cada pessoa do time:

1. Adicione ao GitHub Org com permissão "Write".
2. Envie URL do repo + este SETUP.md.
3. Peça pra começar na Fase 2 (com adaptações: persona dela pode ser diferente).
4. `setup-workstation` cria a estação dela automaticamente.

Planeje ~1 semana pra todo time ter estação funcionando.

## Fase 10 — Quando abrir o cérebro da diretoria

**Não abra imediatamente.** Primeiro este repo virar rotina (~60 dias).

Considere clonar `template-second-brain-diretoria` quando:
- Primeira contratação formal com CLT/PJ
- Primeiro contrato com distribuição de receita / equity
- Primeira captura "dinheiro com nome próprio"
- Primeira situação RH que requer registro (avaliação, conflito)

Ver [`../empresa/contexto/ARQUITETURA.md`](../empresa/contexto/ARQUITETURA.md).

---

## Tempo total estimado

| Fase | Persona 1 | Persona 2 | Persona 3 |
|---|---|---|---|
| 1-2 (fork + clone) | 10min | 10min | 10min |
| 3 (inicializar) | 5min | 5min | 5min |
| 4 (workstation) | 10min | — | 10min |
| 5 (VPS OpenClaw) | — | 20min | 20min |
| 6 (primeira captura) | 10min | 10min | 10min |
| 7 (agendar) | 5min | já feito na Fase 5 | já feito |
| 8 (validação) | 15min | 15min | 15min |
| **Total solo** | **~55min** | **~60min** | **~70min** |
| 9 (convidar time) | +1 semana | +1 semana | +1 semana |

## Cross-uso Claude Code + OpenClaw (Persona 3)

Cérebro é **um repo único** — não duplica. Como funciona:

```
GitHub: pixel-org/{{EMPRESA_SLUG}}-second-brain (origem)
       ↓                                        ↓
Laptop (Claude Code)              VPS (OpenClaw)
~/{{EMPRESA_SLUG}}/empresa/       ~/openclaw/workspace/{{EMPRESA_SLUG}}-second-brain/
```

- **Claude Code** edita em staging, push.
- **OpenClaw** pull periódico (cron `sync-github` 30min), edita canônico ou consolida em staging, push.
- Git resolve. Nunca há "sincronia" customizada — é só git push/pull.

Conflitos: a rotina `consolidar-estacoes` tem regra "nunca resolver conflito sozinha" — alerta humano.

## Links rápidos

- [`CLAUDE.md`](../CLAUDE.md) — instruções operacionais
- [`empresa/contexto/PRINCIPIOS.md`](../empresa/contexto/PRINCIPIOS.md) — regras duras (3 gatilhos, sidecar)
- [`empresa/contexto/ARQUITETURA.md`](../empresa/contexto/ARQUITETURA.md) — modelo dos 2 cérebros
- [`empresa/contexto/FLUXO-CAPTURA.md`](../empresa/contexto/FLUXO-CAPTURA.md) — fluxo `/sync-empresa`
- [`empresa/skills/sync-empresa/SKILL.md`](../empresa/skills/sync-empresa/SKILL.md)
- [`empresa/skills/setup-workstation/SKILL.md`](../empresa/skills/setup-workstation/SKILL.md)
- [`empresa/skills/consolidar-estacoes/SKILL.md`](../empresa/skills/consolidar-estacoes/SKILL.md)
- [`MAPA.md`](../MAPA.md) — visão geral
