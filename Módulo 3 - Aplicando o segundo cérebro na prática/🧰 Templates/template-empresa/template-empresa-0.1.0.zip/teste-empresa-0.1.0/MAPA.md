# MAPA — {{EMPRESA}} Second Brain (Empresa/Time)

## Função

Ponto de entrada pra navegar o cérebro operacional do time.

## Dois cérebros disjuntos

Sua empresa opera com dois repositórios complementares:

1. **Este** (cérebro do time) — tudo que é operacional: marketing, vendas, atendimento, operações, produto. Acesso: todo o time.
2. **Cérebro da diretoria** (cria depois a partir de `template-second-brain-diretoria`) — conteúdo sensível: financeiro, RH, jurídico, governança. Acesso: só sócios.

Ver [`empresa/contexto/ARQUITETURA.md`](empresa/contexto/ARQUITETURA.md).

## Regra de navegação

1. Comece aqui para localizar a área certa.
2. Entre no `MAPA.md` da área.
3. Se houver subárea, entre no `MAPA.md` da subárea.
4. Para **contexto, rotinas e projetos**, siga sempre pelo `MAPA.md`.
5. Para **skills**, abra `skills/_index.md` da área ou subárea.

## Convenção

- `MAPA.md` = mapa estrutural e de navegação
- `skills/_index.md` = catálogo de skills
- Toda área tem: `contexto/`, `rotinas/`, `skills/`

## Estrutura

- `agentes/geral-empresa/` — agente operacional do time (renomeie pro nome do seu agente, ex: `geral`, `oliver`, `iris`)
- `empresa/` — contexto transversal, princípios, skills gerais
- `areas/marketing/` — marketing, conteúdo, tráfego
- `areas/vendas/` — funil, pipeline, oportunidades
- `areas/atendimento/` — suporte, relação com cliente
- `areas/operacoes/` — processos, infraestrutura, automações, rotinas (crons de sync + consolidação)
- `areas/produto/` — roadmap, features, ideias
- `inbox/` — triagem e estações pessoais
  - `inbox/{humano-slug}/` — estação de cada membro do time (e cada diretor quando faz `/sync-empresa` modo diretor pra empurrar do cérebro pessoal pra cá)

## Regra dos 3 gatilhos

Se a captura dispara qualquer um destes 3, **não fica neste repo**:

1. Dinheiro com nome próprio (salário, comissão, bônus individual)
2. Pessoa específica (avaliação, conflito, contratação)
3. Peso contratual sensível ou jurídico (acordos de sócios, NDAs, M&A, litígio, escritório de advocacia/advisory) — **não é gatilho**: contratos operacionais (gateway de pagamento, hosting, SaaS recorrente, fornecedor padrão) ficam em `areas/operacoes/`.

→ Vai pro cérebro da diretoria (`template-second-brain-diretoria` clonado).

---

*Template gerado pela Pixel Educação — Pixel AI Hub.*
