# HEARTBEAT — {{AGENTE_NOME}}

## Rotinas ativas

| rotina                        | frequência       | skill                 |
|-------------------------------|------------------|-----------------------|
| Consolidação noturna          | 02:00 BRT diário | consolidar-estacoes   |

## Como agendar (Claude Code Scheduled Task ou cron do VPS)

- **Schedule:** `0 5 * * *` (02:00 BRT = 05:00 UTC — ajuste pro seu timezone)
- **Prompt:** `"Rodar skill consolidar-estacoes no repo {{EMPRESA_SLUG}}-second-brain"`

Detalhes do setup em `empresa/skills/setup-agente-openclaw/SKILL.md` (subida do agente em VPS).

## Verificações periódicas

### 1. Inboxes e capturas travadas
- Inspecionar `inbox/*/` e o digest mais recente em `empresa/consolidacao/`
- Se houver captura importante parada há mais de 7 dias sem sidecar ou sem evolução → alertar o time

### 2. Saúde dos crons
- Verificar se os crons reais do VPS batem com:
  - `areas/operacoes/rotinas/sync-github.md`
  - `areas/operacoes/rotinas/consolidacao-second-brain.md`
- Se qualquer cron ausente, com caminho antigo, ou com erro recorrente → alertar imediatamente

### 3. Consolidação de memória local
- Ler notas diárias em `memory/`
- Se houver notas com mais de 3 dias não consolidadas → escrever direto no canônico (sou gestor)

### 4. Checagem de segurança semanal
- Verificar `.gitignore` cobre `agentes/*/google_*.json`, `.env`, `*.key`, `inbox/*/privado/`
- Se encontrar arquivo sensível no staging → alertar e sugerir remoção

### 5. Consolidação noturna das estações (02:00 BRT)
- Rodar a skill `consolidar-estacoes` (ver `empresa/skills/consolidar-estacoes/SKILL.md`)
- Processa `inbox/*/` (humanos + canal diplomático do agente da diretoria)
- Regra de segurança: nunca resolver conflito sozinho, nunca deletar captura sem arquivar primeiro

---

*Template: ajuste timezone e prompts conforme sua empresa.*
