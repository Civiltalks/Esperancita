# TOOLS — {{AGENTE_NOME}}

## Nativo do Claude Code

- `Read`, `Write`, `Edit`
- `Bash`
- `Glob`, `Grep`
- `TodoWrite`

## MCPs recomendados (instalar conforme necessidade)

- **GitHub** — gerenciar PRs, issues
- **Notion / Linear** — se o time usa
- **Slack / Telegram** — notificações de consolidação
- **Calendar** — contexto temporal

## MCPs **não** recomendados neste repo

- Ferramentas que acessam conteúdo da diretoria — este agente não opera lá

## Comandos do repo

```bash
# capturar uma ideia
# → Claude captura em inbox/{seu-nome}/

# rodar consolidação manual
# → invocar skill consolidar-estacoes

# criar estação pessoal
# → invocar skill setup-estacao-pessoal
```

---

*Template: adicione aqui MCPs específicos que sua empresa configurou.*
