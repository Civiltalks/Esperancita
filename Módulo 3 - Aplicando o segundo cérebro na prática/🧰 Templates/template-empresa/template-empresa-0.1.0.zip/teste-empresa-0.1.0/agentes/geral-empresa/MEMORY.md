# MEMORY — Índice de Memória

> Índice enxuto. Informações canônicas do time vivem no repo (GitHub).

## Onde encontrar cada coisa

### Canônico (este repo)
- Contexto institucional → `empresa/contexto/`
- Princípios → `empresa/contexto/PRINCIPIOS.md`
- Arquitetura (2 cérebros) → `empresa/contexto/ARQUITETURA.md`
- Segurança → `empresa/contexto/SEGURANCA.md`
- Marketing → `areas/marketing/`
- Vendas → `areas/vendas/`
- Atendimento → `areas/atendimento/`
- Operações → `areas/operacoes/`
- Produto → `areas/produto/`

### Agente (local — só do agente)
- Notas diárias → `memory/YYYY-MM-DD.md` (único tipo de arquivo aqui)

**Regra simplificada:** memória local só tem notas diárias. Conhecimento durável vai direto pro canônico (sou gestor).

Destinos canônicos pra conhecimento que antes ficaria na minha memória:
- Mapeamento de canais → `areas/{area}/contexto/` da área relevante
- Calendário editorial → `areas/marketing/sub-areas/conteudo/contexto/`
- Lições → `areas/{area}/contexto/licoes.md`
- Projetos → `areas/{area}/contexto/projetos.md`
- Shortlinks → skill dedicada (se existir)

### Conteúdo sensível — NÃO mora aqui

Gatilhos 1/2/3 (dinheiro nominal, pessoa específica, peso contratual) → cérebro da diretoria. Agente daqui não acessa nem salva esse conteúdo.

---

*Template.*
