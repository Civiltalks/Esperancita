# USER — {{EMPRESA}} (Time)

> Contexto compartilhado para o {{AGENTE_NOME}} atender o time operacional de {{EMPRESA}}.

## A Empresa

- **Nome:** {{EMPRESA}}
- **Tipo:** {{TIPO_EMPRESA}}
- **Timezone:** {{TIMEZONE}}
- **Idioma:** {{IDIOMA}}

## Quem eu sirvo

Todo o time operacional. Qualquer pessoa com estação em `inbox/{nome}/` pode me acionar.

A lista nominal completa (com papéis e especialidades) vive no cérebro da diretoria, não aqui — gatilho 2.

## Regra de navegação

1. Começar pelo **MAPA da raiz**.
2. Entrar no **MAPA da área** em `areas/<área>/MAPA.md`.
3. Se existir subárea, entrar no **MAPA da subárea**.
4. Usar `MAPA.md` pra localizar `contexto/`, `rotinas/`, `skills/`.
5. Pra **skills**, abrir `skills/_index.md`.

## Regra de escrita

- Informações operacionais do time → salvar em `areas/` ou `empresa/`.
- `memory/` é memória operacional do agente, rascunho local.
- Conteúdo que dispara os 3 gatilhos → não salvo aqui. Sinalizo pro humano levar pra diretoria.

## Produtos / Verticais

{{PRODUTOS_DESCRICAO}}

## Áreas que opero

| área | escopo |
|---|---|
| marketing | {{ESCOPO_MARKETING}} |
| vendas | {{ESCOPO_VENDAS}} |
| atendimento | {{ESCOPO_ATENDIMENTO}} |
| operacoes | {{ESCOPO_OPERACOES}} |
| produto | {{ESCOPO_PRODUTO}} |

## Skill principal

`consolidar-estacoes` — rotina noturna. Ver `empresa/skills/consolidar-estacoes/SKILL.md`.

---

<!-- template-only-start -->
*Template: substitua todos os `{{...}}` pelos dados da sua empresa via skill `inicializar-cerebro`.*
<!-- template-only-end -->
