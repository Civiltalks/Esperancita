# CLAUDE.md — Operação do Claude neste cérebro

<!-- template-only-start -->
> Instruções pro Claude Code / Cowork operar neste repositório (cópia do `template-second-brain-empresa`). Substitua os placeholders `{{...}}` pelos dados da sua empresa via skill `inicializar-cerebro`.
<!-- template-only-end -->

## Papel do Claude

O Claude Code atua como **estação local de trabalho** de uma pessoa específica do time. Cada pessoa tem sua estação em `inbox/{nome}/`.

Ele pode:
- explorar o repositório
- editar arquivos
- produzir drafts
- organizar material
- sintetizar estudos
- capturar tudo que surge na sessão

A consolidação do que vira memória oficial é do agente `{{AGENTE_NOME}}` (geral do time), via skill `consolidar-estacoes`.

## Fonte de verdade

- Este repo é a fonte canônica **operacional** da sua empresa.
- Conteúdo sensível (3 gatilhos) vive em outro repo clonado a partir de `template-second-brain-diretoria`.
- `inbox/` é triagem, não memória oficial.

## Regra estrutural (estrita)

Toda área tem apenas 3 pastas na raiz:

- `contexto/` — estado, conhecimento, artefatos
- `rotinas/` — automações (crons do agente). Um arquivo `.md` por rotina, flat.
- `skills/` — habilidades invocáveis (cada skill em subpasta com `SKILL.md`)

Exceção: áreas com subáreas adicionam `sub-areas/` como 4ª pasta.
Cada área/subárea tem `MAPA.md` na raiz (arquivo).

## Modelo de sincronização — branch `staging`

Todo mundo trabalha em `staging`. `main` só é atualizada pela rotina noturna de consolidação.

### Quem é gestor vs quem é visitante

- **{{AGENTE_NOME}} (agente do time)** — gestor deste cérebro. Escreve **direto** em canônico (`empresa/`, `areas/`, `agentes/{{AGENTE_NOME}}/`) durante o dia. Não usa inbox próprio — a responsabilidade é dele.
- **Humanos** (membros de time com acesso ao repo) — visitantes do canônico. Capturam **sempre** em `inbox/{seu-slug}/`, nunca direto em canônico.
- **Cada diretor** da empresa distribui capturas do **cérebro pessoal** dele (workspace local do mini-curso) pra este repo via skill `/sync-empresa` — que joga em `inbox/{diretor-slug}/` em staging. Não há mais "canal diplomático" do agente da diretoria como entidade — cada diretor é o responsável pelo próprio fluxo cross-repo.
- **Membros de time** **não** têm cérebro pessoal separado — operam este cérebro via Claude Code / Cowork on-demand com `/sync-empresa` (capturas dia-a-dia direto na estação) + linguagem natural pra o agente do time consolidar.
- **Claude Code / Cowork em sessão humana** — opera sempre como visitante (comportamento de humano).

### Regra dura (humanos e Claude em sessão)

```bash
git add inbox/{nome}/
git commit -m "..."
```

**Nunca** `git add .` ou `git add -A`. Fora de `inbox/{nome}/`, zero diffs no push.

Esta regra **não se aplica ao {{AGENTE_NOME}}** rodando autonomamente no VPS dele — ele é gestor e tem autoridade plena sobre canônico.

### Edição de canônico

Qualquer pedido de edição em `areas/**` ou `empresa/**` vira **proposta** em `inbox/{nome}/` com sidecar `.meta.yaml` (`tipo: proposta-canonica`). A consolidação noturna abre PR.

### Detecção de estação no início da sessão

1. Ler `~/.cowork/{{EMPRESA_SLUG}}-identity` — se existe, usar o slug.
2. Se não existe, disparar skill `setup-estacao-pessoal`.
3. Verificar que `inbox/{slug}/` existe no remote.

### Fluxo de sessão

```bash
git fetch origin
git checkout staging
git pull --rebase origin staging

# ... trabalho em inbox/{nome}/

git add inbox/{nome}/
git commit -m "..."
git pull --rebase origin staging
git push origin staging
```

## Sidecar `.meta.yaml` obrigatório

Toda captura em `inbox/{nome}/` (qualquer formato) vem com sidecar irmão `{arquivo.ext}.meta.yaml`. Sem sidecar, a consolidação não promove.

Schema:

```yaml
autor: {nome}
data: 2026-04-20T02:00
fonte: conversa | captura-solo | pesquisa-web | screenshot | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
destino_sugerido: areas/marketing/contexto/...
relacionado: []
tags: []
```

## Privacidade — default público

Default: tudo é **público ao time** (sobe pra staging). Privado é opt-in explícito (`inbox/{nome}/privado/`, gitignored).

Gatilhos pra `privado/`:
1. Pessoa disse "privado", "não compartilha"
2. Conteúdo claramente sensível — perguntar antes

## Regra dos 3 gatilhos

Se uma captura dispara qualquer um destes 3, **não commitar aqui**:

1. **Dinheiro com nome próprio** — salário, comissão, bônus individual
2. **Pessoa específica** — avaliação, feedback, conflito, contratação
3. **Peso contratual sensível ou jurídico** — acordos de sócios, NDAs, M&A, litígio, escritório de advocacia/advisory
   - **Não é gatilho:** contratos operacionais (gateway de pagamento, hosting, SaaS recorrente, fornecedor padrão) — esses ficam aqui em `areas/operacoes/` (ou área correspondente do cérebro do time, se aplicável).

→ Vai pro cérebro da diretoria (repo separado clonado de `template-second-brain-diretoria`). Sinalizar ao humano.

## Ordem de navegação

1. Raiz deste repo (`MAPA.md` + este `CLAUDE.md`)
2. `MAPA.md` da área
3. `MAPA.md` de subárea (se houver)
4. `skills/_index.md` para skills
5. Arquivos específicos

## O que evitar

- Não criar nova taxonomia sem necessidade
- Não tratar `inbox/` como memória oficial
- Não sobrescrever convenções estruturais existentes sem motivo claro
- **Nunca** usar `git add .` ou `git add -A`
- **Nunca** commitar fora de `inbox/{nome}/` na branch `staging`
- **Nunca** acessar o cérebro da diretoria deste repo

## Regra final

Na dúvida entre canônico e `inbox/{nome}/`, sempre preferir `inbox/{nome}/`. A consolidação noturna decide o que vira memória oficial.

---

<!-- template-only-start -->
*Gerado a partir do template-second-brain-empresa (Pixel AI Hub). Substitua os `{{...}}` pelos dados da sua empresa via skill `inicializar-cerebro`.*
<!-- template-only-end -->
