# inbox/

Área de **triagem**. Toda captura do dia a dia cai aqui, em pastas por pessoa:

```
inbox/{nome}/         ← sua estação pessoal
inbox/_TEMPLATE/      ← modelo pra criar uma estação nova
```

O que entra aqui é **provisório**. A rotina noturna de consolidação (agente geral, ~02:00 BRT) classifica cada captura e:

- Promove pro cérebro canônico (`areas/` ou `empresa/`) se `maturidade: pronto-para-canonico` com destino claro
- Abre PR de revisão se `tipo: proposta-canonica`
- Mantém no inbox se ainda está verde (`maturidade: cru`)
- Arquiva em `inbox/{nome}/_historico/` (gitignored) se já foi processado

## Regras importantes

- Toda captura tem um **sidecar `.meta.yaml`** irmão (mesmo diretório, mesmo nome base).
- `inbox/{nome}/privado/` está no `.gitignore` — usar pra conteúdo sensível.
- Durante sua sessão, o Claude **só commita dentro de `inbox/{seu-nome}/`**.

## Criar sua estação

Rodar a skill `setup-estacao-pessoal`.
