# Estação pessoal de {nome}

> Esta é a pasta de trabalho pessoal de {nome} dentro do Pixel Second Brain.

## Como funciona

Tudo que {nome} capturar durante uma sessão de Claude Code / Cowork (brainstorm, notas, drafts, pesquisa, propostas, diário) vem parar aqui automaticamente.

O conteúdo sobe em tempo real pra branch `staging`, então todo o time tem acesso ao que está sendo trabalhado durante o dia.

De madrugada (~02h), o {{AGENTE_NOME}} roda a skill `consolidar-estacoes`:

- promove pra `main` o que está maduro
- abre PR pro que precisa revisão humana
- arquiva em `inbox/{nome}/_historico/{data}/` o que foi processado
- reseta staging pra começar o dia limpo

## Regras

- **Tudo aqui é público por default.** Sobe pra staging e fica visível ao time.
- **Conteúdo privado vai pra `privado/`.** Esta subpasta está no `.gitignore` e nunca sai do laptop.
- **Frontmatter YAML é obrigatório** em todo arquivo `.md` criado aqui. Veja `CLAUDE.md` deste diretório.
- **Não editar arquivos fora deste diretório** durante a sessão e commitar — só `inbox/{nome}/` sobe.

## Subpastas que podem aparecer

- `privado/` — gitignored, local-only
- `_historico/YYYY-MM-DD/` — criada automaticamente pela consolidação do {{AGENTE_NOME}}

Fora isso, mantemos **flat**. A classificação sai no frontmatter do arquivo, não na pasta.
