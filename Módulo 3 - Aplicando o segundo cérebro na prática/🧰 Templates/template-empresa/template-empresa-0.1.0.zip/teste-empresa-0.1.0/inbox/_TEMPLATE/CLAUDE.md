# CLAUDE.md — Estação pessoal de {nome}

> Instruções específicas para o Claude quando operar a estação pessoal de {nome}. Este arquivo empilha em cima do `CLAUDE.md` da raiz.

## Identidade

- **Nome:** {nome}
- **Email:** {email}
- **Área:** {area}
- **Papel:** {papel}
- **Projetos ativos:** {projetos}

## Preferências de captura

{preferencias livres: formato de notas preferido, idioma, nível de detalhe, tom}

## Fluxo de sessão desta estação

Fonte canônica: [`empresa/contexto/FLUXO-CAPTURA.md`](../../empresa/contexto/FLUXO-CAPTURA.md). Resumo aplicado a esta estação:

### 1. Início da sessão

```bash
git fetch origin
git checkout staging
git pull --rebase origin staging
```

### 2. Durante a sessão — capturas em `inbox/{nome}/`

- Toda captura vai em `inbox/{nome}/`, flat — qualquer formato (`.md`, `.html`, `.pdf`, `.png`, `.pptx`, etc.)
- **Sidecar `.meta.yaml` obrigatório** pra cada captura. Conteúdo fica limpo; metadata vive no sidecar.
- Privado só quando explicitamente marcado pela pessoa → `inbox/{nome}/privado/`
- Nada de editar arquivos canônicos; se precisar influenciar canônico, criar proposta em `inbox/{nome}/` com sidecar marcando `tipo: proposta-canonica` e `destino_sugerido: {caminho}`
- Capturas ficam **sem git** durante a sessão. `/sync-empresa` no fim revisa e commita.

### 3. Fim de expediente — `/sync-empresa`

- Revisão item-a-item: pra cada arquivo `inbox/{nome}/` ainda untracked/modificado, decidir se sobe pro `staging`
- Aplica check dos 3 gatilhos automaticamente (envia pra `/sync-diretoria` se disparar)
- Commita e pusha só os confirmados — rejeitados ficam local

> ⚠️ **Anti-padrão:** `git add inbox/{nome}/ && commit && push origin staging` direto, sem passar pelo `/sync-empresa`. Sem revisão item-a-item, sem check de gatilhos, sem garantia de sidecar.

## Regra dura de commit

**Só commitar arquivos de `inbox/{nome}/`.** Nunca `git add .`, nunca `git add -A`. Se a sessão mexeu em qualquer outro arquivo (mesmo só pra ler/rascunhar), esses diffs ficam locais e **não** vão pro servidor.

## Como nomear arquivos

Convenção: `YYYY-MM-DD-HHMM-{slug-curto}.{ext}` e, ao lado, `YYYY-MM-DD-HHMM-{slug-curto}.{ext}.meta.yaml`

Exemplos (par conteúdo + sidecar):
- `2026-04-19-1532-aulao-padrao-ouro-notas.md` + `2026-04-19-1532-aulao-padrao-ouro-notas.md.meta.yaml`
- `2026-04-19-1545-proposta-ajuste-mapa-produto.md` + `2026-04-19-1545-proposta-ajuste-mapa-produto.md.meta.yaml`
- `2026-04-19-1600-diario.md` + `2026-04-19-1600-diario.md.meta.yaml`
- `2026-04-20-0930-apresentacao-cliente.pdf` + `2026-04-20-0930-apresentacao-cliente.pdf.meta.yaml`

## Sidecar default pra esta estação

Conteúdo do `.meta.yaml` ao lado de cada captura:

```yaml
autor: {nome}
data: <timestamp automático>
fonte: conversa | captura-solo | pesquisa-web | screenshot | reuniao | brainstorm
tipo: nota | draft | proposta-canonica | diario | referencia
maturidade: cru | draft | pronto-para-canonico
destino_sugerido: <quando claro>
relacionado: []
tags: []
```

**O conteúdo do arquivo-par fica limpo.** Sem YAML no topo. A metadata toda mora no sidecar — assim, quando o agente promover pra canônico, o conteúdo vai intocado.

---

*Criada por: skill `setup-estacao-pessoal`*
