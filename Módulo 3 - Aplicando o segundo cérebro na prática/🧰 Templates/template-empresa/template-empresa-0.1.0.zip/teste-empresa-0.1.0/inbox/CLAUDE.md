# CLAUDE.md — inbox/

> Instruções gerais pro Claude operar em `inbox/`. Estação pessoal de cada pessoa adiciona contexto em `inbox/{nome}/CLAUDE.md`.
>
> **Fluxo canônico:** ver [`empresa/contexto/FLUXO-CAPTURA.md`](../empresa/contexto/FLUXO-CAPTURA.md). Esta página resume; lá tem detalhe.

## Regras duras

1. **Só commitar em `inbox/{nome}/`** — nunca fora.
2. **Nunca `git add .` / `git add -A`** — sempre pathspec específico do seu inbox.
3. **Branch: staging.** `main` só muda via consolidação noturna.
4. **Sidecar `.meta.yaml` obrigatório** pra toda captura.
5. **Privacidade default: público ao time.** Opt-in pra `privado/` só quando pedido ou inequivocamente sensível.
6. **Conteúdo que dispara os 3 gatilhos** não fica aqui — usar `/sync-diretoria` (skill que vive em `template-second-brain-diretoria`).

## Fluxo de captura — `/sync-empresa`

Visitante (humano + Claude em sessão) usa **uma skill** que cobre 2 modos:

- **Modo diretor:** `/sync-empresa` lê commits novos do `~/{{EMPRESA_SLUG}}/pessoal/` (cérebro pessoal) e empurra pra inbox deste empresa via quiz item-a-item.
- **Modo funcionário:** `/sync-empresa` lê capturas locais em `inbox/{seu-slug}/` (criadas durante a sessão) e commita em staging via quiz item-a-item.

A skill detecta o modo automaticamente pela presença de `~/{{EMPRESA_SLUG}}/pessoal/`.

Detalhe completo + razões em [`empresa/contexto/FLUXO-CAPTURA.md`](../empresa/contexto/FLUXO-CAPTURA.md).

> ⚠️ **`git add` + `commit` + `push` direto é anti-padrão.** Sem revisão, sem check de gatilhos, sem garantia de sidecar. Use `/sync-empresa`.
